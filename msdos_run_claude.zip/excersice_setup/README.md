# MS-DOS 1.25 — source, porting reference, and a C host wrapper

This workspace combines four things:

1. **`v1.25/`** — the complete original **MS-DOS 1.25** 8086 assembly source (Tim Paterson,
   Seattle Computer Products, March 1982) plus the shipped binaries.
2. **Porting references** — documents that describe the source and how to port it to C.
3. **`src/` (wrapper)** — a small **C "wrapper" application**: a host layer providing the console
   and disk-image services a C port of the DOS kernel runs on top of.
4. **`src/kernel/` (the port)** — a compact **C port of the MS-DOS 1.25 kernel**: the FAT12
   filesystem and the `INT 21H` system-call layer, built bottom-up and integrated with the wrapper.

The wrapper gives you raw-mode keyboard input, screen output, and a sector-addressed disk image
(loaded on start, saved on exit) — the same console/disk seam the original kernel reaches through
`INT 21H` and its BIOS calls. **By default the wrapper boots the ported kernel on that seam:**
`./wrapper <image>` mounts the disk and runs a DOS-style shell whose file commands are real
`INT 21H` calls into the kernel, taking keyboard input and writing the screen through the terminal.
A low-level sector/hex disk monitor remains available via `--monitor`.

---

## Layout

```
.
├── Makefile                       # build / test / run
├── README.md                      # this file
├── REFERENCE.md                   # technical reference (DOS source + the C wrapper)
├── ASM_TO_C_PORTING_REFERENCE.md  # 8086-assembly → C porting guide
├── src/                           # the wrapper (host layer)
│   ├── disk.{h,c}                 # disk image: load on start, sector R/W, save on exit
│   ├── terminal.{h,c}             # raw-mode keyboard input + screen output
│   ├── fat12.{h,c}                # FAT12 floppy formatting (160/180/320/360/720 KB)
│   ├── main.c                     # CLI: disk monitor + --format + --shell
│   └── kernel/                    # the ported MS-DOS 1.25 kernel (bottom-up layers)
│       ├── fat.{h,c}              # L1: FAT12 arithmetic (UNPACK/PACK/ALLOCATE)
│       ├── volume.{h,c}           # L2: mounted volume / Drive Parameter Block
│       ├── dir.{h,c}              # L3: root directory, 8.3 names, search
│       ├── kfile.{h,c}            # L4: file create/open/read/write/delete/rename
│       ├── dos.{h,c}              # L5: INT 21H dispatch + char I/O + FCB calls
│       ├── command.{h,c}          # command processor (COMMAND.ASM port)
│       ├── edit.{h,c}             # full-screen text editor (EDIT command)
│       ├── basic.{h,c}            # rudimentary BASIC interpreter (BASIC command)
│       └── kfs.{h,c}              # shared status codes
├── tests/                         # one suite per layer + processor + wrapper modules
│   ├── test_fat.c test_volume.c test_dir.c test_kfile.c test_dos.c test_command.c
│   └── test_basic.c test_disk.c test_format.c
├── demo/                          # BASIC programs for the demo disk (+ README.TXT)
├── tools/mkdemo.c                 # builds demo.img and copies host files into it
└── v1.25/                         # original MS-DOS 1.25 sources and binaries
```

---

## Quick start

```sh
make build      # compile ./wrapper (wrapper + kernel)
make test       # build and run all test suites
make run        # boot the ported DOS kernel on disk.img (formats it if absent)
make demo       # build the demo disk (demo.img) and boot the kernel on it
make monitor    # launch the low-level sector/hex disk monitor on disk.img
make clean      # remove binaries and generated images
```

## Using the wrapper

### Create a blank FAT12 disk image (`--format`)

```sh
./wrapper --format mydisk.img --720     # 720 KB
./wrapper --format mydisk.img --360     # 360 KB
./wrapper --format mydisk.img --180     # 180 KB
```

Supported sizes: `--160 --180 --320 --360 --720` (kilobytes). Each writes a blank FAT12
image of the exact byte size, identified by its media descriptor byte in the FAT (the way
MS-DOS 1.x recognises a disk — no BPB is written).

| Flag | Size | Sectors | Media | Disk type |
|------|------|---------|-------|-----------|
| `--160` | 160 KB | 320 | `0xFE` | 5.25" SS 8-sector (PC DOS 1.0) |
| `--180` | 180 KB | 360 | `0xFC` | 5.25" SS 9-sector (DOS 2.0) |
| `--320` | 320 KB | 640 | `0xFF` | 5.25" DS 8-sector (PC DOS 1.1 / MS-DOS 1.25) |
| `--360` | 360 KB | 720 | `0xFD` | 5.25" DS 9-sector (DOS 2.0) |
| `--720` | 720 KB | 1440 | `0xF9` | 3.5" DS 9-sector (DOS 3.2) |

### Boot the ported kernel (default)

```sh
./wrapper dos.img        # mounts dos.img and boots the DOS shell
                         # (if dos.img is absent, a fresh 320 KB disk is formatted first)
```

This is the default action. The wrapper mounts the FAT12 image, wires the terminal as the console,
and runs the **command processor** (`command.c`, the COMMAND.ASM port): it shows the `A>` prompt,
reads a line, tokenises the command word, and dispatches to the matching internal-command handler.
Unknown commands print `Bad command or file name`. Every command runs as real `INT 21H` calls into
the kernel, so keyboard input, screen output and disk storage all go through the ported layers, and
files persist across sessions.

| Command | DOS calls used | Action |
|---------|----------------|--------|
| `DIR [pattern]` | SET DTA, SEARCH FIRST/NEXT (1Ah/11h/12h) | list files with sizes |
| `TYPE <file>` | OPEN + SEQ READ (0Fh/14h) | print a file |
| `COPY <src> <dst>` | OPEN/CREATE + SEQ READ/WRITE + CLOSE | copy a file |
| `REN <old> <new>` | RENAME (17h) | rename a file |
| `DEL`/`ERASE <file>` | DELETE (13h) | delete a file |
| `MKDIR`/`MD <dir>` | MKDIR (39h) | create a subdirectory |
| `RMDIR`/`RD <dir>` | RMDIR (3Ah) | remove an empty subdirectory |
| `CD`/`CHDIR [path]` | CHDIR (3Bh) | change directory (`NAME`, `..`, `\`); no arg prints it |
| `EDIT <file>` | OPEN/SEQ READ to load, CREATE/SEQ WRITE to save | full-screen text editor |
| `BASIC <file>` | OPEN/SEQ READ to load | run a BASIC program (`.BAS` default) |
| `CHKDSK` | SEARCH FIRST/NEXT + FAT | report total / used / free disk space |
| `ECHO` `REM` `CLS` `VER` `DATE` `TIME` `HELP` | CONOUT (02h) | console built-ins |
| `EXIT` / `QUIT` | — | leave the shell (saves) |

The `EDIT` editor uses control-key bindings a raw-mode terminal delivers verbatim (it deliberately
avoids the flow-control keys Ctrl-S/Ctrl-Q and the signal keys Ctrl-C/Ctrl-Z):

| Key | Action | Key | Action |
|-----|--------|-----|--------|
| `Ctrl-W` | save | `Ctrl-X` | exit |
| `Ctrl-B` / `Ctrl-F` | left / right | `Ctrl-P` / `Ctrl-N` | up / down |
| `Ctrl-A` / `Ctrl-E` | line start / end | Backspace / `Ctrl-D` | delete left / right |

Enter inserts a newline; printable keys insert; arrow keys also work. Saving is atomic (writes a
temp file then replaces the target), so a failed save never corrupts the original; files larger than
the 8 KB buffer are refused rather than truncated.

### BASIC interpreter

`BASIC <file>` loads a line-numbered, ASCII BASIC program (default extension `.BAS`) and runs it.
A rudimentary subset in the spirit of the `BASIC.COM` that shipped with MS-DOS 1.25:

- statements: `PRINT` (`;`/`,` separators, trailing `;` suppresses newline), `LET`/bare assignment,
  `IF…THEN` (a line number or a statement), `GOTO`, `FOR…TO…STEP`/`NEXT`, `INPUT`, `REM`, `END`/`STOP`
- numeric and string (`A$`) variables
- expressions: `+ - * /`, parentheses, comparisons `= <> < <= > >=`, string concatenation with `+`

Author a program with `EDIT prog.bas`, then run it with `BASIC prog` (the `.BAS` extension is the
default). This self-test exercises every feature of the dialect:

```basic
10 REM --- BASIC SELF-TEST ---
20 PRINT "BASIC SELF-TEST"
30 A = 6
40 B = 7
50 PRINT "A*B ="; A * B
60 PRINT "MATH:"; 2 + 3 * 4; (2 + 3) * 4
70 S = 0
80 FOR I = 1 TO 10
90 S = S + I
100 NEXT I
110 PRINT "SUM 1..10 ="; S
120 PRINT "COUNTDOWN:";
130 FOR J = 5 TO 1 STEP -2
140 PRINT J;
150 NEXT J
160 PRINT
170 F$ = "HELLO"
180 L$ = "WORLD"
190 PRINT F$ + " " + L$
200 IF S = 55 THEN PRINT "SUM OK"
210 IF F$ <> L$ THEN PRINT "DIFFERENT"
220 N = 0
230 PRINT "GOTO:";
240 N = N + 1
250 PRINT N;
260 IF N < 3 THEN GOTO 240
270 PRINT
280 PRINT "DONE"
290 END
```

Output:

```
BASIC SELF-TEST
A*B = 42
MATH: 14 20
SUM 1..10 = 55
COUNTDOWN: 5 3 1
HELLO WORLD
SUM OK
DIFFERENT
GOTO: 1 2 3
DONE
```

| Command | DOS calls used | Action |
|---------|----------------|--------|
| `dir` | SEARCH FIRST/NEXT (11h/12h) | list files with sizes |
| `type <file>` | OPEN + SEQ READ (0Fh/14h) | print a file |
| `write <file> <text>` | CREATE + SEQ WRITE + CLOSE (16h/15h/10h) | create a file from text |
| `del <file>` | DELETE (13h) | delete a file |
| `help` / `quit` | — | help / exit (saves) |

```
A>ver
MS-DOS 1.25 (C port)
A>copy readme.txt backup.txt
    1 file(s) copied
A>dir
README.TXT           38
BACKUP.TXT           38
    2 file(s)
```

Control keys: **Ctrl-C / Ctrl-Q** quit, **Ctrl-D** quits on an empty line.

### Low-level disk monitor (`--monitor`)

```sh
./wrapper --monitor <image> [sector_count] [sector_size]
```

A raw sector/hex view of an image, independent of any filesystem. If the image does not exist it is
created (zero-filled); on exit it is saved back. Useful for inspecting what the kernel wrote.

| Command | Action |
|---------|--------|
| `h` / `i` | help / image info |
| `r <lba>` | read + hex-dump a sector |
| `w <lba> <text>` | write text into a sector |
| `format` | format the image as FAT12 (geometry auto-detected) |
| `f` / `c` / `q` | flush now / clear screen / quit (saves) |

## The ported kernel (`src/kernel/`)

A compact C port of the `MSDOS.ASM` filesystem and system-call core, built **bottom-up** — each
layer has its own unit-test suite that passes before the next is started. Scope matches MS-DOS 1.x
(FCB file API, single root directory, no subdirectories/`EXEC`).

| Layer | Module | Ports (MSDOS.ASM) | Tests |
|-------|--------|-------------------|-------|
| 1 — FAT12 arithmetic | `fat.{h,c}` | `UNPACK`/`PACK`/`ALLOCATE`/`FNDCLUS` | `test_fat` |
| 2 — Volume / DPB | `volume.{h,c}` | `DPBLOCK`, FAT load/flush | `test_volume` |
| 3 — Directory | `dir.{h,c}` | `SRCHFRST`/`SRCHNXT`, 32-byte entries | `test_dir` |
| 4 — Files | `kfile.{h,c}` | OPEN/CREATE/CLOSE/DELETE/RENAME, seq R/W | `test_kfile` |
| 5 — DOS dispatch | `dos.{h,c}` | `ENTRY`/`DISPATCH`, char I/O, FCB calls | `test_dos` |
| Command processor | `command.{h,c}` | `COMMAND.ASM` (prompt/parse/dispatch) | `test_command` |

See `REFERENCE.md` Part 3 for the per-layer technical detail and APIs.

---

## Demo disk

`make demo` builds `demo.img` from the BASIC programs in `demo/` and boots the kernel on it. The
disk holds `HELLO.BAS`, `MATH.BAS` (multiplication tables), `CALC.BAS` (a four-function calculator),
`GUESS.BAS` (a two-player guessing game), `README.TXT`, and `BASIC.TXT` (a manual for the BASIC
dialect). At the `A>` prompt:

```
A>dir
A>basic calc          run the calculator
A>basic guess         play the game
A>type basic.txt      read the BASIC language manual
A>type readme.txt     read the disk's readme
```

The image is built by `tools/mkdemo.c` (`make demo-disk`), which formats a 360 KB FAT12 image and
copies the host files in through the kernel — so it is exactly what `./wrapper demo.img` reads. Edit
the programs in `demo/` and rerun `make demo-disk` to rebuild.

## Documentation

- **`REFERENCE.md`** — technical reference: the original DOS source (Part 1), the C wrapper
  (Part 2), and the ported kernel layers and APIs (Part 3).
- **`ASM_TO_C_PORTING_REFERENCE.md`** — how to translate the 8086 assembly to C: registers,
  calling conventions, data structures, instruction idioms.

## Requirements

A C11 compiler (`cc`/`clang`/`gcc`) and a POSIX terminal (`termios`). No external dependencies.
Tested on macOS; portable to Linux.
