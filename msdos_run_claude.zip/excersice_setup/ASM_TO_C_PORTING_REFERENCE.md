# 8086 Assembly → C Porting Reference

A working reference for porting the **MS-DOS 1.25** sources in `v1.25/source/`
(8086 assembly) to C. It explains the 8086 execution model, the instruction and
mnemonic vocabulary actually used in these files, the calling conventions and data
structures the code relies on, and the idiomatic C each maps to.

> Scope note: the kernel/shell files (`MSDOS.ASM`, `COMMAND.ASM`, `IO.ASM`, `ASM.ASM`)
> use mostly MASM-style mnemonics; `HEX2BIN.ASM` and `TRANS.ASM` use the older
> **Seattle Computer Products (SCP) assembler** shorthand (`MOVB`, `LODB`, `UP`, …).
> Both vocabularies are covered — see the [SCP mnemonic glossary](#9-scp-assembler-mnemonic-glossary).

---

## 1. The 8086 programming model in C terms

The 8086 is a 16-bit CPU. Every register is 16 bits; memory is addressed as
`segment:offset`. When porting, the first job is to stop thinking in registers and
start thinking in **named variables and struct fields** — the register is just where
the value happened to live.

### 1.1 General-purpose registers

| Reg | Halves | Typical role in this code | C analogue |
|-----|--------|---------------------------|------------|
| `AX` | `AH`,`AL` | Accumulator; **`AH` = DOS function number**, `AL` = return/char | `uint16_t ax;` (often the return value) |
| `BX` | `BH`,`BL` | Base/pointer for memory & dispatch (`[BX+DISPATCH]`) | pointer or array index |
| `CX` | `CH`,`CL` | Loop counter (`LOOP`, `REP`); `CL` = shift count; CP/M func # | `int count;` / shift amount |
| `DX` | `DH`,`DL` | Address of a buffer/string passed to DOS; I/O port number | pointer arg, or port id |
| `SI` | — | Source index for string ops | `const T *src;` |
| `DI` | — | Destination index for string ops | `T *dst;` |
| `BP` | — | Frame base — here used to index the **saved-register block** (`[BP.AXSAVE]`) | `struct regs *r;` |
| `SP` | — | Stack pointer | the C stack (don't model directly) |

`AX`/`BX`/`CX`/`DX` are byte-addressable: `AH` is the high byte, `AL` the low byte of
`AX`. In C: `al = ax & 0xFF; ah = ax >> 8;` Treat a 16-bit register as
`uint16_t` and slice bytes explicitly.

### 1.2 Segment registers and the memory model

| Reg | Meaning |
|-----|---------|
| `CS` | Code segment |
| `DS` | Data segment (default for `[BX]`, `[SI]` …) |
| `ES` | Extra segment (default for string destinations `[DI]`) |
| `SS` | Stack segment |

A physical address is `segment * 16 + offset` (segments are paragraph-aligned, 16
bytes). A *far pointer* is the pair `(segment, offset)`; a *near pointer* is just the
offset within an implied segment.

In the kernel, `DS = CS = ES = SS = DOSGROUP` while DOS runs (one combined group of
`CODE`+`CONSTANTS`+`DATA`), and the user's `SS:SP` is saved/restored around every call.
So for porting **the kernel's own data**, segments collapse to a single flat space —
model it as plain C globals/structs. Segments matter only at the boundaries: the user
program's buffer (`DS:DX`), and the BIOS segment (`SEGBIOS` at `40H`/`60H`).

**Porting rule of thumb**
- Within one module, ignore segments → ordinary C pointers/objects.
- Cross-boundary data (user buffer, device memory) → a small `struct { uint16_t seg, off; }`
  far pointer, or a helper `void* phys(seg,off){ return base + (seg<<4) + off; }`.

### 1.3 FLAGS and conditional branches

Arithmetic/logic instructions set flags; the next `Jcc` branches on them. Don't model
the flags register — translate the **compare + jump pair** into one C condition.

| Jump | Taken when | Signedness | C condition for `CMP a,b` |
|------|-----------|------------|---------------------------|
| `JZ`/`JE` | ZF=1 | — | `a == b` |
| `JNZ`/`JNE` | ZF=0 | — | `a != b` |
| `JC`/`JB`/`JNAE` | CF=1 | unsigned | `a < b` |
| `JNC`/`JAE`/`JNB` | CF=0 | unsigned | `a >= b` |
| `JA`/`JNBE` | CF=0&ZF=0 | unsigned | `a > b` |
| `JBE`/`JNA` | CF=1 or ZF=1 | unsigned | `a <= b` |
| `JL`/`JNGE` | SF≠OF | signed | `a < b` |
| `JLE`/`JNG` | ZF=1 or SF≠OF | signed | `a <= b` |
| `JG`/`JNLE` | ZF=0&SF=OF | signed | `a > b` |
| `JGE`/`JNL` | SF=OF | signed | `a >= b` |
| `JS` | SF=1 | — | result `< 0` (high bit set) |
| `JNS` | SF=0 | — | result `>= 0` |

> Critical porting hazard: `JC/JNC/JA/JBE` are **unsigned**, `JL/JG/JLE/JGE` are
> **signed**. Pick `uint16_t` vs `int16_t` in C to match, or the comparison flips.
> The code uses `JS` (e.g. `MSDOS.ASM:723`) to test "high bit set" flags like the FCB
> `DEVID` file/device bit — that is a bit test, not a magnitude compare.

`CMP`/`TEST` set flags without storing; `TEST a,mask` is `(a & mask)` discarded → in C
`if (a & mask)`. `OR a,a` / `AND a,a` is the classic "is it zero / what's the sign"
idiom: `if (a == 0)` / `if ((int16_t)a < 0)`.

---

## 2. Instruction set → C semantics

Grouped by what they do. `D` = destination, `S` = source.

### Data movement
| Asm | C |
|-----|---|
| `MOV D,S` | `D = S;` |
| `XCHG D,S` | `t = D; D = S; S = t;` |
| `PUSH r` / `POP r` | save/restore — usually a C local, not modeled |
| `LEA D,[mem]` | `D = &mem;` (compute address, don't dereference) |
| `XLAT` | `AL = table[AL];` |

### Arithmetic / logic
| Asm | C |
|-----|---|
| `ADD D,S` / `SUB D,S` | `D += S;` / `D -= S;` |
| `ADC`/`SBB` | add/sub **with carry** → use a wider temp to capture carry-in |
| `INC`/`DEC` | `D++;` / `D--;` (note: do **not** affect CF) |
| `NEG D` | `D = -D;` |
| `CMP D,S` | sets flags for a following `Jcc` (see §1.3) |
| `AND/OR/XOR/NOT` | `&  |  ^  ~` |
| `MUL S` / `IMUL` | `AX = AL*S` (8-bit) or `DX:AX = AX*S` (16-bit), unsigned/signed |
| `DIV S` / `IDIV` | `AL = AX/S, AH = AX%S` (8-bit); `AX = DXAX/S, DX = rem` (16-bit) |
| `CBW` / `CWD` | sign-extend `AL→AX` / `AX→DX:AX`: `(int16_t)(int8_t)al` |

### Shifts / rotates
| Asm | C |
|-----|---|
| `SHL D,n` | `D <<= n;`  (also a fast `*2`) |
| `SHR D,n` | `D >>= n;` on **unsigned** D (logical) |
| `SAR D,n` | `D >>= n;` on **signed** D (arithmetic) |
| `ROL/ROR` | rotate — `(D<<n)|(D>>(w-n))` masked to width |
| `RCL/RCR` | rotate **through carry** — used to shuttle a bit between words; model the carry bit explicitly. The 12-bit FAT `UNPACK`/`PACK` uses `SHR/SHL` by `CL=4`, not RCL. |

### Decimal / BCD
| Asm | C |
|-----|---|
| `AAM` | `AH = AL/10; AL = AL%10;` (split a byte into two decimal digits) — used for number formatting |
| `AAD` | `AL = AH*10 + AL; AH = 0;` |
| `DAA`/`DAS` | BCD add/subtract fixups |

### Control flow
| Asm | C |
|-----|---|
| `JMP` / `JMPS` (short) | `goto` |
| `Jcc` | `if (cond) goto …;` (see §1.3) |
| `LOOP lbl` | `if (--CX) goto lbl;` → `for (; cx; cx--)` |
| `CALL` / `RET` | function call / return |
| `CALL CS:[BX+DISPATCH]` | **indirect call through a table** → `dispatch[fn]()` (function-pointer array) |
| `INT n` / `IRET` | software interrupt = a "system call" to another layer; see §3 |

### String / block operations (with `REP` prefix)
The direction flag picks ascending (`CLD`/`UP`) or descending (`STD`/`DN`).
| Asm | C (forward) |
|-----|-------------|
| `MOVSB`/`MOVSW` (`MOVB`/`MOVW`) | `*dst++ = *src++;` |
| `REP MOVSB` | `memcpy(dst, src, cx);` |
| `STOSB`/`STOSW` (`STOB`/`STOW`) | `*dst++ = al;` |
| `REP STOSB` | `memset(dst, al, cx);` |
| `LODSB`/`LODSW` (`LODB`/`LODW`) | `al = *src++;` |
| `SCASB` (`SCAB`) | `cmp(al, *dst++)` — scan |
| `REPNE SCASB` | `memchr`-style search until match or `cx==0` |
| `CMPSB` | `cmp(*src++, *dst++)` → `memcmp` loop |

### Port I/O (hardware — lives in `IO.ASM`)
| Asm | Meaning |
|-----|---------|
| `IN AL,dx` / `INB` | read a byte from hardware port `DX` |
| `OUT dx,AL` / `OUTB` | write a byte to hardware port `DX` |
| `STI`/`CLI` (`EI`/`DI`) | enable/disable interrupts |

Port I/O does not exist in portable C — wrap each as `uint8_t inb(uint16_t port)` /
`void outb(uint16_t port, uint8_t v)` backed by the real platform (or a device model).
This is the natural HAL seam: everything in `IO.ASM` becomes a driver interface.

### Flag-register moves
`LAHF`/`SAHF` load/store the low flags into `AH`; the code uses them to **stash a
condition across other work** (carry = error). In C, hold the boolean in a variable
instead of relaying it through a register.

---

## 3. Calling conventions used in this project

There is no single C-style convention; there are three layers. Identify which one a
routine belongs to before porting it.

### 3.1 The DOS system-call interface (`INT 21H`)
The public API. The caller puts a **function number in `AH`**, arguments in other
registers (`DX` usually points at an FCB or buffer, `AL`/`CX`/`DX` carry scalars), and
executes `INT 21H`. `MSDOS.ASM` dispatches through the `DISPATCH` table
(`MSDOS.ASM:349`), indexed by `AH`:

```
MOV  BL,AH        ; function number
SHL  BX,1         ; *2 for word table
CALL CS:[BX+DISPATCH]
```

C model — one function per call, plus a dispatcher:

```c
typedef int (*dos_fn)(struct dos_regs *r);
static const dos_fn dispatch[] = { sys_abort, sys_conin, sys_conout, /* … */ };

int dos_int21(struct dos_regs *r) {
    uint8_t fn = r->ah;
    if (fn > MAXCALL) return bad_call(r);
    return dispatch[fn](r);          /* CALL CS:[BX+DISPATCH] */
}
```

Each handler reads/writes fields of a `struct dos_regs` that mirrors the saved-register
block (see §3.3) rather than touching real registers.

### 3.2 The CP/M-compatibility entry (`CALL 5` / `ENTRY`)
For CP/M-ported programs: function number in **`CL`**, invoked by `CALL 5`. `ENTRY`
(`MSDOS.ASM:277`) reorders the stack to look like an `INT`, copies `CL→AH`, and joins
the same dispatcher. Port it as a thin shim: `r->ah = r->cl; return dos_int21(r);`.

### 3.3 Register save/restore (the implicit "stack frame")
On entry the dispatcher pushes every register into a fixed block and later reads them
back by name via `BP`:

```
SAVREGS: PUSH ES,DS,BP,DI,SI,DX,CX,BX,AX   ; (one PUSH each)
…
MOV BYTE PTR [BP.AXSAVE],AL                ; write result back into the saved AX
```

This block **is** the C argument/return struct. Define it once and pass a pointer:

```c
struct dos_regs {                 /* order matches the PUSH sequence */
    uint16_t ax, bx, cx, dx, si, di, bp, ds, es;
    union { struct { uint8_t al, ah; }; uint16_t _ax; };  /* byte access */
};
```

`[BP.AXSAVE]` is **struct-field addressing** (`STRUC` member offset off `BP`); it ports
directly to `r->ax`. Most routines have no other locals beyond registers, so they
become straightforward functions taking `struct dos_regs *`.

### 3.4 Internal helper calls
Internal routines (`UNPACK`, `FNDCLUS`, `ALLOCATE`, `FATREAD`, …) pass arguments in
registers by ad-hoc agreement and return in registers/CF. Port each to a normal C
function with explicit parameters and return value; **carry-set-on-error** becomes a
returned status code or a `bool ok`.

---

## 4. Project data structures → C structs

These are defined by `STRUC` in `MSDOS.ASM`. The byte layout is contractual (it is the
on-disk and in-memory format), so port them as **packed** structs with fixed-width types.

### 4.1 File Control Block (`FCBLOCK`, `MSDOS.ASM:78`)
```c
#pragma pack(push,1)
struct fcb {
    uint8_t  drive_name[12];  /* drive code + 8.3 name            */
    uint16_t extent;
    uint16_t recsiz;          /* record size (user-settable)      */
    uint16_t filsiz;          /* file size in bytes               */
    uint16_t drvbp;           /* BP saved for SEARCH FIRST/NEXT    */
    uint16_t fdate, ftime;    /* last-write date/time (packed)     */
    uint8_t  devid;           /* bit7: 1=device,0=file; bit6 dirty/EOF */
    uint16_t firclus;         /* first cluster                    */
    uint16_t lstclus;         /* last cluster accessed (cache)     */
    uint16_t cluspos;         /* position of that cluster (cache)  */
    uint8_t  _pad;            /* "Forces NR to offset 32"          */
    uint8_t  nr;              /* next record                       */
    uint8_t  rr[3];           /* random record                    */
};
#pragma pack(pop)
```
The `_pad` byte is deliberate — keep it so `nr` lands at offset 32 exactly as the asm
comment requires. The `LSTCLUS`/`CLUSPOS` fields are a cluster-walk cache so `FNDCLUS`
need not re-traverse the chain from the start.

### 4.2 Directory entry (32 bytes, documented at `MSDOS.ASM:99`)
```c
#pragma pack(push,1)
struct dir_entry {
    uint8_t  name[11];        /* 8.3; 0xE5 = empty, 0x00 = end-of-dir (1.25!) */
    uint8_t  attr;            /* bits 1..2 => hidden               */
    uint8_t  reserved[10];
    uint16_t time;            /* bits0-4 sec/2, 5-10 min, 11-15 hr */
    uint16_t date;            /* bits0-4 day, 5-8 month, 9-15 yr-1980 */
    uint16_t first_cluster;
    uint32_t size;            /* LSB first, 30-bit max             */
};
#pragma pack(pop)
```

### 4.3 Drive Parameter Block (`DPBLOCK`, `MSDOS.ASM:128`)
```c
#pragma pack(push,1)
struct dpb {
    uint8_t  devnum, drvnum;
    uint16_t secsiz;          /* bytes/sector              */
    uint8_t  clusmsk;         /* sectors/cluster - 1       */
    uint8_t  clusshft;        /* log2(sectors/cluster)     */
    uint16_t firfat;          /* first FAT sector          */
    uint8_t  fatcnt;          /* number of FAT copies      */
    uint16_t maxent;          /* directory entries         */
    uint16_t firrec;          /* first data sector         */
    uint16_t maxclus;         /* clusters + 1              */
    uint8_t  fatsiz;          /* FAT size in sectors       */
    uint16_t firdir;          /* directory start sector    */
    uint16_t fat;             /* pointer to in-memory FAT  */
};
#pragma pack(pop)
```

### 4.4 The 12-bit FAT — `UNPACK`/`PACK` (`MSDOS.ASM:448`/`:484`)
Two entries per three bytes. The asm computes `addr = FAT + N + N/2`, loads a word, and
shifts right 4 if `N` is odd. In C:

```c
uint16_t fat_get(const uint8_t *fat, uint16_t n) {     /* UNPACK */
    uint16_t w = fat[n + n/2] | (fat[n + n/2 + 1] << 8);
    return (n & 1) ? (w >> 4) : (w & 0x0FFF);
}
void fat_set(uint8_t *fat, uint16_t n, uint16_t val) { /* PACK */
    uint16_t i = n + n/2, w = fat[i] | (fat[i+1] << 8);
    w = (n & 1) ? ((w & 0x000F) | (val << 4))
                : ((w & 0xF000) | (val & 0x0FFF));
    fat[i] = w & 0xFF; fat[i+1] = w >> 8;
}
```
Sentinels: `0` = free, `>0FF8H` = end-of-file, cluster 0/1 reserved, data starts at
cluster 2. `FNDCLUS` walks `next = fat_get(...)` until an EOF marker.

---

## 5. Idiom → C pattern cheatsheet

| 8086 idiom | Intent | C |
|------------|--------|---|
| `XOR AX,AX` | zero a register | `ax = 0;` |
| `OR AX,AX` / `AND AX,AX` then `JZ` | test for zero | `if (ax == 0)` |
| `SHL BX,1` before table index | scale index by element size | `&table[i]` (compiler scales) |
| `SHL/SHR ...,CL` with `CL=4` | ×16 / ÷16 (nibble shift) | `<<4` / `>>4` |
| `MOV CX,n` + `LOOP` | counted loop | `for (i=n; i; i--)` |
| `REP MOVSB` | block copy | `memcpy` |
| `REP STOSB` | block fill | `memset` |
| `REPNE SCASB` | find byte / strlen | `memchr` / `strlen` |
| `CMP AL,' '` / `0E5H` / `00` | parse FCB / scan directory | compare to the named sentinel constant |
| `LAHF … SAHF` | carry-error across calls | `bool err` variable |
| `AAM` | byte → two decimal digits | `q=al/10; r=al%10;` |
| `CALL CS:[BX+DISPATCH]` | jump table | function-pointer array |
| self-overwriting transient (`COMMAND.ASM`) | reclaim memory; checksum-reload | a normal module load; don't replicate the overlay trick |

---

## 6. Porting hazards specific to 16-bit DOS asm

- **16-bit wraparound is intentional.** `INC SI` past `0xFFFF` wraps; offsets wrap
  within a 64 KB segment. Use `uint16_t` arithmetic where the code depends on this; do
  **not** widen to `int`/`size_t` blindly or wrap-dependent logic breaks.
- **Signed vs unsigned follows the jump, not the type.** There are no C types in asm —
  the *branch* (`JB` vs `JL`) tells you the intended signedness (§1.3). Choose the C type
  to match each comparison.
- **`INC`/`DEC` preserve carry**; `ADD`/`SUB` set it. Loops that test CF after `INC` rely
  on this. Track flags only where a branch actually reads them.
- **Direction flag is global state.** `CLD`/`STD` (`UP`/`DN`) set the string direction
  once and many ops inherit it. When you split a `REP` block into `memcpy`/`memmove`,
  honor the direction (descending overlap → `memmove`).
- **Segment register reloads** (`MOV SP,CS` / `MOV SS,SP`) are stack switches between the
  user stack and the DOS `IOSTACK`/`DSKSTACK`. In C you simply call functions; drop the
  manual stack juggling, but preserve the *reentrancy boundary* it protected.
- **Interrupt vectors as the ABI.** `INT 20H/21H/22H/23H/24H/27H` are the contract with
  user programs and handlers. Model them as explicit function entry points / callbacks,
  and keep the documented register semantics at those boundaries.
- **`CS:`-relative data** (`CS:[TEMP]`, `CS:[SPSAVE]`) is just module-private global state
  because code and data share `DOSGROUP`. Port to `static` globals.

---

## 7. Suggested module mapping

| Asm file | C target | Notes |
|----------|----------|-------|
| `MSDOS.ASM` | `dos_kernel.c` + `fat.c` + `fcb.c` | split the dispatcher, FAT, and FCB logic |
| `COMMAND.ASM` | `command.c` | drop the resident/transient overlay split; one program |
| `IO.ASM` | `hal.h` + a backend (`hal_pc.c`, `hal_sim.c`) | every `IN`/`OUT`/disk routine becomes a driver call |
| `ASM.ASM` / `TRANS.ASM` / `HEX2BIN.ASM` | leave as build tools, or port last | not part of the OS runtime |

Recommended order: (1) define the structs in §4 and the HAL in §2/§6; (2) port the
self-contained helpers (`UNPACK`/`PACK`, `FNDCLUS`, `ALLOCATE`, FAT/dir I/O); (3) port the
`INT 21H` handlers one dispatch slot at a time against `struct dos_regs`; (4) port
`COMMAND.COM`; (5) wire a HAL backend so you can run and test on a host.

---

## 8. The DOS interrupt entry points (the C-visible ABI)

| Vector | Name | C entry point |
|--------|------|---------------|
| `INT 20H` | `QUIT` — terminate program | `void dos_terminate(void);` |
| `INT 21H` | `COMMAND` — system call (dispatch on `AH`) | `int dos_int21(struct dos_regs*);` |
| `CALL 5`  | `ENTRY` — CP/M call (dispatch on `CL`) | shim → `dos_int21` |
| `INT 22H` | terminate address (COMMAND) | callback |
| `INT 23H` | Ctrl-C handler | callback |
| `INT 24H` | fatal/critical error (`HARDERR`) | `int dos_critical_error(...)` returning the user's action |
| `INT 27H` | terminate-and-stay-resident | n/a in a hosted port |

---

## 9. SCP assembler mnemonic glossary

`HEX2BIN.ASM` and `TRANS.ASM` use the older SCP 8086 assembler, whose mnemonics differ
from MASM. Translate as follows (some also appear in `MSDOS.ASM`, e.g. `JMPS`):

| SCP mnemonic | Standard 8086 | Meaning / C |
|--------------|---------------|-------------|
| `MOVB` / `MOVW` | `MOVSB` / `MOVSW` | `*dst++ = *src++;` (byte/word) |
| `LODB` / `LODW` | `LODSB` / `LODSW` | `al/ax = *src++;` |
| `STOB` / `STOW` | `STOSB` / `STOSW` | `*dst++ = al/ax;` |
| `SCAB` / `SCAW` | `SCASB` / `SCASW` | scan/compare `*dst++` |
| `REP` / `REPNZ` | same | repeat prefix; `REPNZ` = repeat while not equal |
| `UP` / `DN` | `CLD` / `STD` | set string direction forward / backward |
| `JMPS` | `JMP SHORT` | `goto` (short) |
| `INB` / `OUTB` | `IN AL,DX` / `OUT DX,AL` | byte port read/write |
| `EI` / `DI` | `STI` / `CLI` | enable / disable interrupts |
| `CBW` | `CBW` | sign-extend `AL → AX` |
| `ORG` / `PUT` | — | set assembly origin / output load address (build directive) |

Common assembler directives seen across the files: `EQU` (constant), `DB`/`DW` (define
byte/word data), `STRUC`/`ENDS` (record layout → C struct), `SEGMENT`/`GROUP` (linkage),
`IF`/`ENDIF` (conditional assembly → `#if`), `INCLUDE` (`#include`), and the `name.field`
syntax for struct-member offsets (→ `obj->field`).
