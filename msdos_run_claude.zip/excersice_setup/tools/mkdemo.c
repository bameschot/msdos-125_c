/* mkdemo.c - build a FAT12 demo disk image and copy host files into it.
 *
 * usage: mkdemo <image> <hostfile>...
 *
 * Creates a fresh 360 KB FAT12 image, then writes each host file into it as an
 * 8.3 file (the FAT name comes from the host basename, upper-cased by the
 * directory layer). Uses the same kernel modules as the wrapper, so the disk
 * is exactly what `./wrapper <image>` will read.
 */
#include <stdio.h>
#include <string.h>

#include "../src/disk.h"
#include "../src/fat12.h"
#include "../src/kernel/kfile.h"
#include "../src/kernel/kfs.h"
#include "../src/kernel/volume.h"

static const char *basename_of(const char *p) {
    const char *b = strrchr(p, '/');
    return b ? b + 1 : p;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr, "usage: %s <image> <hostfile>...\n", argv[0]);
        return 2;
    }
    const char *image = argv[1];

    if (fat12_create_image(image, "360") != DISK_OK) {
        fprintf(stderr, "cannot create image '%s'\n", image);
        return 1;
    }
    disk_t d;
    if (disk_open(&d, image, 512) != DISK_OK) { fprintf(stderr, "open failed\n"); return 1; }
    volume_t v;
    if (volume_mount(&v, &d) != DISK_OK) { fprintf(stderr, "mount failed\n"); return 1; }

    int errors = 0;
    for (int i = 2; i < argc; i++) {
        FILE *f = fopen(argv[i], "rb");
        if (!f) { fprintf(stderr, "skip %s: cannot open\n", argv[i]); errors++; continue; }
        static char buf[16384];
        size_t n = fread(buf, 1, sizeof buf, f);
        fclose(f);

        const char *name = basename_of(argv[i]);
        kfile_t kf;
        if (kfile_create(&v, name, &kf) != KFS_OK) {
            fprintf(stderr, "skip %s: cannot create on image\n", name); errors++; continue;
        }
        if (n > 0 && kfile_write(&kf, buf, (uint32_t)n) != KFS_OK) {
            fprintf(stderr, "write failed for %s\n", name); errors++;
        }
        kfile_close(&kf);
        printf("  added %-12s %6zu bytes\n", name, n);
    }

    volume_flush(&v);
    volume_unmount(&v);
    disk_close(&d);
    printf("created %s\n", image);
    return errors ? 1 : 0;
}
