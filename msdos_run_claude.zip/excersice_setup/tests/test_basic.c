/* test_basic.c - the rudimentary BASIC interpreter. Programs are run with a
 * stub console; output (and any error message) is captured and checked. */
#include "../src/kernel/basic.h"
#include "../src/kernel/dos.h"

#include <stdio.h>
#include <string.h>

static int g_failures = 0, g_checks = 0;
#define CHECK(c, m) do { g_checks++; if (c) printf("  PASS: %s\n", (m)); \
    else { printf("  FAIL: %s  (%s:%d)\n", (m), __FILE__, __LINE__); g_failures++; } } while (0)

typedef struct { const char *in; size_t inpos; char out[8192]; size_t outlen; } stub_con;
static int  sgk(void *x) { stub_con *c = x; return c->in && c->in[c->inpos] ? (unsigned char)c->in[c->inpos++] : -1; }
static void spc(void *x, char ch) { stub_con *c = x; if (c->outlen < sizeof(c->out) - 1) c->out[c->outlen++] = ch; c->out[c->outlen] = 0; }

/* Run a program (with optional console input) and return captured output. */
static char g_out[8192];
static const char *run(const char *prog, const char *input) {
    static char buf[16384];
    size_t len = strlen(prog);
    memcpy(buf, prog, len); buf[len] = 0;
    stub_con sc; memset(&sc, 0, sizeof(sc)); sc.in = input;
    console_t con = { sgk, spc, NULL, &sc };
    dos_t dos; dos_init(&dos, NULL, &con);
    basic_run(&dos, buf, len);
    memcpy(g_out, sc.out, sizeof(g_out));
    return g_out;
}
static int has(const char *hay, const char *needle) { return strstr(hay, needle) != NULL; }

static void test_print_and_expr(void) {
    printf("test_print_and_expr\n");
    const char *o = run("10 PRINT \"HELLO, WORLD\"\n", NULL);
    CHECK(has(o, "HELLO, WORLD"), "PRINT a string literal");

    o = run("10 PRINT 2+3*4\n20 PRINT (2+3)*4\n30 PRINT 10/4\n", NULL);
    CHECK(has(o, " 14"), "operator precedence: 2+3*4 = 14");
    CHECK(has(o, " 20"), "parentheses: (2+3)*4 = 20");
    CHECK(has(o, " 2.5"), "division yields 2.5");

    o = run("10 PRINT \"A=\"; 1; \" B=\"; 2\n", NULL);
    CHECK(has(o, "A= 1 B= 2"), "; separators concatenate with numeric lead space");
}

static void test_variables(void) {
    printf("test_variables\n");
    const char *o = run("10 LET X = 5\n20 Y = X * 2\n30 PRINT Y\n", NULL);
    CHECK(has(o, " 10"), "LET and bare assignment, numeric variable");

    o = run("10 A$ = \"HEL\"\n20 B$ = \"LO\"\n30 PRINT A$ + B$\n", NULL);
    CHECK(has(o, "HELLO"), "string variables and concatenation");
}

static void test_for_next(void) {
    printf("test_for_next\n");
    const char *o = run(
        "10 FOR I = 1 TO 3\n"
        "20 PRINT \"I=\"; I\n"
        "30 NEXT I\n", NULL);
    CHECK(has(o, "I= 1") && has(o, "I= 2") && has(o, "I= 3"), "FOR/NEXT iterates 1..3");
    CHECK(!has(o, "I= 4"), "FOR/NEXT stops at the limit");

    o = run(
        "10 S = 0\n"
        "20 FOR K = 1 TO 5\n"
        "30 S = S + K\n"
        "40 NEXT K\n"
        "50 PRINT \"SUM=\"; S\n", NULL);
    CHECK(has(o, "SUM= 15"), "FOR/NEXT accumulates a sum");

    o = run(
        "10 FOR J = 10 TO 1 STEP -3\n"
        "20 PRINT J;\n"
        "30 NEXT J\n", NULL);
    CHECK(has(o, " 10 7 4 1"), "FOR/NEXT with negative STEP");
}

static void test_if_goto(void) {
    printf("test_if_goto\n");
    const char *o = run(
        "10 I = 0\n"
        "20 I = I + 1\n"
        "30 PRINT I;\n"
        "40 IF I < 3 THEN GOTO 20\n"
        "50 PRINT \"DONE\"\n", NULL);
    CHECK(has(o, " 1 2 3"), "GOTO loop counts to 3");
    CHECK(has(o, "DONE"), "falls through when condition is false");

    o = run("10 IF 5 = 5 THEN PRINT \"EQ\"\n20 IF 5 <> 5 THEN PRINT \"NE\"\n", NULL);
    CHECK(has(o, "EQ") && !has(o, "NE"), "IF/THEN with comparison operators");
}

static void test_input(void) {
    printf("test_input\n");
    const char *o = run(
        "10 INPUT \"NAME\"; N$\n"
        "20 PRINT \"HI \"; N$\n", "BOB\r");
    CHECK(has(o, "HI BOB"), "INPUT reads a string into a variable");

    o = run("10 INPUT X\n20 PRINT X * 2\n", "21\r");
    CHECK(has(o, " 42"), "INPUT reads a number");
}

static void test_errors(void) {
    printf("test_errors\n");
    const char *o = run("10 PRINT 1/0\n", NULL);
    CHECK(has(o, "DIVISION BY ZERO") && has(o, "IN 10"), "division by zero reports an error with line");

    o = run("10 GOTO 99\n", NULL);
    CHECK(has(o, "UNDEF'D LINE"), "GOTO to a missing line errors");

    o = run("10 PRINT \"A\"\n20 END\n30 PRINT \"B\"\n", NULL);
    CHECK(has(o, "A") && !has(o, "B"), "END halts the program");
}

static void test_line_ordering(void) {
    printf("test_line_ordering\n");
    /* lines given out of order must run in line-number order */
    const char *o = run("30 PRINT \"3\"\n10 PRINT \"1\"\n20 PRINT \"2\"\n", NULL);
    CHECK(strstr(o, "1") < strstr(o, "2") && strstr(o, "2") < strstr(o, "3"),
          "program runs in line-number order regardless of source order");
}

int main(void) {
    printf("== Rudimentary BASIC interpreter ==\n");
    test_print_and_expr();
    test_variables();
    test_for_next();
    test_if_goto();
    test_input();
    test_errors();
    test_line_ordering();
    printf("\n%d checks, %d failure(s)\n", g_checks, g_failures);
    return g_failures ? 1 : 0;
}
