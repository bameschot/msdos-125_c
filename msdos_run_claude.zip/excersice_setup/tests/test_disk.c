/* test_disk.c - unit tests for the disk image module.
 *
 * No test framework: each check prints PASS/FAIL and the process exits
 * non-zero if any check failed. The terminal module is intentionally not
 * tested here because it requires a TTY.
 */
#include "../src/disk.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_failures = 0;
static int g_checks = 0;

#define CHECK(cond, msg) do {                                   \
    g_checks++;                                                 \
    if (cond) {                                                 \
        printf("  PASS: %s\n", (msg));                          \
    } else {                                                    \
        printf("  FAIL: %s  (%s:%d)\n", (msg), __FILE__, __LINE__); \
        g_failures++;                                           \
    }                                                           \
} while (0)

#define TMP_IMG  "test_disk.img"
#define SECSZ    512u
#define NSEC     16u

static void test_create_and_fields(void) {
    printf("test_create_and_fields\n");
    disk_t d;
    int rc = disk_create(&d, TMP_IMG, SECSZ, NSEC);
    CHECK(rc == DISK_OK, "disk_create succeeds");
    CHECK(d.sector_size == SECSZ, "sector_size set");
    CHECK(d.sector_count == NSEC, "sector_count set");
    CHECK(d.size == (size_t)SECSZ * NSEC, "size is sectors * sector_size");
    CHECK(d.dirty == 1, "new image is dirty");

    /* a freshly created image is zero-filled */
    uint8_t buf[SECSZ];
    memset(buf, 0xAA, sizeof(buf));
    CHECK(disk_read_sector(&d, 0, buf) == DISK_OK, "read sector 0");
    int zero = 1;
    for (uint32_t i = 0; i < SECSZ; i++) if (buf[i] != 0) { zero = 0; break; }
    CHECK(zero, "new image is zero-filled");

    disk_close(&d);
}

static void test_roundtrip_in_memory(void) {
    printf("test_roundtrip_in_memory\n");
    disk_t d;
    disk_create(&d, TMP_IMG, SECSZ, NSEC);

    uint8_t out[SECSZ], in[SECSZ];
    for (uint32_t i = 0; i < SECSZ; i++) out[i] = (uint8_t)(i ^ 0x5A);

    CHECK(disk_write_sector(&d, 3, out) == DISK_OK, "write sector 3");
    memset(in, 0, sizeof(in));
    CHECK(disk_read_sector(&d, 3, in) == DISK_OK, "read sector 3");
    CHECK(memcmp(out, in, SECSZ) == 0, "data read back equals data written");

    /* other sectors untouched */
    CHECK(disk_read_sector(&d, 4, in) == DISK_OK, "read sector 4");
    int zero = 1;
    for (uint32_t i = 0; i < SECSZ; i++) if (in[i] != 0) { zero = 0; break; }
    CHECK(zero, "adjacent sector untouched");

    disk_close(&d);
}

static void test_persistence_across_reopen(void) {
    printf("test_persistence_across_reopen\n");
    const char *msg = "Hello, disk image!";

    /* create, write, close (saves) */
    disk_t d;
    disk_create(&d, TMP_IMG, SECSZ, NSEC);
    uint8_t sec[SECSZ];
    memset(sec, 0, sizeof(sec));
    memcpy(sec, msg, strlen(msg));
    disk_write_sector(&d, 7, sec);
    CHECK(disk_close(&d) == DISK_OK, "close flushes to file");

    /* reopen and verify the bytes survived */
    disk_t d2;
    int rc = disk_open(&d2, TMP_IMG, SECSZ);
    CHECK(rc == DISK_OK, "reopen existing image");
    CHECK(d2.sector_count == NSEC, "reopened count matches");
    uint8_t got[SECSZ];
    CHECK(disk_read_sector(&d2, 7, got) == DISK_OK, "read sector 7 after reopen");
    CHECK(memcmp(got, msg, strlen(msg)) == 0, "persisted data matches");
    CHECK(d2.dirty == 0, "freshly loaded image is not dirty");
    disk_close(&d2);
}

static void test_bounds_and_args(void) {
    printf("test_bounds_and_args\n");
    disk_t d;
    disk_create(&d, TMP_IMG, SECSZ, NSEC);
    uint8_t buf[SECSZ] = {0};

    CHECK(disk_read_sector(&d, NSEC, buf) == DISK_ERR_RANGE,
          "read past last sector is out of range");
    CHECK(disk_write_sector(&d, NSEC + 100, buf) == DISK_ERR_RANGE,
          "write past last sector is out of range");
    CHECK(disk_read_sector(&d, NSEC - 1, buf) == DISK_OK,
          "read last valid sector ok");

    CHECK(disk_read_sector(&d, 0, NULL) == DISK_ERR_ARG, "null buffer rejected");
    CHECK(disk_create(NULL, TMP_IMG, SECSZ, NSEC) == DISK_ERR_ARG,
          "null disk rejected");
    CHECK(disk_create(&d, TMP_IMG, 0, NSEC) == DISK_ERR_ARG,
          "zero sector size rejected");

    disk_close(&d);
}

static void test_open_errors(void) {
    printf("test_open_errors\n");
    disk_t d;
    CHECK(disk_open(&d, "definitely_not_a_real_file.img", SECSZ) == DISK_ERR_IO,
          "opening a missing file reports I/O error");
}

int main(void) {
    printf("== disk module tests ==\n");
    test_create_and_fields();
    test_roundtrip_in_memory();
    test_persistence_across_reopen();
    test_bounds_and_args();
    test_open_errors();

    remove(TMP_IMG);

    printf("\n%d checks, %d failure(s)\n", g_checks, g_failures);
    return g_failures == 0 ? 0 : 1;
}
