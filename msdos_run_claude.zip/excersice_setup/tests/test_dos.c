/* test_dos.c - Layer 5: INT 21H dispatch, character I/O (stub console) and the
 * FCB file calls bridged to the filesystem. */
#include "../src/disk.h"
#include "../src/fat12.h"
#include "../src/kernel/dos.h"
#include "../src/kernel/kfs.h"
#include "../src/kernel/volume.h"

#include <stdio.h>
#include <string.h>

static int g_failures = 0, g_checks = 0;
#define CHECK(c, m) do { g_checks++; if (c) printf("  PASS: %s\n", (m)); \
    else { printf("  FAIL: %s  (%s:%d)\n", (m), __FILE__, __LINE__); g_failures++; } } while (0)

#define IMG "test_dos.img"

/* ---- buffer-backed stub console ---- */
typedef struct {
    const char *in; size_t inpos;
    char out[4096]; size_t outlen;
} stub_con;
static int  stub_getkey(void *ctx) {
    stub_con *c = ctx;
    return c->in[c->inpos] ? (unsigned char)c->in[c->inpos++] : -1;
}
static void stub_putch(void *ctx, char ch) {
    stub_con *c = ctx;
    if (c->outlen < sizeof(c->out) - 1) c->out[c->outlen++] = ch;
    c->out[c->outlen] = '\0';
}

static void test_char_io(void) {
    printf("test_char_io\n");
    stub_con sc; memset(&sc, 0, sizeof(sc));
    sc.in = "Hi";
    console_t con = { stub_getkey, stub_putch, NULL, &sc };
    dos_t s; dos_init(&s, NULL, &con);
    dos_regs r;

    /* 02h CONOUT 'A' */
    memset(&r, 0, sizeof(r)); r.ah = DOS_CONOUT; r.dl = 'A';
    dos_call(&s, &r);
    CHECK(strcmp(sc.out, "A") == 0, "CONOUT writes 'A'");

    /* 09h print '$'-terminated string */
    memset(&r, 0, sizeof(r)); r.ah = DOS_PRINT_STRING; r.dx_ptr = (void *)"BC$XYZ";
    dos_call(&s, &r);
    CHECK(strcmp(sc.out, "ABC") == 0, "PRINT_STRING stops at '$'");

    /* 01h CONIN returns next key and echoes */
    memset(&r, 0, sizeof(r)); r.ah = DOS_CONIN;
    dos_call(&s, &r);
    CHECK(r.al == 'H', "CONIN returns 'H'");
    CHECK(strcmp(sc.out, "ABCH") == 0, "CONIN echoed 'H'");

    /* 00h terminate sets the flag */
    memset(&r, 0, sizeof(r)); r.ah = DOS_TERMINATE;
    dos_call(&s, &r);
    CHECK(s.terminated == 1, "TERMINATE sets terminated flag");

    /* unimplemented function -> AL=0xFF, returns -1 */
    memset(&r, 0, sizeof(r)); r.ah = 0x99;
    CHECK(dos_call(&s, &r) == -1 && r.al == 0xFF, "unimplemented call rejected");
}

static void test_fcb_file_calls(void) {
    printf("test_fcb_file_calls\n");
    fat12_create_image(IMG, "320");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);
    dos_t s; dos_init(&s, &v, NULL);
    dos_regs r;

    uint8_t dta[128];
    memset(&r, 0, sizeof(r)); r.ah = DOS_SET_DTA; r.dx_ptr = dta;
    dos_call(&s, &r);

    /* create GREETING.TXT via FCB, write two records, close */
    dos_fcb_t fcb;
    CHECK(dos_fcb_init(&fcb, "greeting.txt") == KFS_OK, "init FCB");
    memset(&r, 0, sizeof(r)); r.ah = DOS_CREATE; r.dx_ptr = &fcb;
    dos_call(&s, &r);
    CHECK(r.al == 0, "CREATE succeeds");

    memset(dta, 0, sizeof(dta));
    memcpy(dta, "HELLO FROM RECORD 0", 19);
    memset(&r, 0, sizeof(r)); r.ah = DOS_SEQ_WRITE; r.dx_ptr = &fcb;
    dos_call(&s, &r);
    CHECK(r.al == 0, "SEQ_WRITE record 0");

    memset(dta, 0, sizeof(dta));
    memcpy(dta, "AND RECORD 1", 12);
    r.ah = DOS_SEQ_WRITE; r.al = 0;
    dos_call(&s, &r);
    CHECK(r.al == 0, "SEQ_WRITE record 1");
    CHECK(fcb.file_size == 256, "file is 2 records (256 bytes)");

    memset(&r, 0, sizeof(r)); r.ah = DOS_CLOSE; r.dx_ptr = &fcb;
    dos_call(&s, &r);
    CHECK(r.al == 0, "CLOSE succeeds");

    /* reopen and read records back */
    dos_fcb_t fcb2; dos_fcb_init(&fcb2, "greeting.txt");
    memset(&r, 0, sizeof(r)); r.ah = DOS_OPEN; r.dx_ptr = &fcb2;
    dos_call(&s, &r);
    CHECK(r.al == 0, "OPEN existing file");
    CHECK(fcb2.file_size == 256, "size read from directory");

    memset(dta, 0, sizeof(dta));
    memset(&r, 0, sizeof(r)); r.ah = DOS_SEQ_READ; r.dx_ptr = &fcb2;
    dos_call(&s, &r);
    CHECK(r.al == 0 && memcmp(dta, "HELLO FROM RECORD 0", 19) == 0, "SEQ_READ record 0");
    r.ah = DOS_SEQ_READ;
    dos_call(&s, &r);
    CHECK(r.al == 0 && memcmp(dta, "AND RECORD 1", 12) == 0, "SEQ_READ record 1");
    r.ah = DOS_SEQ_READ;
    dos_call(&s, &r);
    CHECK(r.al == 1, "SEQ_READ past EOF returns AL=1");

    /* search first/next for *.txt finds our file */
    uint8_t found[32];
    memset(&r, 0, sizeof(r)); r.ah = DOS_SET_DTA; r.dx_ptr = found; dos_call(&s, &r);
    dos_fcb_t pat; dos_fcb_init(&pat, "????????.txt");
    memset(pat.name, '?', 11); memcpy(pat.name + 8, "TXT", 3);   /* *.TXT */
    memset(&r, 0, sizeof(r)); r.ah = DOS_SEARCH_FIRST; r.dx_ptr = &pat;
    dos_call(&s, &r);
    CHECK(r.al == 0 && memcmp(found, "GREETINGTXT", 11) == 0, "SEARCH_FIRST finds GREETING.TXT");
    r.ah = DOS_SEARCH_NEXT;
    dos_call(&s, &r);
    CHECK(r.al == 0xFF, "SEARCH_NEXT: no more matches");

    /* delete it */
    dos_fcb_t df; dos_fcb_init(&df, "greeting.txt");
    memset(&r, 0, sizeof(r)); r.ah = DOS_DELETE; r.dx_ptr = &df;
    dos_call(&s, &r);
    CHECK(r.al == 0, "DELETE succeeds");
    dos_fcb_t cf; dos_fcb_init(&cf, "greeting.txt");
    memset(&r, 0, sizeof(r)); r.ah = DOS_OPEN; r.dx_ptr = &cf;
    dos_call(&s, &r);
    CHECK(r.al == 0xFF, "OPEN after DELETE fails");

    volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

/* Directory system calls (39h/3Ah/3Bh) and cwd-relative file operations. */
static void test_directory_calls(void) {
    printf("test_directory_calls\n");
    fat12_create_image(IMG, "320");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);
    dos_t s; dos_init(&s, &v, NULL);
    dos_regs r;
    uint8_t dta[128];
    memset(&r, 0, sizeof(r)); r.ah = DOS_SET_DTA; r.dx_ptr = dta; dos_call(&s, &r);

    /* MKDIR (39h) */
    memset(&r, 0, sizeof(r)); r.ah = DOS_MKDIR; r.dx_ptr = (void *)"GAMES";
    dos_call(&s, &r);
    CHECK(r.al == 0, "MKDIR GAMES succeeds");
    memset(&r, 0, sizeof(r)); r.ah = DOS_MKDIR; r.dx_ptr = (void *)"GAMES";
    dos_call(&s, &r);
    CHECK(r.al == 0xFF, "MKDIR of an existing name fails");

    /* CHDIR (3Bh) into it, then CREATE a file -- it lands in the subdir */
    memset(&r, 0, sizeof(r)); r.ah = DOS_CHDIR; r.dx_ptr = (void *)"GAMES";
    dos_call(&s, &r);
    CHECK(r.al == 0 && v.cwd.is_root == 0, "CHDIR GAMES enters the subdirectory");

    dos_fcb_t fcb; dos_fcb_init(&fcb, "SCORE.DAT");
    memset(&r, 0, sizeof(r)); r.ah = DOS_CREATE; r.dx_ptr = &fcb; dos_call(&s, &r);
    CHECK(r.al == 0, "CREATE SCORE.DAT inside GAMES");
    memset(&r, 0, sizeof(r)); r.ah = DOS_CLOSE; r.dx_ptr = &fcb; dos_call(&s, &r);

    /* back to root: the file is not openable there */
    memset(&r, 0, sizeof(r)); r.ah = DOS_CHDIR; r.dx_ptr = (void *)"..";
    dos_call(&s, &r);
    CHECK(r.al == 0 && v.cwd.is_root == 1, "CHDIR .. returns to root");
    dos_fcb_t look; dos_fcb_init(&look, "SCORE.DAT");
    memset(&r, 0, sizeof(r)); r.ah = DOS_OPEN; r.dx_ptr = &look; dos_call(&s, &r);
    CHECK(r.al == 0xFF, "SCORE.DAT not found from the root");

    /* RMDIR (3Ah): refuses non-empty, succeeds once emptied */
    memset(&r, 0, sizeof(r)); r.ah = DOS_RMDIR; r.dx_ptr = (void *)"GAMES";
    dos_call(&s, &r);
    CHECK(r.al == 0xFF, "RMDIR of a non-empty directory fails");

    memset(&r, 0, sizeof(r)); r.ah = DOS_CHDIR; r.dx_ptr = (void *)"GAMES"; dos_call(&s, &r);
    dos_fcb_t del; dos_fcb_init(&del, "SCORE.DAT");
    memset(&r, 0, sizeof(r)); r.ah = DOS_DELETE; r.dx_ptr = &del; dos_call(&s, &r);
    memset(&r, 0, sizeof(r)); r.ah = DOS_CHDIR; r.dx_ptr = (void *)"\\"; dos_call(&s, &r);
    memset(&r, 0, sizeof(r)); r.ah = DOS_RMDIR; r.dx_ptr = (void *)"GAMES"; dos_call(&s, &r);
    CHECK(r.al == 0, "RMDIR succeeds once the directory is empty");

    volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

int main(void) {
    printf("== Layer 5: DOS dispatch + char I/O ==\n");
    test_char_io();
    test_fcb_file_calls();
    test_directory_calls();
    printf("\n%d checks, %d failure(s)\n", g_checks, g_failures);
    return g_failures ? 1 : 0;
}
