/* test_volume.c - Layer 2: mount a formatted image and check derived geometry
 * and cluster/root addressing. Uses the real wrapper disk + fat12 modules. */
#include "../src/disk.h"
#include "../src/fat12.h"
#include "../src/kernel/fat.h"
#include "../src/kernel/volume.h"

#include <stdio.h>
#include <string.h>

static int g_failures = 0, g_checks = 0;
#define CHECK(c, m) do { g_checks++; if (c) printf("  PASS: %s\n", (m)); \
    else { printf("  FAIL: %s  (%s:%d)\n", (m), __FILE__, __LINE__); g_failures++; } } while (0)

#define IMG "test_volume.img"

static void test_mount_320k(void) {
    printf("test_mount_320k\n");
    disk_t d;
    /* 320 KB MS-DOS 1.25 disk: media 0xFF, spc 2, root 112, spf 1. */
    fat12_create_image(IMG, "320");
    CHECK(disk_open(&d, IMG, 512) == DISK_OK, "open formatted image");

    volume_t v;
    CHECK(volume_mount(&v, &d) == DISK_OK, "mount succeeds");
    CHECK(v.media == 0xFF, "media descriptor 0xFF");
    CHECK(v.sectors_per_cluster == 2, "sectors per cluster = 2");
    CHECK(v.root_entries == 112, "112 root entries");
    CHECK(v.root_dir_sectors == 7, "root dir = 7 sectors");
    CHECK(v.first_root_sector == 3, "root starts at sector 3 (1 boot + 2 FAT)");
    CHECK(v.first_data_sector == 10, "data starts at sector 10");
    CHECK(v.bytes_per_cluster == 1024, "cluster = 1024 bytes");
    /* data sectors = 640 - 10 = 630; clusters = 315 */
    CHECK(v.cluster_count == 315, "315 data clusters");
    CHECK(v.max_cluster == 316, "max cluster = 316");

    /* The loaded FAT carries the media byte and reserved entries. */
    CHECK(v.fat[0] == 0xFF && v.fat[1] == 0xFF && v.fat[2] == 0xFF,
          "in-memory FAT seeded with media/reserved entries");
    CHECK(fat12_count_free(v.fat, v.max_cluster) == v.cluster_count,
          "all data clusters free on a fresh format");

    volume_unmount(&v);
    disk_close(&d);
}

static void test_cluster_addressing(void) {
    printf("test_cluster_addressing\n");
    disk_t d;
    disk_open(&d, IMG, 512);
    volume_t v;
    volume_mount(&v, &d);

    CHECK(volume_cluster_sector(&v, 2) == 10, "cluster 2 -> sector 10");
    CHECK(volume_cluster_sector(&v, 3) == 12, "cluster 3 -> sector 12 (spc 2)");

    /* Write a cluster, read it back. */
    uint8_t out[1024], in[1024];
    for (int i = 0; i < 1024; i++) out[i] = (uint8_t)(i * 3 + 1);
    CHECK(volume_write_cluster(&v, 5, out) == DISK_OK, "write cluster 5");
    memset(in, 0, sizeof(in));
    CHECK(volume_read_cluster(&v, 5, in) == DISK_OK, "read cluster 5");
    CHECK(memcmp(in, out, 1024) == 0, "cluster data round-trips");

    CHECK(volume_read_cluster(&v, 1, in) == DISK_ERR_RANGE, "cluster 1 rejected");
    CHECK(volume_read_cluster(&v, 9999, in) == DISK_ERR_RANGE, "huge cluster rejected");

    volume_unmount(&v);
    disk_close(&d);
}

static void test_flush_persists_fat(void) {
    printf("test_flush_persists_fat\n");
    disk_t d;
    disk_open(&d, IMG, 512);
    volume_t v;
    volume_mount(&v, &d);

    uint16_t c = fat12_alloc(v.fat, v.max_cluster);
    CHECK(c == 2, "allocated cluster 2 in memory");
    CHECK(volume_flush(&v) == DISK_OK, "flush writes FAT to both copies");

    /* Verify FAT copy #2 on disk also got the update. */
    size_t fat2 = (size_t)(v.reserved_sectors + v.sectors_per_fat) * 512;
    CHECK(fat12_is_eof(fat12_get(d.data + fat2, 2)),
          "second FAT copy reflects the allocation");
    volume_unmount(&v);
    disk_close(&d);

    /* Reopen + remount: the allocation survived. */
    disk_t d2; disk_open(&d2, IMG, 512);
    volume_t v2; volume_mount(&v2, &d2);
    CHECK(fat12_is_eof(fat12_get(v2.fat, 2)), "allocation persisted across remount");
    volume_unmount(&v2); disk_close(&d2);
}

static void test_mount_unformatted(void) {
    printf("test_mount_unformatted\n");
    disk_t d;
    disk_create(&d, "test_volume_blank.img", 512, 640);  /* zero-filled, no media */
    volume_t v;
    CHECK(volume_mount(&v, &d) == DISK_ERR_ARG, "mounting unformatted image fails cleanly");
    disk_close(&d);
    remove("test_volume_blank.img");
}

int main(void) {
    printf("== Layer 2: volume / DPB ==\n");
    test_mount_320k();
    test_cluster_addressing();
    test_flush_persists_fat();
    test_mount_unformatted();
    remove(IMG);
    printf("\n%d checks, %d failure(s)\n", g_checks, g_failures);
    return g_failures ? 1 : 0;
}
