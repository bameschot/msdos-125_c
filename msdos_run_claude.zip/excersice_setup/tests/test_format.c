/* test_format.c - wrapper tests for authentic MS-DOS 1.x FAT12 formatting
 * and open-error handling.
 *
 * Verifies:
 *   1. a freshly formatted disk image has the correct size;
 *   2. the volume carries a valid (authentic 1.x) FAT12 identity -- the media
 *      descriptor byte in the FAT -- and NO BPB / "FAT12" type string;
 *   3. opening a non-existent image returns an error rather than crashing.
 *
 * MS-DOS 1.25 == PC DOS 1.1, whose canonical disk is the 320 KB double-sided
 * floppy (640 x 512 = 327680 bytes, media descriptor 0xFF).
 *
 * No test framework: each check prints PASS/FAIL and the process exits
 * non-zero if any check failed.
 */
#include "../src/disk.h"
#include "../src/fat12.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_failures = 0;
static int g_checks = 0;

#define CHECK(cond, msg) do {                                       \
    g_checks++;                                                     \
    if (cond) {                                                     \
        printf("  PASS: %s\n", (msg));                              \
    } else {                                                        \
        printf("  FAIL: %s  (%s:%d)\n", (msg), __FILE__, __LINE__); \
        g_failures++;                                               \
    }                                                               \
} while (0)

#define TMP_IMG  "test_format.img"
#define SECSZ    512u
#define NSEC_320 640u            /* 320 KB: 640 * 512 = 327680 bytes */
#define NSEC_160 320u            /* 160 KB: 320 * 512 = 163840 bytes */

/* (1) A freshly formatted image is exactly sector_count * sector_size bytes,
 *     both in memory and as written to the backing file. */
static void test_correct_size(void) {
    printf("test_correct_size\n");
    const size_t expected = (size_t)SECSZ * NSEC_320;   /* 327680 */

    disk_t d;
    int rc = disk_create(&d, TMP_IMG, SECSZ, NSEC_320);
    CHECK(rc == DISK_OK, "disk_create succeeds");
    CHECK(fat12_format(&d, DOS1_MEDIA_320K) == DISK_OK,
          "fat12_format (320K) succeeds");
    CHECK(d.size == expected, "in-memory size = sectors * sector_size (327680)");
    CHECK(disk_close(&d) == DISK_OK, "close writes the image to file");

    /* Reopen and confirm the on-disk file is the right size. */
    disk_t d2;
    CHECK(disk_open(&d2, TMP_IMG, SECSZ) == DISK_OK, "reopen formatted image");
    CHECK(d2.size == expected, "on-disk size = sectors * sector_size");
    CHECK(d2.sector_count == NSEC_320, "sector_count preserved");
    disk_close(&d2);
}

/* (2) The volume is identified the authentic 1.x way -- by the media
 *     descriptor in the FAT -- and carries NO modern BPB / "FAT12" string.
 *     An unformatted image is not recognised. */
static void test_authentic_media_id(void) {
    printf("test_authentic_media_id\n");
    disk_t d;
    disk_create(&d, TMP_IMG, SECSZ, NSEC_320);

    /* Before formatting: zero-filled, no media descriptor recognised. */
    CHECK(fat12_media_descriptor(&d) == 0,
          "unformatted image has no media descriptor");

    CHECK(fat12_format(&d, DOS1_MEDIA_320K) == DISK_OK, "format 320K image");

    /* The media descriptor is the authentic disk identity, in FAT[0]. */
    CHECK(fat12_media_descriptor(&d) == DOS1_MEDIA_320K,
          "media descriptor 0xFF read from the FAT");

    uint8_t fat[SECSZ];
    CHECK(disk_read_sector(&d, 1, fat) == DISK_OK, "read first FAT sector");
    CHECK(fat[0] == 0xFF && fat[1] == 0xFF && fat[2] == 0xFF,
          "FAT reserved entries are FF FF FF (media 0xFF)");

    /* Authenticity: the boot sector must NOT contain a BPB or the "FAT12"
     * type string -- those are DOS 2.0 / 4.0 inventions, absent in 1.25. */
    uint8_t boot[SECSZ];
    CHECK(disk_read_sector(&d, 0, boot) == DISK_OK, "read boot sector");
    CHECK(memcmp(boot + 54, "FAT12", 5) != 0,
          "boot sector has NO \"FAT12\" type string (authentic 1.x)");
    CHECK(boot[11] == 0 && boot[12] == 0,
          "boot sector has NO BPB bytes-per-sector field (authentic 1.x)");
    CHECK(boot[510] == 0x55 && boot[511] == 0xAA,
          "BIOS boot signature 0x55AA present (written by FORMAT)");

    disk_close(&d);

    /* The 160 KB single-sided format uses media descriptor 0xFE. */
    disk_t s;
    disk_create(&s, TMP_IMG, SECSZ, NSEC_160);
    CHECK(fat12_format(&s, DOS1_MEDIA_160K) == DISK_OK, "format 160K image");
    CHECK(fat12_media_descriptor(&s) == DOS1_MEDIA_160K,
          "media descriptor 0xFE for 160K disk");
    disk_close(&s);
}

/* Geometry helper recognises standard disks and rejects others. */
static void test_geometry_lookup(void) {
    printf("test_geometry_lookup\n");
    CHECK(fat12_media_for_geometry(512, 640) == DOS1_MEDIA_320K,
          "512 x 640 -> media 0xFF (320K)");
    CHECK(fat12_media_for_geometry(512, 320) == DOS1_MEDIA_160K,
          "512 x 320 -> media 0xFE (160K)");
    CHECK(fat12_media_for_geometry(512, 256) == 0,
          "non-standard geometry -> 0");
    CHECK(fat12_media_for_geometry(1024, 640) == 0,
          "non-512 sector size -> 0");
}

/* The --format CLI flags: each named size creates a blank FAT12 image of the
 * correct byte size with the correct media descriptor. */
static void test_create_image_sizes(void) {
    printf("test_create_image_sizes\n");
    const struct { const char *name; size_t bytes; uint8_t media; } cases[] = {
        { "180",  360u * 512, DOS1_MEDIA_180K },   /* 184320  */
        { "360",  720u * 512, DOS1_MEDIA_360K },   /* 368640  */
        { "720", 1440u * 512, DOS1_MEDIA_720K },   /* 737280  */
        { "160",  320u * 512, DOS1_MEDIA_160K },   /* 163840  */
        { "320",  640u * 512, DOS1_MEDIA_320K },   /* 327680  */
    };
    char msg[96];
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
        snprintf(msg, sizeof(msg), "create --%s image", cases[i].name);
        CHECK(fat12_create_image(TMP_IMG, cases[i].name) == DISK_OK, msg);

        disk_t d;
        CHECK(disk_open(&d, TMP_IMG, 512) == DISK_OK, "reopen created image");
        snprintf(msg, sizeof(msg), "--%s image size = %zu bytes",
                 cases[i].name, cases[i].bytes);
        CHECK(d.size == cases[i].bytes, msg);
        snprintf(msg, sizeof(msg), "--%s media descriptor = 0x%02X",
                 cases[i].name, cases[i].media);
        CHECK(fat12_media_descriptor(&d) == cases[i].media, msg);
        disk_close(&d);
    }

    /* name lookup + rejection of an unknown size */
    uint8_t media; uint32_t ss, sc;
    CHECK(fat12_geometry_by_name("720", &media, &ss, &sc) == DISK_OK,
          "geometry_by_name(\"720\") ok");
    CHECK(media == DOS1_MEDIA_720K && ss == 512 && sc == 1440,
          "geometry_by_name(\"720\") fields correct");
    CHECK(fat12_geometry_by_name("999", NULL, NULL, NULL) == DISK_ERR_ARG,
          "geometry_by_name(unknown) rejected");
    CHECK(fat12_create_image(TMP_IMG, "999") == DISK_ERR_ARG,
          "create_image(unknown size) rejected");
}

/* (3) Opening a missing file returns an error (no crash); the bad-input and
 *     geometry-mismatch guards return cleanly instead of dereferencing NULL. */
static void test_open_nonexistent(void) {
    printf("test_open_nonexistent\n");
    disk_t d;
    int rc = disk_open(&d, "does_not_exist_42.img", SECSZ);
    CHECK(rc == DISK_ERR_IO, "open of missing file returns DISK_ERR_IO");

    CHECK(fat12_media_descriptor(NULL) == 0,
          "fat12_media_descriptor(NULL) returns 0, no crash");
    CHECK(fat12_format(NULL, DOS1_MEDIA_320K) == DISK_ERR_ARG,
          "fat12_format(NULL) returns an error, no crash");

    /* Unknown media descriptor must be rejected. */
    disk_t img;
    disk_create(&img, TMP_IMG, SECSZ, NSEC_320);
    CHECK(fat12_format(&img, 0x42) == DISK_ERR_ARG,
          "unknown media descriptor rejected");
    /* Geometry that does not match the requested media must be rejected. */
    CHECK(fat12_format(&img, DOS1_MEDIA_160K) == DISK_ERR_ARG,
          "media/geometry mismatch rejected (160K media on 320K disk)");
    disk_close(&img);
}

int main(void) {
    printf("== authentic MS-DOS 1.x FAT12 format tests ==\n");
    test_correct_size();
    test_authentic_media_id();
    test_geometry_lookup();
    test_create_image_sizes();
    test_open_nonexistent();

    remove(TMP_IMG);

    printf("\n%d checks, %d failure(s)\n", g_checks, g_failures);
    return g_failures == 0 ? 0 : 1;
}
