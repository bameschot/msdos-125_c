/* test_dir.c - Layer 3: 8.3 name handling and root-directory operations. */
#include "../src/disk.h"
#include "../src/fat12.h"
#include "../src/kernel/dir.h"
#include "../src/kernel/fat.h"
#include "../src/kernel/kfile.h"
#include "../src/kernel/kfs.h"
#include "../src/kernel/volume.h"

#include <stdio.h>
#include <string.h>

static int g_failures = 0, g_checks = 0;
#define CHECK(c, m) do { g_checks++; if (c) printf("  PASS: %s\n", (m)); \
    else { printf("  FAIL: %s  (%s:%d)\n", (m), __FILE__, __LINE__); g_failures++; } } while (0)

#define IMG "test_dir.img"

static void test_names(void) {
    printf("test_names\n");
    uint8_t n[11];
    char s[13];

    CHECK(dir_parse_name("readme.txt", n) == KFS_OK, "parse readme.txt");
    CHECK(memcmp(n, "README  TXT", 11) == 0, "-> 'README  TXT' (upcased, padded)");
    dir_format_name(n, s);
    CHECK(strcmp(s, "README.TXT") == 0, "format back to README.TXT");

    CHECK(dir_parse_name("kernel", n) == KFS_OK, "parse extensionless name");
    CHECK(memcmp(n, "KERNEL     ", 11) == 0, "-> 'KERNEL     '");
    dir_format_name(n, s);
    CHECK(strcmp(s, "KERNEL") == 0, "format back to KERNEL");

    CHECK(dir_parse_name("toolongname.txt", n) == KFS_ARG, "reject >8 char name");
    CHECK(dir_parse_name("a.exten", n) == KFS_ARG, "reject >3 char ext");
    CHECK(dir_parse_name("a?b.txt", n) == KFS_ARG, "reject wildcard in exact name");

    /* patterns */
    CHECK(dir_parse_pattern("*.txt", n) == KFS_OK, "parse *.txt pattern");
    CHECK(memcmp(n, "????????TXT", 11) == 0, "*.txt -> '????????TXT'");
    uint8_t name[11]; dir_parse_name("readme.txt", name);
    CHECK(dir_name_match(n, name), "*.txt matches README.TXT");
    uint8_t other[11]; dir_parse_name("readme.doc", other);
    CHECK(!dir_name_match(n, other), "*.txt does not match README.DOC");
}

static void test_create_find_delete(void) {
    printf("test_create_find_delete\n");
    disk_t d;
    fat12_create_image(IMG, "320");
    disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);

    /* Initially empty: nothing found, first free slot is index 0. */
    uint8_t nm[11]; dir_parse_name("hello.txt", nm);
    CHECK(dir_find(&v, nm, NULL, NULL) == KFS_NOTFOUND, "empty dir: not found");
    uint16_t free_idx = 0xFFFF;
    CHECK(dir_find_free(&v, &free_idx) == KFS_OK && free_idx == 0,
          "first free slot is index 0");

    /* Write an entry and read it back. */
    dir_entry_t e;
    memset(&e, 0, sizeof(e));
    memcpy(e.name, nm, 11);
    e.first_cluster = 5;
    e.size = 1234;
    CHECK(dir_write_entry(&v, 0, &e) == KFS_OK, "write entry at slot 0");

    uint16_t idx = 0xFFFF; dir_entry_t got;
    CHECK(dir_find(&v, nm, &idx, &got) == KFS_OK, "find written entry");
    CHECK(idx == 0, "found at index 0");
    CHECK(got.first_cluster == 5 && got.size == 1234, "entry fields preserved");

    /* Next free slot is now 1. */
    CHECK(dir_find_free(&v, &free_idx) == KFS_OK && free_idx == 1,
          "next free slot is index 1");

    /* Delete by marking the name byte 0xE5; slot becomes reusable. */
    got.name[0] = DIR_FREE;
    dir_write_entry(&v, 0, &got);
    CHECK(dir_find(&v, nm, NULL, NULL) == KFS_NOTFOUND, "deleted entry not found");
    CHECK(dir_find_free(&v, &free_idx) == KFS_OK && free_idx == 0,
          "deleted slot 0 reusable");

    volume_flush(&v); volume_unmount(&v); disk_close(&d);
}

static void test_search_wildcards(void) {
    printf("test_search_wildcards\n");
    disk_t d;
    fat12_create_image(IMG, "320");
    disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);

    const char *files[] = { "a.txt", "b.txt", "c.doc", "readme.txt" };
    for (int i = 0; i < 4; i++) {
        dir_entry_t e; memset(&e, 0, sizeof(e));
        dir_parse_name(files[i], e.name);
        dir_write_entry(&v, (uint16_t)i, &e);
    }

    uint8_t pat[11]; dir_parse_pattern("*.txt", pat);
    uint16_t idx = 0; dir_entry_t e;
    int matches = 0; char nm[13];
    while (dir_search(&v, pat, &idx, &e) == KFS_OK) {
        dir_format_name(e.name, nm);
        matches++;
    }
    CHECK(matches == 3, "*.txt matches 3 of 4 files");

    uint8_t all[11]; dir_parse_pattern("*.*", all);
    idx = 0; matches = 0;
    while (dir_search(&v, all, &idx, &e) == KFS_OK) matches++;
    CHECK(matches == 4, "*.* matches all 4 files");

    volume_unmount(&v); disk_close(&d);
}

/* Subdirectories: MKDIR / CHDIR / RMDIR, dot entries, cwd-relative files. */
static void test_subdirectories(void) {
    printf("test_subdirectories\n");
    disk_t d;
    fat12_create_image(IMG, "320");
    disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);
    uint16_t free0 = fat12_count_free(v.fat, v.max_cluster);

    /* create a subdirectory in the root */
    CHECK(dir_mkdir(&v, "SUB") == KFS_OK, "mkdir SUB");
    CHECK(dir_mkdir(&v, "SUB") == KFS_EXISTS, "mkdir SUB again -> exists");
    uint8_t nm[11]; dir_parse_name("SUB", nm);
    dir_entry_t e;
    CHECK(dir_find(&v, nm, NULL, &e) == KFS_OK && (e.attr & DIR_ATTR_DIR),
          "SUB is present in root with the directory attribute");
    CHECK(fat12_count_free(v.fat, v.max_cluster) == free0 - 1, "subdir uses one cluster");

    /* enter it; it has "." and ".." and is otherwise empty */
    CHECK(dir_chdir(&v, "SUB") == KFS_OK, "cd SUB");
    CHECK(v.cwd.is_root == 0, "cwd is no longer the root");
    CHECK(strcmp(v.cwd_path, "\\SUB") == 0, "cwd path is \\SUB");
    uint8_t dot[11]; dir_parse_pattern("*.*", dot);
    uint16_t idx = 0; int entries = 0; dir_entry_t se;
    while (dir_search(&v, dot, &idx, &se) == KFS_OK) entries++;
    CHECK(entries == 2, "new subdir contains exactly . and ..");

    /* create a file inside the subdir; it lives there, not in the root */
    kfile_t f;
    CHECK(kfile_create(&v, "INNER.TXT", &f) == KFS_OK, "create INNER.TXT in SUB");
    kfile_write(&f, "hi", 2); kfile_close(&f);
    CHECK(dir_find(&v, (dir_parse_name("INNER.TXT", nm), nm), NULL, NULL) == KFS_OK,
          "INNER.TXT found in SUB");

    /* go back to root: the file is not visible there */
    CHECK(dir_chdir(&v, "..") == KFS_OK, "cd ..");
    CHECK(v.cwd.is_root == 1 && v.cwd_path[0] == 0, "back at root");
    CHECK(dir_find(&v, (dir_parse_name("INNER.TXT", nm), nm), NULL, NULL) == KFS_NOTFOUND,
          "INNER.TXT not visible from the root");

    /* rmdir refuses a non-empty directory */
    CHECK(dir_rmdir(&v, "SUB") == KFS_NOTEMPTY, "rmdir SUB while non-empty fails");

    /* empty it, then rmdir succeeds and frees the cluster */
    dir_chdir(&v, "SUB");
    CHECK(kfile_delete(&v, "INNER.TXT") == KFS_OK, "delete INNER.TXT");
    dir_chdir(&v, "\\");
    CHECK(v.cwd.is_root == 1, "cd \\ returns to root");
    CHECK(dir_rmdir(&v, "SUB") == KFS_OK, "rmdir SUB when empty");
    CHECK(dir_find(&v, (dir_parse_name("SUB", nm), nm), NULL, NULL) == KFS_NOTFOUND, "SUB gone");
    CHECK(fat12_count_free(v.fat, v.max_cluster) == free0, "all clusters reclaimed");

    /* cd into a missing directory / a regular file fails */
    CHECK(dir_chdir(&v, "NOPE") == KFS_NOTFOUND, "cd to missing dir fails");
    kfile_create(&v, "PLAIN.TXT", &f); kfile_close(&f);
    CHECK(dir_chdir(&v, "PLAIN.TXT") == KFS_ARG, "cd into a regular file fails");

    volume_flush(&v); volume_unmount(&v); disk_close(&d);
}

/* Nested directories: parent links via ".." resolve correctly. */
static void test_nested(void) {
    printf("test_nested\n");
    disk_t d;
    fat12_create_image(IMG, "320");
    disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);

    dir_mkdir(&v, "A");
    dir_chdir(&v, "A");
    dir_mkdir(&v, "B");
    dir_chdir(&v, "B");
    CHECK(strcmp(v.cwd_path, "\\A\\B") == 0, "two levels deep: path \\A\\B");
    dir_chdir(&v, "..");
    CHECK(strcmp(v.cwd_path, "\\A") == 0, "cd .. -> \\A");
    CHECK(v.cwd.is_root == 0, "still in a subdirectory");
    dir_chdir(&v, "..");
    CHECK(v.cwd.is_root == 1 && v.cwd_path[0] == 0, "cd .. -> root");

    volume_unmount(&v); disk_close(&d);
}

int main(void) {
    printf("== Layer 3: directory ==\n");
    test_names();
    test_create_find_delete();
    test_search_wildcards();
    test_subdirectories();
    test_nested();
    remove(IMG);
    printf("\n%d checks, %d failure(s)\n", g_checks, g_failures);
    return g_failures ? 1 : 0;
}
