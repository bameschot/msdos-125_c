/* test_kfile.c - Layer 4: file create/write/read/seek/delete on a real image,
 * including data that spans multiple clusters and persistence across remount. */
#include "../src/disk.h"
#include "../src/fat12.h"
#include "../src/kernel/dir.h"
#include "../src/kernel/fat.h"
#include "../src/kernel/kfile.h"
#include "../src/kernel/kfs.h"
#include "../src/kernel/volume.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_failures = 0, g_checks = 0;
#define CHECK(c, m) do { g_checks++; if (c) printf("  PASS: %s\n", (m)); \
    else { printf("  FAIL: %s  (%s:%d)\n", (m), __FILE__, __LINE__); g_failures++; } } while (0)

#define IMG "test_kfile.img"

/* Write a payload, close, remount, read it back. The payload (3000 bytes)
 * spans 3 clusters on the 320K disk (1024 bytes/cluster). */
static void test_write_read_persist(void) {
    printf("test_write_read_persist\n");
    fat12_create_image(IMG, "320");

    uint8_t payload[3000];
    for (int i = 0; i < 3000; i++) payload[i] = (uint8_t)(i * 31 + 7);

    /* --- session 1: create + write --- */
    {
        disk_t d; disk_open(&d, IMG, 512);
        volume_t v; volume_mount(&v, &d);
        kfile_t f;
        CHECK(kfile_create(&v, "data.bin", &f) == KFS_OK, "create data.bin");
        CHECK(kfile_write(&f, payload, sizeof(payload)) == KFS_OK, "write 3000 bytes");
        CHECK(f.size == 3000, "size tracks to 3000");
        CHECK(fat12_chain_length(v.fat, f.first_cluster) == 3,
              "payload occupies 3 clusters");
        CHECK(kfile_close(&f) == KFS_OK, "close (flushes)");
        volume_unmount(&v); disk_close(&d);
    }

    /* --- session 2: remount + read back --- */
    {
        disk_t d; disk_open(&d, IMG, 512);
        volume_t v; volume_mount(&v, &d);
        kfile_t f;
        CHECK(kfile_open(&v, "data.bin", &f) == KFS_OK, "reopen after remount");
        CHECK(f.size == 3000, "size persisted");
        uint8_t got[3000]; uint32_t n = 0;
        CHECK(kfile_read(&f, got, sizeof(got), &n) == KFS_OK, "read back");
        CHECK(n == 3000, "read full length");
        CHECK(memcmp(got, payload, 3000) == 0, "data matches across remount");

        /* read past EOF returns short */
        uint8_t extra[16]; uint32_t m = 99;
        kfile_read(&f, extra, sizeof(extra), &m);
        CHECK(m == 0, "read at EOF returns 0 bytes");
        kfile_close(&f);
        volume_unmount(&v); disk_close(&d);
    }
    remove(IMG);
}

static void test_seek_and_overwrite(void) {
    printf("test_seek_and_overwrite\n");
    fat12_create_image(IMG, "320");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);

    kfile_t f;
    kfile_create(&v, "seek.txt", &f);
    kfile_write(&f, "AAAAAAAAAA", 10);          /* 10 'A' */
    CHECK(f.size == 10, "wrote 10 bytes");

    kfile_seek(&f, 3);
    kfile_write(&f, "xyz", 3);                  /* overwrite bytes 3..5 */
    CHECK(f.size == 10, "size unchanged by in-place overwrite");

    kfile_seek(&f, 0);
    char got[11] = {0}; uint32_t n;
    kfile_read(&f, got, 10, &n);
    CHECK(strcmp(got, "AAAxyzAAAA") == 0, "seek+overwrite produced AAAxyzAAAA");
    kfile_close(&f);
    volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

static void test_truncate_and_delete(void) {
    printf("test_truncate_and_delete\n");
    fat12_create_image(IMG, "320");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);
    uint16_t free_before = fat12_count_free(v.fat, v.max_cluster);

    kfile_t f;
    kfile_create(&v, "big.dat", &f);
    uint8_t blk[2048]; memset(blk, 0xAB, sizeof(blk));
    kfile_write(&f, blk, sizeof(blk));          /* 2 clusters */
    kfile_close(&f);
    CHECK(fat12_count_free(v.fat, v.max_cluster) == free_before - 2,
          "2 clusters consumed");

    /* create over the same name truncates: chain freed, size 0 */
    kfile_create(&v, "big.dat", &f);
    CHECK(f.size == 0 && f.first_cluster == 0, "re-create truncates to empty");
    kfile_close(&f);
    CHECK(fat12_count_free(v.fat, v.max_cluster) == free_before,
          "truncation returned the clusters");

    /* delete removes the dir entry and frees nothing extra (already empty) */
    kfile_create(&v, "tmp.x", &f);
    kfile_write(&f, blk, 1024);
    kfile_close(&f);
    CHECK(fat12_count_free(v.fat, v.max_cluster) == free_before - 1, "tmp.x used 1 cluster");
    CHECK(kfile_delete(&v, "tmp.x") == KFS_OK, "delete tmp.x");
    CHECK(fat12_count_free(v.fat, v.max_cluster) == free_before, "delete freed the cluster");
    kfile_t g;
    CHECK(kfile_open(&v, "tmp.x", &g) == KFS_NOTFOUND, "deleted file cannot be opened");

    volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

static void test_volume_full(void) {
    printf("test_volume_full\n");
    /* 160K disk: media 0xFE, spc 1 (512 B/cluster), 313 data clusters. */
    fat12_create_image(IMG, "160");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);

    kfile_t f;
    kfile_create(&v, "fill.bin", &f);
    uint8_t blk[512]; memset(blk, 0x55, sizeof(blk));
    int rc = KFS_OK, clusters = 0;
    for (int i = 0; i < 100000; i++) {
        rc = kfile_write(&f, blk, sizeof(blk));
        if (rc != KFS_OK) break;
        clusters++;
    }
    CHECK(rc == KFS_FULL, "writing past capacity returns KFS_FULL");
    CHECK(clusters == v.cluster_count, "filled exactly cluster_count clusters");
    CHECK(fat12_count_free(v.fat, v.max_cluster) == 0, "no free clusters left");
    kfile_close(&f);
    volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

int main(void) {
    printf("== Layer 4: files ==\n");
    test_write_read_persist();
    test_seek_and_overwrite();
    test_truncate_and_delete();
    test_volume_full();
    printf("\n%d checks, %d failure(s)\n", g_checks, g_failures);
    return g_failures ? 1 : 0;
}
