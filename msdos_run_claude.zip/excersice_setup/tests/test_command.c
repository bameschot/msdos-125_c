/* test_command.c - the command processor: prompt/read/dispatch and the
 * internal commands, driven against a mounted volume + stub console. */
#include "../src/disk.h"
#include "../src/fat12.h"
#include "../src/kernel/command.h"
#include "../src/kernel/dos.h"
#include "../src/kernel/fat.h"
#include "../src/kernel/kfile.h"
#include "../src/kernel/kfs.h"
#include "../src/kernel/volume.h"

#include <stdio.h>
#include <string.h>

static int g_failures = 0, g_checks = 0;
#define CHECK(c, m) do { g_checks++; if (c) printf("  PASS: %s\n", (m)); \
    else { printf("  FAIL: %s  (%s:%d)\n", (m), __FILE__, __LINE__); g_failures++; } } while (0)

#define IMG "test_command.img"

/* buffer-backed console: feeds `in`, captures output in `out`. */
typedef struct { const char *in; size_t inpos; char out[8192]; size_t outlen; } stub_con;
static int  sgk(void *x) { stub_con *c = x; return c->in[c->inpos] ? (unsigned char)c->in[c->inpos++] : -1; }
static void spc(void *x, char ch) { stub_con *c = x; if (c->outlen < sizeof(c->out) - 1) c->out[c->outlen++] = ch; c->out[c->outlen] = 0; }

static int contains(stub_con *c, const char *needle) { return strstr(c->out, needle) != NULL; }
static void reset_out(stub_con *c) { c->out[0] = 0; c->outlen = 0; }

/* Helper: drop a file with given contents using the kernel API directly. */
static void make_file(volume_t *v, const char *name, const char *text) {
    kfile_t f; kfile_create(v, name, &f);
    kfile_write(&f, text, (uint32_t)strlen(text));
    kfile_close(&f);
}

static void test_dispatch_and_commands(void) {
    printf("test_dispatch_and_commands\n");
    fat12_create_image(IMG, "320");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);
    make_file(&v, "hello.txt", "HELLO WORLD CONTENTS");

    stub_con sc; memset(&sc, 0, sizeof(sc));
    console_t con = { sgk, spc, NULL, &sc };
    dos_t dos; dos_init(&dos, &v, &con);
    command_t c; command_init(&c, &dos);

    char line[128];

    /* VER */
    reset_out(&sc); strcpy(line, "ver"); command_exec(&c, line);
    CHECK(contains(&sc, "MS-DOS 1.25"), "VER prints the version string");

    /* CLS emits an ANSI clear sequence */
    reset_out(&sc); strcpy(line, "cls"); command_exec(&c, line);
    CHECK(contains(&sc, "\x1b[2J"), "CLS emits the clear-screen escape");

    /* HELP lists commands */
    reset_out(&sc); strcpy(line, "help"); command_exec(&c, line);
    CHECK(contains(&sc, "DIR") && contains(&sc, "CHKDSK") && contains(&sc, "EXIT"),
          "HELP lists the internal commands");

    /* CHKDSK reports usage; one file (hello.txt, 20 bytes) present */
    reset_out(&sc); strcpy(line, "chkdsk"); command_exec(&c, line);
    CHECK(contains(&sc, "bytes total disk space"), "CHKDSK reports total space");
    CHECK(contains(&sc, "in 1 user files"), "CHKDSK counts the one file");
    CHECK(contains(&sc, "bytes available on disk"), "CHKDSK reports free space");

    /* lower-case command word is upper-cased before dispatch */
    reset_out(&sc); strcpy(line, "DIR"); command_exec(&c, line);
    CHECK(contains(&sc, "HELLO.TXT"), "DIR lists HELLO.TXT");
    CHECK(contains(&sc, "1 file(s)"), "DIR reports file count");

    /* TYPE */
    reset_out(&sc); strcpy(line, "type hello.txt"); command_exec(&c, line);
    CHECK(contains(&sc, "HELLO WORLD CONTENTS"), "TYPE prints file contents");

    /* unknown command */
    reset_out(&sc); strcpy(line, "frobnicate x"); command_exec(&c, line);
    CHECK(contains(&sc, "Bad command or file name"), "unknown command rejected");

    /* blank line is a no-op */
    reset_out(&sc); strcpy(line, "   "); command_exec(&c, line);
    CHECK(sc.outlen == 0, "blank line produces no output");

    /* ECHO */
    reset_out(&sc); strcpy(line, "echo hi there"); command_exec(&c, line);
    CHECK(contains(&sc, "hi there"), "ECHO echoes its argument");

    /* COPY then verify the copy exists and DIR shows both */
    reset_out(&sc); strcpy(line, "copy hello.txt copy.txt"); command_exec(&c, line);
    CHECK(contains(&sc, "1 file(s) copied"), "COPY reports success");
    kfile_t chk; CHECK(kfile_open(&v, "copy.txt", &chk) == KFS_OK, "copy.txt was created");
    CHECK(chk.size == 20, "copy.txt has the source's byte size"); kfile_close(&chk);
    reset_out(&sc); strcpy(line, "type copy.txt"); command_exec(&c, line);
    CHECK(contains(&sc, "HELLO WORLD CONTENTS"), "copy.txt has the same contents");

    /* REN */
    reset_out(&sc); strcpy(line, "ren copy.txt renamed.txt"); command_exec(&c, line);
    CHECK(kfile_open(&v, "renamed.txt", &chk) == KFS_OK, "REN created renamed.txt");
    kfile_close(&chk);
    CHECK(kfile_open(&v, "copy.txt", &chk) == KFS_NOTFOUND, "old name gone after REN");

    /* DEL */
    reset_out(&sc); strcpy(line, "del renamed.txt"); command_exec(&c, line);
    CHECK(kfile_open(&v, "renamed.txt", &chk) == KFS_NOTFOUND, "DEL removed the file");
    reset_out(&sc); strcpy(line, "del nope.txt"); command_exec(&c, line);
    CHECK(contains(&sc, "File not found"), "DEL of missing file reports error");

    /* EXIT clears running */
    strcpy(line, "exit"); command_exec(&c, line);
    CHECK(c.running == 0, "EXIT clears the running flag");

    volume_flush(&v); volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

/* The full prompt/read/dispatch loop, fed a scripted session. */
static void test_run_loop(void) {
    printf("test_run_loop\n");
    fat12_create_image(IMG, "320");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);

    stub_con sc; memset(&sc, 0, sizeof(sc));
    sc.in = "ver\r"          /* a command */
            "bogus\r"        /* unknown   */
            "exit\r";        /* leave     */
    console_t con = { sgk, spc, NULL, &sc };
    dos_t dos; dos_init(&dos, &v, &con);
    command_t c; command_init(&c, &dos);

    command_run(&c);
    CHECK(contains(&sc, "A>"), "loop printed the A> prompt");
    CHECK(contains(&sc, "MS-DOS 1.25"), "loop executed VER");
    CHECK(contains(&sc, "Bad command or file name"), "loop rejected the unknown command");
    CHECK(c.running == 0, "loop exited via EXIT");

    volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

/* Read a whole file into a NUL-terminated C string for assertions. */
static void slurp(volume_t *v, const char *name, char *out, size_t cap) {
    kfile_t f; out[0] = 0;
    if (kfile_open(v, name, &f) != KFS_OK) return;
    uint32_t got = 0;
    kfile_read(&f, out, (uint32_t)cap - 1, &got);
    out[got] = 0;
    kfile_close(&f);
}

/* EDIT: control-key bindings the terminal will not intercept. */
static void test_edit(void) {
    printf("test_edit\n");
    fat12_create_image(IMG, "320");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);

    stub_con sc; memset(&sc, 0, sizeof(sc));
    console_t con = { sgk, spc, NULL, &sc };
    dos_t dos; dos_init(&dos, &v, &con);
    command_t c; command_init(&c, &dos);
    char line[64], got[256];

    /* New file: type "Hello", Ctrl-W save, Ctrl-X exit. */
    sc.in = "Hello\x17\x18"; sc.inpos = 0;
    strcpy(line, "edit note.txt"); command_exec(&c, line);
    slurp(&v, "note.txt", got, sizeof(got));
    CHECK(strcmp(got, "Hello") == 0, "EDIT creates a file with typed text");

    /* Reopen, Ctrl-E (end of line), append " World", save, exit. */
    reset_out(&sc); sc.in = "\x05 World\x17\x18"; sc.inpos = 0;
    strcpy(line, "edit note.txt"); command_exec(&c, line);
    slurp(&v, "note.txt", got, sizeof(got));
    CHECK(strcmp(got, "Hello World") == 0, "EDIT loads existing text and appends at line end");

    /* Backspace edit: Ctrl-E to end, two backspaces remove "ld", save, exit. */
    reset_out(&sc); sc.in = "\x05\x7f\x7f\x17\x18"; sc.inpos = 0;
    strcpy(line, "edit note.txt"); command_exec(&c, line);
    slurp(&v, "note.txt", got, sizeof(got));
    CHECK(strcmp(got, "Hello Wor") == 0, "Backspace deletes characters before saving");

    /* Cursor movement: Ctrl-A home, type "X" inserts at start. */
    reset_out(&sc); sc.in = "\x01X\x17\x18"; sc.inpos = 0;
    strcpy(line, "edit note.txt"); command_exec(&c, line);
    slurp(&v, "note.txt", got, sizeof(got));
    CHECK(strcmp(got, "XHello Wor") == 0, "Ctrl-A + insert edits at the line start");

    /* Multi-line: type two lines with Enter between them. */
    reset_out(&sc); sc.in = "line1\rline2\x17\x18"; sc.inpos = 0;
    strcpy(line, "edit multi.txt"); command_exec(&c, line);
    slurp(&v, "multi.txt", got, sizeof(got));
    CHECK(strcmp(got, "line1\nline2") == 0, "Enter inserts a newline between lines");

    /* Exit without saving leaves the file unchanged. */
    reset_out(&sc); sc.in = "ZZZ\x18"; sc.inpos = 0;     /* type then exit, no Ctrl-W */
    strcpy(line, "edit note.txt"); command_exec(&c, line);
    slurp(&v, "note.txt", got, sizeof(got));
    CHECK(strcmp(got, "XHello Wor") == 0, "exit without save leaves file unchanged");

    volume_flush(&v); volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

/* Run one EDIT session on `name` with the given keystroke script, then return
 * the resulting file contents in `out`. */
static void edit_session(volume_t *v, const char *name, const char *keys,
                         char *out, size_t cap) {
    stub_con sc; memset(&sc, 0, sizeof(sc));
    sc.in = keys;
    console_t con = { sgk, spc, NULL, &sc };
    dos_t dos; dos_init(&dos, v, &con);
    command_t c; command_init(&c, &dos);
    char line[64];
    snprintf(line, sizeof(line), "edit %s", name);
    command_exec(&c, line);
    if (out) slurp(v, name, out, cap);
}

/* The key-handling and save/load edge cases from the review. */
static void test_edit_robustness(void) {
    printf("test_edit_robustness\n");
    fat12_create_image(IMG, "320");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);
    char got[256];

    /* --- key handling --- */
    /* arrow-left (ESC [ D) moves the cursor; insert lands mid-text */
    edit_session(&v, "k1.txt", "AB\x1b[D" "X\x17\x18", got, sizeof(got));
    CHECK(strcmp(got, "AXB") == 0, "arrow-left moves cursor (ESC[D)");

    /* Delete key (ESC [ 3 ~) is drained, not inserted as '~' */
    edit_session(&v, "k2.txt", "AB\x1b[3~\x17\x18", got, sizeof(got));
    CHECK(strcmp(got, "AB") == 0, "Delete key injects no stray '~'");

    /* function key (ESC O P) is drained, not inserted as 'P' */
    edit_session(&v, "k3.txt", "AB\x1bOP\x17\x18", got, sizeof(got));
    CHECK(strcmp(got, "AB") == 0, "function key injects no stray char");

    /* a lone ESC does not swallow the following key */
    edit_session(&v, "k4.txt", "A\x1b" "B\x17\x18", got, sizeof(got));
    CHECK(strcmp(got, "AB") == 0, "lone ESC processes the next key normally");

    /* --- save / load --- */
    /* round-trip: a multi-line file reopened and re-saved is byte-identical */
    edit_session(&v, "rt.txt", "a\rb\rc\x17\x18", got, sizeof(got));
    CHECK(strcmp(got, "a\nb\nc") == 0, "multi-line save writes \\n line breaks");
    edit_session(&v, "rt.txt", "\x17\x18", got, sizeof(got));   /* open, save, exit */
    CHECK(strcmp(got, "a\nb\nc") == 0, "reopen + resave is idempotent");

    /* emptying a file then saving yields a 0-byte file */
    make_file(&v, "e.txt", "AB");
    edit_session(&v, "e.txt", "\x05\x7f\x7f\x17\x18", got, sizeof(got));  /* end, bksp x2, save */
    kfile_t f;
    int orc = kfile_open(&v, "e.txt", &f);
    CHECK(orc == KFS_OK && f.size == 0, "emptied file saves as 0 bytes");
    if (orc == KFS_OK) kfile_close(&f);

    /* a file larger than the editor buffer is refused, not truncated */
    {
        kfile_t big; kfile_create(&v, "big.txt", &big);
        uint8_t blk[1000]; memset(blk, 'Z', sizeof(blk));
        for (int i = 0; i < 9; i++) kfile_write(&big, blk, sizeof(blk));  /* 9000 bytes */
        kfile_close(&big);
    }
    stub_con sc; memset(&sc, 0, sizeof(sc)); sc.in = "junk\x17\x18";
    console_t con = { sgk, spc, NULL, &sc };
    dos_t dos; dos_init(&dos, &v, &con);
    command_t c; command_init(&c, &dos);
    char line[32]; strcpy(line, "edit big.txt"); command_exec(&c, line);
    CHECK(contains(&sc, "File too large"), "oversized file is refused");
    kfile_t chk; kfile_open(&v, "big.txt", &chk);
    CHECK(chk.size == 9000, "oversized file left untouched"); kfile_close(&chk);

    volume_flush(&v); volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

/* Atomic save: a write that fails on a full disk must leave the original file
 * intact (and must not leak the clusters it partially grew). */
static void test_edit_atomic_save(void) {
    printf("test_edit_atomic_save\n");
    const char *FIMG = "test_cmd_full.img";
    fat12_create_image(FIMG, "160");          /* 160 KB: 512-byte clusters */
    disk_t d; disk_open(&d, FIMG, 512);
    volume_t v; volume_mount(&v, &d);

    /* an existing file we must not lose */
    make_file(&v, "keep.txt", "ORIGINAL");

    /* fill the volume, leaving just 2 free clusters */
    kfile_t fill; kfile_create(&v, "filler.bin", &fill);
    uint8_t blk[512]; memset(blk, 'F', sizeof(blk));
    while (fat12_count_free(v.fat, v.max_cluster) > 2)
        if (kfile_write(&fill, blk, sizeof(blk)) != KFS_OK) break;
    kfile_close(&fill);
    uint16_t free_before = fat12_count_free(v.fat, v.max_cluster);
    CHECK(free_before == 2, "disk filled to 2 free clusters");

    /* edit keep.txt and try to save ~2000 bytes (needs 4 clusters > 2 free) */
    static char keys[2100];
    memset(keys, 'X', 2000);
    keys[2000] = 0x17; keys[2001] = 0x18; keys[2002] = '\0';   /* Ctrl-W, Ctrl-X */
    char got[64];
    edit_session(&v, "keep.txt", keys, got, sizeof(got));

    CHECK(strcmp(got, "ORIGINAL") == 0, "failed save leaves the original intact");
    CHECK(fat12_count_free(v.fat, v.max_cluster) == free_before,
          "failed save leaks no clusters");

    volume_flush(&v); volume_unmount(&v); disk_close(&d);
    remove(FIMG);
}

/* MKDIR / CD / RMDIR / DIR commands through the parser. */
static void test_directory_commands(void) {
    printf("test_directory_commands\n");
    fat12_create_image(IMG, "320");
    disk_t d; disk_open(&d, IMG, 512);
    volume_t v; volume_mount(&v, &d);

    stub_con sc; memset(&sc, 0, sizeof(sc));
    console_t con = { sgk, spc, NULL, &sc };
    dos_t dos; dos_init(&dos, &v, &con);
    command_t c; command_init(&c, &dos);
    char line[64];

    /* MKDIR then DIR shows it with a <DIR> marker */
    reset_out(&sc); strcpy(line, "mkdir GAMES"); command_exec(&c, line);
    reset_out(&sc); strcpy(line, "dir"); command_exec(&c, line);
    CHECK(contains(&sc, "GAMES") && contains(&sc, "<DIR>"), "DIR shows GAMES <DIR>");

    /* CD into it (cwd changes) and create a file there */
    reset_out(&sc); strcpy(line, "cd GAMES"); command_exec(&c, line);
    CHECK(v.cwd.is_root == 0 && strcmp(v.cwd_path, "\\GAMES") == 0, "CD GAMES updates the cwd");
    edit_session(&v, "PLAY.TXT", "hello\x17\x18", NULL, 0);
    reset_out(&sc); strcpy(line, "dir"); command_exec(&c, line);
    CHECK(contains(&sc, "PLAY.TXT"), "DIR in GAMES lists PLAY.TXT");

    /* CD .. back to root: the inner file is not listed there */
    reset_out(&sc); strcpy(line, "cd .."); command_exec(&c, line);
    CHECK(v.cwd.is_root == 1, "CD .. returns to root");
    reset_out(&sc); strcpy(line, "dir"); command_exec(&c, line);
    CHECK(contains(&sc, "GAMES") && !contains(&sc, "PLAY.TXT"),
          "root DIR shows GAMES but not the inner file");

    /* RMDIR refuses a non-empty directory */
    reset_out(&sc); strcpy(line, "rmdir GAMES"); command_exec(&c, line);
    CHECK(contains(&sc, "Unable to remove directory"), "RMDIR of non-empty dir reports error");

    /* empty it, then RMDIR works and DIR no longer shows it */
    strcpy(line, "cd GAMES"); command_exec(&c, line);
    strcpy(line, "del PLAY.TXT"); command_exec(&c, line);
    strcpy(line, "cd \\"); command_exec(&c, line);
    reset_out(&sc); strcpy(line, "rmdir GAMES"); command_exec(&c, line);
    CHECK(sc.outlen == 0, "RMDIR of empty dir succeeds silently");
    reset_out(&sc); strcpy(line, "dir"); command_exec(&c, line);
    CHECK(!contains(&sc, "GAMES"), "GAMES no longer listed");

    /* CD with no argument prints the current directory */
    reset_out(&sc); strcpy(line, "cd"); command_exec(&c, line);
    CHECK(contains(&sc, "A:\\"), "CD with no arg prints the current path");

    volume_flush(&v); volume_unmount(&v); disk_close(&d);
    remove(IMG);
}

int main(void) {
    printf("== Command processor (COMMAND.ASM port) ==\n");
    test_dispatch_and_commands();
    test_edit();
    test_edit_robustness();
    test_edit_atomic_save();
    test_directory_commands();
    test_run_loop();
    printf("\n%d checks, %d failure(s)\n", g_checks, g_failures);
    return g_failures ? 1 : 0;
}
