/* test_fat.c - Layer 1 unit tests: FAT12 arithmetic, in isolation. */
#include "../src/kernel/fat.h"

#include <stdio.h>
#include <string.h>

static int g_failures = 0, g_checks = 0;
#define CHECK(c, m) do { g_checks++; if (c) printf("  PASS: %s\n", (m)); \
    else { printf("  FAIL: %s  (%s:%d)\n", (m), __FILE__, __LINE__); g_failures++; } } while (0)

/* The packed layout: two 12-bit entries share three bytes. Verify against a
 * hand-computed vector so we know endianness/nibble lanes are right. */
static void test_pack_layout(void) {
    printf("test_pack_layout\n");
    uint8_t fat[6] = {0};
    fat12_set(fat, 0, 0x123);
    fat12_set(fat, 1, 0x456);
    /* even entry 0 -> low 12 bits; odd entry 1 -> high 12 bits, sharing byte 1.
     * bytes: [0]=0x23, [1]=0x61, [2]=0x45  (0x123 | 0x456<<12) */
    CHECK(fat[0] == 0x23 && fat[1] == 0x61 && fat[2] == 0x45,
          "0x123,0x456 pack to bytes 23 61 45");
    CHECK(fat12_get(fat, 0) == 0x123, "get even entry");
    CHECK(fat12_get(fat, 1) == 0x456, "get odd entry");
}

static void test_get_set_roundtrip(void) {
    printf("test_get_set_roundtrip\n");
    uint8_t fat[600];
    memset(fat, 0, sizeof(fat));
    /* Write a distinct value to each entry, then read all back. Adjacent
     * entries share bytes, so this catches lane bleed. */
    for (uint16_t c = 0; c < 256; c++)
        fat12_set(fat, c, (uint16_t)((c * 7 + 1) & 0x0FFF));
    int ok = 1;
    for (uint16_t c = 0; c < 256; c++)
        if (fat12_get(fat, c) != (uint16_t)((c * 7 + 1) & 0x0FFF)) { ok = 0; break; }
    CHECK(ok, "256 distinct entries survive round-trip without bleed");

    fat12_set(fat, 10, 0xFFF);
    fat12_set(fat, 11, 0x000);
    CHECK(fat12_get(fat, 10) == 0xFFF, "0xFFF stored");
    CHECK(fat12_get(fat, 11) == 0x000, "neighbour still 0");
}

static void test_sentinels(void) {
    printf("test_sentinels\n");
    CHECK(fat12_is_free(0x000), "0 is free");
    CHECK(!fat12_is_free(0x002), "2 is not free");
    CHECK(fat12_is_eof(0xFFF), "0xFFF is eof");
    CHECK(fat12_is_eof(0xFF8), "0xFF8 is eof (>= min)");
    CHECK(!fat12_is_eof(0xFF7), "0xFF7 (bad) is not eof");
    CHECK(!fat12_is_eof(0x002), "data cluster is not eof");
}

static void test_alloc_and_free(void) {
    printf("test_alloc_and_free\n");
    uint8_t fat[600];
    memset(fat, 0, sizeof(fat));
    const uint16_t max = 10;             /* clusters 2..10 allocatable (9 of them) */

    CHECK(fat12_count_free(fat, max) == 9, "9 clusters free initially");

    uint16_t a = fat12_alloc(fat, max);
    uint16_t b = fat12_alloc(fat, max);
    CHECK(a == 2 && b == 3, "alloc returns lowest free clusters (2,3)");
    CHECK(fat12_is_eof(fat12_get(fat, a)), "allocated cluster marked EOF");
    CHECK(fat12_count_free(fat, max) == 7, "two fewer free after alloc");

    /* Build a 3-cluster chain 2 -> 3 -> 4(EOF). */
    uint16_t c = fat12_alloc(fat, max);  /* 4 */
    fat12_set(fat, a, b);
    fat12_set(fat, b, c);
    CHECK(fat12_chain_length(fat, a) == 3, "chain length is 3");
    CHECK(fat12_next(fat, a) == b && fat12_next(fat, b) == c, "chain links correct");

    fat12_free_chain(fat, a);
    CHECK(fat12_count_free(fat, max) == 9, "free chain returns all clusters");
    CHECK(fat12_is_free(fat12_get(fat, b)), "middle cluster freed");
}

static void test_alloc_full(void) {
    printf("test_alloc_full\n");
    uint8_t fat[600];
    memset(fat, 0, sizeof(fat));
    const uint16_t max = 4;              /* clusters 2,3,4 */
    CHECK(fat12_alloc(fat, max) == 2, "alloc 2");
    CHECK(fat12_alloc(fat, max) == 3, "alloc 3");
    CHECK(fat12_alloc(fat, max) == 4, "alloc 4");
    CHECK(fat12_alloc(fat, max) == 0, "alloc on full volume returns 0");
}

int main(void) {
    printf("== Layer 1: FAT12 arithmetic ==\n");
    test_pack_layout();
    test_get_set_roundtrip();
    test_sentinels();
    test_alloc_and_free();
    test_alloc_full();
    printf("\n%d checks, %d failure(s)\n", g_checks, g_failures);
    return g_failures ? 1 : 0;
}
