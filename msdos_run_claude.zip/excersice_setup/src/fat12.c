/* fat12.c - see fat12.h */
#include "fat12.h"

#include <string.h>

#define DOS1_SECTOR_SIZE  512u
#define DOS1_RESERVED     1u    /* boot sector */
#define DOS1_NUM_FATS     2u

/* Standard FAT12 floppy geometries. All use 512-byte sectors, one reserved
 * (boot) sector and two FATs. */
typedef struct {
    const char *name;            /* CLI size name, e.g. "720"      */
    uint8_t     media;           /* media descriptor byte          */
    uint32_t    total_sectors;
    uint8_t     sectors_per_cluster;
    uint16_t    root_entries;
    uint8_t     sectors_per_fat;
} fat12_geometry;

static const fat12_geometry GEOMETRY[] = {
    { "160", DOS1_MEDIA_160K,  320, 1,  64, 1 },
    { "180", DOS1_MEDIA_180K,  360, 1,  64, 2 },
    { "320", DOS1_MEDIA_320K,  640, 2, 112, 1 },
    { "360", DOS1_MEDIA_360K,  720, 2, 112, 2 },
    { "720", DOS1_MEDIA_720K, 1440, 2, 112, 3 },
};
#define GEOMETRY_COUNT (sizeof(GEOMETRY) / sizeof(GEOMETRY[0]))

static const fat12_geometry *find_by_media(uint8_t media) {
    for (size_t i = 0; i < GEOMETRY_COUNT; i++)
        if (GEOMETRY[i].media == media)
            return &GEOMETRY[i];
    return NULL;
}

static const fat12_geometry *find_by_name(const char *name) {
    if (!name) return NULL;
    for (size_t i = 0; i < GEOMETRY_COUNT; i++)
        if (strcmp(GEOMETRY[i].name, name) == 0)
            return &GEOMETRY[i];
    return NULL;
}

uint8_t fat12_media_for_geometry(uint32_t sector_size, uint32_t sector_count) {
    if (sector_size != DOS1_SECTOR_SIZE)
        return 0;
    for (size_t i = 0; i < GEOMETRY_COUNT; i++)
        if (GEOMETRY[i].total_sectors == sector_count)
            return GEOMETRY[i].media;
    return 0;
}

int fat12_geometry_by_name(const char *name, uint8_t *media,
                           uint32_t *sector_size, uint32_t *sector_count) {
    const fat12_geometry *g = find_by_name(name);
    if (!g)
        return DISK_ERR_ARG;
    if (media)        *media = g->media;
    if (sector_size)  *sector_size = DOS1_SECTOR_SIZE;
    if (sector_count) *sector_count = g->total_sectors;
    return DISK_OK;
}

int fat12_layout(uint8_t media, uint32_t *total_sectors,
                 uint32_t *sectors_per_cluster, uint32_t *root_entries,
                 uint32_t *sectors_per_fat) {
    const fat12_geometry *g = find_by_media(media);
    if (!g)
        return DISK_ERR_ARG;
    if (total_sectors)       *total_sectors = g->total_sectors;
    if (sectors_per_cluster) *sectors_per_cluster = g->sectors_per_cluster;
    if (root_entries)        *root_entries = g->root_entries;
    if (sectors_per_fat)     *sectors_per_fat = g->sectors_per_fat;
    return DISK_OK;
}

int fat12_format(disk_t *d, uint8_t media) {
    if (!d || !d->data)
        return DISK_ERR_ARG;

    const fat12_geometry *g = find_by_media(media);
    if (!g)
        return DISK_ERR_ARG;                       /* unknown media descriptor */
    if (d->sector_size != DOS1_SECTOR_SIZE || d->sector_count != g->total_sectors)
        return DISK_ERR_ARG;                       /* geometry mismatch        */

    const uint32_t bps = DOS1_SECTOR_SIZE;
    const uint32_t spf = g->sectors_per_fat;
    uint32_t root_sectors = (g->root_entries * 32u + bps - 1) / bps;

    /* Validate the curated table: the system area must fit and each FAT must
     * be large enough to hold every cluster's 12-bit entry. */
    uint32_t sys_sectors = DOS1_RESERVED + DOS1_NUM_FATS * spf + root_sectors;
    if (sys_sectors >= g->total_sectors)
        return DISK_ERR_ARG;
    uint32_t clusters = (g->total_sectors - sys_sectors) / g->sectors_per_cluster;
    uint32_t fat_bytes_needed = (clusters + 2) * 3 / 2 + 1;   /* +2 reserved entries */
    if (fat_bytes_needed > (uint32_t)spf * bps)
        return DISK_ERR_ARG;

    /* --- Boot sector (sector 0) --- NO BPB, NO type string (authentic 1.x).
     * Just a minimal non-bootable stub (JMP $) and the BIOS load signature. */
    uint8_t *bs = d->data;
    memset(bs, 0, bps);
    bs[0] = 0xEB; bs[1] = 0xFE;          /* JMP $  - harmless do-nothing stub */
    bs[510] = 0x55; bs[511] = 0xAA;      /* BIOS boot signature (not a FS marker) */

    /* --- FATs --- the media descriptor lives in FAT[0]; the first two 12-bit
     * entries are 0xF?? and 0xFFF (bytes: media, 0xFF, 0xFF). */
    for (uint32_t f = 0; f < DOS1_NUM_FATS; f++) {
        uint8_t *fat = d->data + (size_t)(DOS1_RESERVED + f * spf) * bps;
        memset(fat, 0, (size_t)spf * bps);
        fat[0] = media;
        fat[1] = 0xFF;
        fat[2] = 0xFF;
    }

    /* --- Root directory --- cleared (0x00 first byte = end-of-directory,
     * the search optimisation MS-DOS 1.25 introduced). */
    uint8_t *root = d->data + (size_t)(DOS1_RESERVED + DOS1_NUM_FATS * spf) * bps;
    memset(root, 0, (size_t)root_sectors * bps);

    d->dirty = 1;
    return DISK_OK;
}

uint8_t fat12_media_descriptor(disk_t *d) {
    if (!d || !d->data || d->sector_size < DOS1_SECTOR_SIZE)
        return 0;
    const uint8_t *fat = d->data + (size_t)DOS1_RESERVED * d->sector_size;
    uint8_t media = fat[0];
    if (media < 0xF8)                 /* kernel forces valid IDs into 0xF8..0xFF */
        return 0;
    if (fat[1] != 0xFF || fat[2] != 0xFF)
        return 0;
    return media;
}

int fat12_create_image(const char *path, const char *name) {
    uint8_t media;
    uint32_t ss, sc;
    int rc = fat12_geometry_by_name(name, &media, &ss, &sc);
    if (rc != DISK_OK)
        return rc;

    disk_t d;
    rc = disk_create(&d, path, ss, sc);
    if (rc != DISK_OK)
        return rc;

    rc = fat12_format(&d, media);
    if (rc != DISK_OK) {
        disk_close(&d);
        return rc;
    }
    return disk_close(&d);            /* flush to file + free */
}
