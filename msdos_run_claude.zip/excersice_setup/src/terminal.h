/* terminal.h - raw-mode keyboard input and screen output.
 *
 * In raw mode the program receives every keypress immediately and
 * unbuffered, including control keys (Ctrl-C, Ctrl-D, ...) and without
 * the kernel performing echo or line editing. This is the console seam a
 * DOS-style character-I/O layer (CONIN/CONOUT) would sit on.
 */
#ifndef TERMINAL_H
#define TERMINAL_H

/* Common control keys, as the raw byte values delivered by the terminal. */
enum {
    KEY_CTRL_C = 0x03,
    KEY_CTRL_D = 0x04,
    KEY_CTRL_L = 0x0C,
    KEY_CTRL_Q = 0x11,
    KEY_ENTER  = 0x0D,   /* carriage return */
    KEY_LF     = 0x0A,
    KEY_BACKSPACE = 0x7F,
    KEY_BS     = 0x08
};

/* term_read_key special returns (distinct from any 0x00-0xFF byte). */
enum {
    TERM_EOF = -1,   /* end of input / stream closed */
    TERM_INTR = -2   /* read interrupted by a signal */
};

/* Put the controlling terminal into raw mode. The previous settings are
 * remembered so term_restore() can undo this. If stdin is not a TTY (e.g.
 * input is piped, as under the test harness) this is a no-op and returns 0
 * so the program still works with redirected input. Returns 0 on success,
 * -1 on failure. */
int term_raw_enable(void);

/* Restore the terminal to the settings captured by term_raw_enable().
 * Idempotent and safe to call from atexit()/signal handlers. */
void term_restore(void);

/* Read a single keypress. Returns the byte (0-255), or TERM_EOF / TERM_INTR. */
int term_read_key(void);

/* Write a NUL-terminated string to the screen verbatim. */
void term_write(const char *s);

/* printf-style output to the screen. In raw mode the terminal does not
 * translate '\n' to CR-LF, so callers should emit "\r\n" for new lines. */
void term_printf(const char *fmt, ...);

/* Clear the screen and home the cursor (ANSI). */
void term_clear(void);

#endif /* TERMINAL_H */
