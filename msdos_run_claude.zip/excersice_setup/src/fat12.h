/* fat12.h - authentic MS-DOS-style FAT12 formatting for a disk image.
 *
 * A FAT12 floppy is identified by the *media descriptor byte* stored in the
 * first byte of the FAT; the MS-DOS 1.25 kernel reads it and maps the drive
 * geometry from a table (see v1.25/source/MSDOS.ASM:980 -- "MOV AH,[SI] ;
 * Get first byte of FAT" / "OR AH,0F8H ; Put in range"). These images carry
 * NO BPB and NO "FAT12" type string (DOS 2.0 / 4.0 inventions) and NO volume
 * label (DOS 2.0) -- a ported DOS recognises the disk purely from the media
 * byte, exactly as the original kernel does.
 *
 * Supported standard floppy geometries (512-byte sectors throughout):
 *   name   KB   sectors  media   notes
 *   160   160     320    0xFE    5.25" SS 8-sector (PC DOS 1.0)
 *   180   180     360    0xFC    5.25" SS 9-sector (DOS 2.0)
 *   320   320     640    0xFF    5.25" DS 8-sector (PC DOS 1.1 / MS-DOS 1.25)
 *   360   360     720    0xFD    5.25" DS 9-sector (DOS 2.0)
 *   720   720    1440    0xF9    3.5"  DS 9-sector (DOS 3.2)
 */
#ifndef FAT12_H
#define FAT12_H

#include <stdbool.h>
#include <stdint.h>

#include "disk.h"

/* Media descriptors for the supported FAT12 floppy formats. */
#define DOS1_MEDIA_160K  0xFEu
#define DOS1_MEDIA_180K  0xFCu
#define DOS1_MEDIA_320K  0xFFu
#define DOS1_MEDIA_360K  0xFDu
#define DOS1_MEDIA_720K  0xF9u

/* Format the open disk image as a FAT12 volume for the given media descriptor.
 * The disk's geometry (sector_size, sector_count) must match that media's
 * standard layout. Returns DISK_OK, or DISK_ERR_ARG if the media byte is
 * unknown or the disk geometry does not match it. */
int fat12_format(disk_t *d, uint8_t media);

/* Return the media descriptor for a standard geometry, or 0 if the
 * (sector_size, sector_count) pair is not a recognised FAT12 floppy. */
uint8_t fat12_media_for_geometry(uint32_t sector_size, uint32_t sector_count);

/* Return the media descriptor recorded in the image's FAT (FAT[0]) if it is a
 * plausible FAT12 volume (FAT[0]=0xF??, FAT[1]=0xFFF), else 0. NULL-safe. */
uint8_t fat12_media_descriptor(disk_t *d);

/* Look up a standard geometry by size name ("160","180","320","360","720").
 * On success fills the non-NULL out-params and returns DISK_OK; returns
 * DISK_ERR_ARG for an unknown name. */
int fat12_geometry_by_name(const char *name, uint8_t *media,
                           uint32_t *sector_size, uint32_t *sector_count);

/* Create and format a blank FAT12 image of the named size at `path`, writing
 * it to disk. `name` is one of the size names above. Returns DISK_OK or a
 * DISK_ERR_* code. */
int fat12_create_image(const char *path, const char *name);

/* Look up the standard layout for a media descriptor. Fills the non-NULL
 * out-params and returns DISK_OK, or DISK_ERR_ARG for an unknown media byte.
 * Used by the kernel volume layer to derive geometry from FAT[0]. */
int fat12_layout(uint8_t media, uint32_t *total_sectors,
                 uint32_t *sectors_per_cluster, uint32_t *root_entries,
                 uint32_t *sectors_per_fat);

#endif /* FAT12_H */
