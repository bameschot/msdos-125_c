/* terminal.c - see terminal.h */
#include "terminal.h"

#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

static struct termios g_orig;     /* settings captured on enable   */
static int g_raw_active = 0;      /* 1 if we changed the terminal  */

int term_raw_enable(void) {
    if (!isatty(STDIN_FILENO))
        return 0;                 /* piped input: nothing to do */

    if (tcgetattr(STDIN_FILENO, &g_orig) != 0)
        return -1;

    struct termios raw = g_orig;
    /* Disable canonical mode, echo, signal generation, and special input
     * processing so every keypress arrives as a raw byte. */
    raw.c_iflag &= ~(unsigned)(IXON | ICRNL | BRKINT | INPCK | ISTRIP);
    raw.c_oflag &= ~(unsigned)(OPOST);
    raw.c_lflag &= ~(unsigned)(ECHO | ICANON | ISIG | IEXTEN);
    raw.c_cflag |= (unsigned)(CS8);
    raw.c_cc[VMIN]  = 1;          /* block until at least one byte */
    raw.c_cc[VTIME] = 0;

    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) != 0)
        return -1;

    g_raw_active = 1;
    return 0;
}

void term_restore(void) {
    if (g_raw_active) {
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &g_orig);
        g_raw_active = 0;
    }
}

int term_read_key(void) {
    unsigned char c;
    ssize_t n = read(STDIN_FILENO, &c, 1);
    if (n == 1)
        return (int)c;
    if (n == 0)
        return TERM_EOF;
    if (errno == EINTR)
        return TERM_INTR;
    return TERM_EOF;
}

void term_write(const char *s) {
    if (s)
        (void)!write(STDOUT_FILENO, s, strlen(s));
}

void term_printf(const char *fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n > 0) {
        size_t len = (n < (int)sizeof(buf)) ? (size_t)n : sizeof(buf) - 1;
        (void)!write(STDOUT_FILENO, buf, len);
    }
}

void term_clear(void) {
    term_write("\x1b[2J\x1b[H");
}
