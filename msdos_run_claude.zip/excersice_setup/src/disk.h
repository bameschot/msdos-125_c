/* disk.h - sector-addressed disk image backed by a file.
 *
 * The image is loaded fully into memory on open and written back on close
 * (or via disk_flush). Reads and writes are sector-granular, matching the
 * model a DOS-style kernel expects (see ASM_TO_C_PORTING_REFERENCE.md, the
 * DPB / IO.ASM seam).
 */
#ifndef DISK_H
#define DISK_H

#include <stddef.h>
#include <stdint.h>

#define DISK_DEFAULT_SECTOR_SIZE 512u

typedef struct {
    char    *path;          /* backing file path (owned)        */
    uint8_t *data;          /* in-memory image (owned)          */
    size_t   size;          /* total bytes                      */
    uint32_t sector_size;   /* bytes per sector                 */
    uint32_t sector_count;  /* size / sector_size               */
    int      dirty;         /* 1 if modified since last flush   */
} disk_t;

/* Status codes returned by the disk API. */
enum {
    DISK_OK = 0,
    DISK_ERR_IO = -1,       /* file open/read/write failure (see errno) */
    DISK_ERR_RANGE = -2,    /* sector out of bounds                     */
    DISK_ERR_ARG = -3,      /* bad argument (null, zero sector size...) */
    DISK_ERR_NOMEM = -4     /* allocation failure                       */
};

/* Open an existing image file and load it into memory. The image size must
 * be a non-zero multiple of sector_size. Returns DISK_OK or an error code. */
int disk_open(disk_t *d, const char *path, uint32_t sector_size);

/* Create a new, zero-filled image of sector_count sectors. The backing file
 * is not written until disk_flush/disk_close. Returns DISK_OK or an error. */
int disk_create(disk_t *d, const char *path, uint32_t sector_size,
                uint32_t sector_count);

/* Read one sector (lba) into buf, which must hold sector_size bytes. */
int disk_read_sector(disk_t *d, uint32_t lba, void *buf);

/* Write one sector (lba) from buf, which must hold sector_size bytes. */
int disk_write_sector(disk_t *d, uint32_t lba, const void *buf);

/* Write the in-memory image back to its file if dirty. */
int disk_flush(disk_t *d);

/* Flush (if dirty) and release all resources. Safe to call on a zeroed disk_t. */
int disk_close(disk_t *d);

/* Human-readable string for a DISK_* status code. */
const char *disk_strerror(int code);

#endif /* DISK_H */
