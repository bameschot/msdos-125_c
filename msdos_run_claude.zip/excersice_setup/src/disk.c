/* disk.c - see disk.h */
#include "disk.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char *disk_strerror(int code) {
    switch (code) {
        case DISK_OK:         return "ok";
        case DISK_ERR_IO:     return "I/O error";
        case DISK_ERR_RANGE:  return "sector out of range";
        case DISK_ERR_ARG:    return "invalid argument";
        case DISK_ERR_NOMEM:  return "out of memory";
        default:              return "unknown error";
    }
}

int disk_open(disk_t *d, const char *path, uint32_t sector_size) {
    if (!d || !path || sector_size == 0)
        return DISK_ERR_ARG;

    memset(d, 0, sizeof(*d));

    FILE *f = fopen(path, "rb");
    if (!f)
        return DISK_ERR_IO;

    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return DISK_ERR_IO; }
    long len = ftell(f);
    if (len < 0) { fclose(f); return DISK_ERR_IO; }
    rewind(f);

    if (len == 0 || (size_t)len % sector_size != 0) {
        fclose(f);
        return DISK_ERR_ARG;
    }

    uint8_t *buf = malloc((size_t)len);
    if (!buf) { fclose(f); return DISK_ERR_NOMEM; }

    if (fread(buf, 1, (size_t)len, f) != (size_t)len) {
        free(buf);
        fclose(f);
        return DISK_ERR_IO;
    }
    fclose(f);

    d->path = strdup(path);
    if (!d->path) { free(buf); return DISK_ERR_NOMEM; }
    d->data         = buf;
    d->size         = (size_t)len;
    d->sector_size  = sector_size;
    d->sector_count = (uint32_t)((size_t)len / sector_size);
    d->dirty        = 0;
    return DISK_OK;
}

int disk_create(disk_t *d, const char *path, uint32_t sector_size,
                uint32_t sector_count) {
    if (!d || !path || sector_size == 0 || sector_count == 0)
        return DISK_ERR_ARG;

    memset(d, 0, sizeof(*d));

    size_t total = (size_t)sector_size * sector_count;
    uint8_t *buf = calloc(1, total);
    if (!buf)
        return DISK_ERR_NOMEM;

    d->path = strdup(path);
    if (!d->path) { free(buf); return DISK_ERR_NOMEM; }
    d->data         = buf;
    d->size         = total;
    d->sector_size  = sector_size;
    d->sector_count = sector_count;
    d->dirty        = 1;   /* nothing on disk yet */
    return DISK_OK;
}

int disk_read_sector(disk_t *d, uint32_t lba, void *buf) {
    if (!d || !d->data || !buf)
        return DISK_ERR_ARG;
    if (lba >= d->sector_count)
        return DISK_ERR_RANGE;
    memcpy(buf, d->data + (size_t)lba * d->sector_size, d->sector_size);
    return DISK_OK;
}

int disk_write_sector(disk_t *d, uint32_t lba, const void *buf) {
    if (!d || !d->data || !buf)
        return DISK_ERR_ARG;
    if (lba >= d->sector_count)
        return DISK_ERR_RANGE;
    memcpy(d->data + (size_t)lba * d->sector_size, buf, d->sector_size);
    d->dirty = 1;
    return DISK_OK;
}

int disk_flush(disk_t *d) {
    if (!d || !d->data || !d->path)
        return DISK_ERR_ARG;
    if (!d->dirty)
        return DISK_OK;

    FILE *f = fopen(d->path, "wb");
    if (!f)
        return DISK_ERR_IO;
    if (fwrite(d->data, 1, d->size, f) != d->size) {
        fclose(f);
        return DISK_ERR_IO;
    }
    if (fflush(f) != 0 || fclose(f) != 0)
        return DISK_ERR_IO;

    d->dirty = 0;
    return DISK_OK;
}

int disk_close(disk_t *d) {
    if (!d)
        return DISK_ERR_ARG;
    int rc = DISK_OK;
    if (d->data && d->path)
        rc = disk_flush(d);
    free(d->data);
    free(d->path);
    memset(d, 0, sizeof(*d));
    return rc;
}
