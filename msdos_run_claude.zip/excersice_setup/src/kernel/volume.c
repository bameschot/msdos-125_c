/* volume.c - see volume.h. Layer 2: mounted volume / DPB. */
#include "volume.h"

#include <stdlib.h>
#include <string.h>

#include "../fat12.h"
#include "fat.h"

int volume_mount(volume_t *v, disk_t *disk) {
    if (!v || !disk || !disk->data)
        return DISK_ERR_ARG;
    memset(v, 0, sizeof(*v));

    const uint32_t bps = disk->sector_size;
    if (bps < 512)
        return DISK_ERR_ARG;

    /* Media descriptor lives in FAT[0], just past the reserved boot sector. */
    const uint16_t reserved = 1;
    uint8_t media = disk->data[(size_t)reserved * bps];

    uint32_t total = 0, spc = 0, root_ent = 0, spf = 0;
    if (fat12_layout(media, &total, &spc, &root_ent, &spf) != DISK_OK)
        return DISK_ERR_ARG;                 /* unformatted / unknown media */
    if (disk->sector_count != total)
        return DISK_ERR_ARG;                 /* geometry mismatch           */

    v->disk                = disk;
    v->media               = media;
    v->bytes_per_sector    = (uint16_t)bps;
    v->sectors_per_cluster = (uint8_t)spc;
    v->reserved_sectors    = reserved;
    v->num_fats            = 2;
    v->sectors_per_fat     = (uint16_t)spf;
    v->root_entries        = (uint16_t)root_ent;
    v->total_sectors       = (uint16_t)total;
    v->bytes_per_cluster   = spc * bps;

    v->root_dir_sectors  = (uint16_t)((root_ent * 32u + bps - 1) / bps);
    v->first_root_sector = (uint16_t)(reserved + v->num_fats * spf);
    v->first_data_sector = (uint16_t)(v->first_root_sector + v->root_dir_sectors);
    v->cluster_count     = (uint16_t)((total - v->first_data_sector) / spc);
    v->max_cluster       = (uint16_t)(v->cluster_count + 1);  /* clusters 2..count+1 */

    /* Load FAT #1 into memory. */
    size_t fat_bytes = (size_t)spf * bps;
    v->fat = malloc(fat_bytes);
    if (!v->fat)
        return DISK_ERR_NOMEM;
    memcpy(v->fat, disk->data + (size_t)reserved * bps, fat_bytes);

    v->cwd.is_root = 1;            /* start at the root directory */
    v->cwd.cluster = 0;
    v->cwd_path[0] = '\0';
    return DISK_OK;
}

int volume_flush(volume_t *v) {
    if (!v || !v->disk || !v->fat)
        return DISK_ERR_ARG;
    size_t fat_bytes = (size_t)v->sectors_per_fat * v->bytes_per_sector;
    for (uint16_t f = 0; f < v->num_fats; f++) {
        size_t off = (size_t)(v->reserved_sectors + f * v->sectors_per_fat)
                     * v->bytes_per_sector;
        memcpy(v->disk->data + off, v->fat, fat_bytes);
    }
    v->disk->dirty = 1;
    return disk_flush(v->disk);
}

void volume_unmount(volume_t *v) {
    if (v) { free(v->fat); v->fat = NULL; v->disk = NULL; }
}

uint32_t volume_cluster_sector(const volume_t *v, uint16_t cluster) {
    return v->first_data_sector
         + (uint32_t)(cluster - FAT12_MIN_CLUSTER) * v->sectors_per_cluster;
}

int volume_read_cluster(volume_t *v, uint16_t cluster, void *buf) {
    if (cluster < FAT12_MIN_CLUSTER || cluster > v->max_cluster)
        return DISK_ERR_RANGE;
    uint32_t s = volume_cluster_sector(v, cluster);
    uint8_t *p = buf;
    for (uint8_t i = 0; i < v->sectors_per_cluster; i++) {
        int rc = disk_read_sector(v->disk, s + i, p + (size_t)i * v->bytes_per_sector);
        if (rc != DISK_OK) return rc;
    }
    return DISK_OK;
}

int volume_write_cluster(volume_t *v, uint16_t cluster, const void *buf) {
    if (cluster < FAT12_MIN_CLUSTER || cluster > v->max_cluster)
        return DISK_ERR_RANGE;
    uint32_t s = volume_cluster_sector(v, cluster);
    const uint8_t *p = buf;
    for (uint8_t i = 0; i < v->sectors_per_cluster; i++) {
        int rc = disk_write_sector(v->disk, s + i, p + (size_t)i * v->bytes_per_sector);
        if (rc != DISK_OK) return rc;
    }
    return DISK_OK;
}

int volume_read_root_sector(volume_t *v, uint16_t idx, void *buf) {
    if (idx >= v->root_dir_sectors) return DISK_ERR_RANGE;
    return disk_read_sector(v->disk, v->first_root_sector + idx, buf);
}

int volume_write_root_sector(volume_t *v, uint16_t idx, const void *buf) {
    if (idx >= v->root_dir_sectors) return DISK_ERR_RANGE;
    return disk_write_sector(v->disk, v->first_root_sector + idx, buf);
}
