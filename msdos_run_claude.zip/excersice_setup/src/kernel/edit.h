/* edit.h - a small full-screen text editor for the EDIT command.
 *
 * Operates on a flat in-memory text buffer through the kernel console
 * (console_t in dos_t), so it works equally on the wrapper's raw-mode terminal
 * and on a test stub. Key bindings are single control bytes that a terminal in
 * raw mode delivers verbatim and never intercepts -- deliberately avoiding the
 * flow-control keys Ctrl-S/Ctrl-Q (XOFF/XON) and the signal keys Ctrl-C/Ctrl-Z:
 *
 *   Ctrl-W  save (write)        Ctrl-X  exit
 *   Ctrl-B  left   Ctrl-F  right   Ctrl-P  up     Ctrl-N  down
 *   Ctrl-A  line start           Ctrl-E  line end
 *   Backspace delete-left        Ctrl-D  delete-right        Enter  newline
 *   (arrow-key escape sequences are also accepted)
 */
#ifndef KERNEL_EDIT_H
#define KERNEL_EDIT_H

#include <stddef.h>

#include "dos.h"

/* Edit `buf` (holding *len bytes, capacity `cap`) in place. When the user
 * presses Ctrl-W, `save(ctx, buf, len)` is invoked to persist the buffer;
 * its return (0 = ok) is shown in the status line. Returns when the user
 * exits (Ctrl-X) or input ends. */
int editor_run(dos_t *dos, const char *title,
               char *buf, size_t *len, size_t cap,
               int (*save)(void *ctx, const char *buf, size_t len), void *ctx);

#endif /* KERNEL_EDIT_H */
