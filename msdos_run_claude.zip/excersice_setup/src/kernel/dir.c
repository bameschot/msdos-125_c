/* dir.c - see dir.h. Layer 3: root directory operations. */
#include "dir.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#include "fat.h"
#include "kfs.h"

_Static_assert(sizeof(dir_entry_t) == DIR_ENTRY_SIZE, "dir_entry_t must be 32 bytes");

#define DIR_DATE_1980  0x0021u

/* Locate directory slot `index` of `loc`: the absolute disk sector and the
 * byte offset within it. Works for the fixed root region and for a
 * subdirectory's cluster chain. Returns KFS_RANGE past the directory's end. */
static int slot_locate(volume_t *v, dir_loc loc, uint16_t index,
                       uint32_t *sector, uint16_t *off) {
    uint16_t eps = v->bytes_per_sector / DIR_ENTRY_SIZE;
    if (loc.is_root) {
        if (index >= v->root_entries) return KFS_RANGE;
        *sector = v->first_root_sector + index / eps;
        *off = (uint16_t)((index % eps) * DIR_ENTRY_SIZE);
        return KFS_OK;
    }
    uint16_t epc = (uint16_t)(v->bytes_per_cluster / DIR_ENTRY_SIZE);
    uint16_t ci = index / epc, within = index % epc;
    uint16_t cl = loc.cluster;
    for (uint16_t i = 0; i < ci; i++) {
        if (cl < FAT12_MIN_CLUSTER) return KFS_RANGE;
        uint16_t nx = fat12_get(v->fat, cl);
        if (fat12_is_eof(nx)) return KFS_RANGE;
        cl = nx;
    }
    if (cl < FAT12_MIN_CLUSTER) return KFS_RANGE;
    *sector = volume_cluster_sector(v, cl) + within / eps;
    *off = (uint16_t)((within % eps) * DIR_ENTRY_SIZE);
    return KFS_OK;
}

static int read_at(volume_t *v, dir_loc loc, uint16_t index, dir_entry_t *e) {
    uint32_t sec; uint16_t off; uint8_t buf[512];
    int rc = slot_locate(v, loc, index, &sec, &off);
    if (rc != KFS_OK) return rc;
    if (disk_read_sector(v->disk, sec, buf) != DISK_OK) return KFS_ERR;
    memcpy(e, buf + off, DIR_ENTRY_SIZE);
    return KFS_OK;
}

static int write_at(volume_t *v, dir_loc loc, uint16_t index, const dir_entry_t *e) {
    uint32_t sec; uint16_t off; uint8_t buf[512];
    int rc = slot_locate(v, loc, index, &sec, &off);
    if (rc != KFS_OK) return rc;
    if (disk_read_sector(v->disk, sec, buf) != DISK_OK) return KFS_ERR;
    memcpy(buf + off, e, DIR_ENTRY_SIZE);
    if (disk_write_sector(v->disk, sec, buf) != DISK_OK) return KFS_ERR;
    return KFS_OK;
}

/* Shared name parser. If `wild`, '?' passes through and '*' fills the rest of
 * the current field (name or extension) with '?'. */
static int parse(const char *s, uint8_t out[11], bool wild) {
    memset(out, ' ', 11);
    if (!s || !*s)
        return KFS_ARG;

    int n = 0;
    while (*s && *s != '.') {
        if (wild && *s == '*') { while (n < 8) out[n++] = '?'; while (*s && *s != '.') s++; break; }
        if (n >= 8) return KFS_ARG;
        char c = *s++;
        if (!wild && c == '?') return KFS_ARG;
        out[n++] = (uint8_t)toupper((unsigned char)c);
    }
    if (n == 0)
        return KFS_ARG;

    if (*s == '.') {
        s++;
        int e = 0;
        while (*s) {
            if (wild && *s == '*') { while (e < 3) out[8 + e++] = '?'; break; }
            if (e >= 3) return KFS_ARG;
            char c = *s++;
            if (!wild && c == '?') return KFS_ARG;
            out[8 + e++] = (uint8_t)toupper((unsigned char)c);
        }
    }
    return KFS_OK;
}

int dir_parse_name(const char *s, uint8_t out[11])    { return parse(s, out, false); }
int dir_parse_pattern(const char *s, uint8_t out[11]) { return parse(s, out, true);  }

void dir_format_name(const uint8_t name[11], char out[13]) {
    int p = 0;
    for (int i = 0; i < 8 && name[i] != ' '; i++) out[p++] = (char)name[i];
    if (name[8] != ' ') {
        out[p++] = '.';
        for (int i = 8; i < 11 && name[i] != ' '; i++) out[p++] = (char)name[i];
    }
    out[p] = '\0';
}

bool dir_name_match(const uint8_t pattern[11], const uint8_t name[11]) {
    for (int i = 0; i < 11; i++)
        if (pattern[i] != '?' && pattern[i] != name[i])
            return false;
    return true;
}

/* The public entry/find/search functions operate on the volume's current
 * directory (root by default), so all file operations are cwd-relative. */
int dir_read_entry(volume_t *v, uint16_t index, dir_entry_t *e) {
    return read_at(v, v->cwd, index, e);
}
int dir_write_entry(volume_t *v, uint16_t index, const dir_entry_t *e) {
    return write_at(v, v->cwd, index, e);
}

static int find_in(volume_t *v, dir_loc loc, const uint8_t name[11],
                   uint16_t *index, dir_entry_t *e) {
    dir_entry_t cur;
    for (uint16_t i = 0; ; i++) {
        int rc = read_at(v, loc, i, &cur);
        if (rc == KFS_RANGE) break;
        if (rc != KFS_OK) return rc;
        if (cur.name[0] == DIR_END) break;
        if (cur.name[0] == DIR_FREE) continue;
        if (memcmp(cur.name, name, 11) == 0) {
            if (index) *index = i;
            if (e) *e = cur;
            return KFS_OK;
        }
    }
    return KFS_NOTFOUND;
}

int dir_find(volume_t *v, const uint8_t name[11], uint16_t *index, dir_entry_t *e) {
    return find_in(v, v->cwd, name, index, e);
}

int dir_find_free(volume_t *v, uint16_t *index) {
    dir_entry_t cur;
    for (uint16_t i = 0; ; i++) {
        int rc = read_at(v, v->cwd, i, &cur);
        if (rc == KFS_RANGE) break;                  /* directory is full */
        if (rc != KFS_OK) return rc;
        if (cur.name[0] == DIR_END || cur.name[0] == DIR_FREE) {
            if (index) *index = i;
            return KFS_OK;
        }
    }
    return KFS_FULL;
}

int dir_search(volume_t *v, const uint8_t pattern[11], uint16_t *index, dir_entry_t *e) {
    dir_entry_t cur;
    for (uint16_t i = *index; ; i++) {
        int rc = read_at(v, v->cwd, i, &cur);
        if (rc == KFS_RANGE) break;
        if (rc != KFS_OK) return rc;
        if (cur.name[0] == DIR_END) break;
        if (cur.name[0] == DIR_FREE) continue;
        if (dir_name_match(pattern, cur.name)) {
            if (e) *e = cur;
            *index = (uint16_t)(i + 1);
            return KFS_OK;
        }
    }
    return KFS_NOTFOUND;
}

/* ---- subdirectories: MKDIR / RMDIR / CHDIR ---- */

static void dotname(uint8_t out[11], int dots) {
    memset(out, ' ', 11);
    out[0] = '.';
    if (dots == 2) out[1] = '.';
}

int dir_mkdir(volume_t *v, const char *name) {
    uint8_t n[11];
    if (dir_parse_name(name, n) != KFS_OK) return KFS_ARG;
    if (find_in(v, v->cwd, n, NULL, NULL) == KFS_OK) return KFS_EXISTS;

    uint16_t slot;
    int rc = dir_find_free(v, &slot);
    if (rc != KFS_OK) return rc;
    uint16_t cl = fat12_alloc(v->fat, v->max_cluster);
    if (!cl) return KFS_FULL;

    /* initialise the new directory cluster with "." and ".." */
    uint8_t *buf = calloc(1, v->bytes_per_cluster);
    if (!buf) { fat12_set(v->fat, cl, FAT12_FREE); return KFS_ERR; }
    dir_entry_t dot;  memset(&dot, 0, sizeof dot);
    dotname(dot.name, 1); dot.attr = DIR_ATTR_DIR; dot.first_cluster = cl; dot.date = DIR_DATE_1980;
    memcpy(buf, &dot, DIR_ENTRY_SIZE);
    dir_entry_t dd; memset(&dd, 0, sizeof dd);
    dotname(dd.name, 2); dd.attr = DIR_ATTR_DIR;
    dd.first_cluster = v->cwd.is_root ? 0 : v->cwd.cluster; dd.date = DIR_DATE_1980;
    memcpy(buf + DIR_ENTRY_SIZE, &dd, DIR_ENTRY_SIZE);
    int wrc = volume_write_cluster(v, cl, buf);
    free(buf);
    if (wrc != DISK_OK) { fat12_set(v->fat, cl, FAT12_FREE); return KFS_ERR; }

    /* link it into the parent (current) directory */
    dir_entry_t e; memset(&e, 0, sizeof e);
    memcpy(e.name, n, 11); e.attr = DIR_ATTR_DIR; e.first_cluster = cl; e.date = DIR_DATE_1980;
    rc = write_at(v, v->cwd, slot, &e);
    if (rc != KFS_OK) return rc;
    return volume_flush(v) == DISK_OK ? KFS_OK : KFS_ERR;
}

int dir_rmdir(volume_t *v, const char *name) {
    uint8_t n[11];
    if (dir_parse_name(name, n) != KFS_OK) return KFS_ARG;
    uint16_t slot; dir_entry_t e;
    if (find_in(v, v->cwd, n, &slot, &e) != KFS_OK) return KFS_NOTFOUND;
    if (!(e.attr & DIR_ATTR_DIR)) return KFS_ARG;        /* not a directory */

    /* must be empty apart from "." and ".." */
    dir_loc loc = { 0, e.first_cluster };
    dir_entry_t c;
    for (uint16_t i = 0; ; i++) {
        int rc = read_at(v, loc, i, &c);
        if (rc == KFS_RANGE) break;
        if (rc != KFS_OK) return rc;
        if (c.name[0] == DIR_END) break;
        if (c.name[0] == DIR_FREE) continue;
        if (c.name[0] == '.') continue;                  /* "." or ".." */
        return KFS_NOTEMPTY;
    }

    if (e.first_cluster) fat12_free_chain(v->fat, e.first_cluster);
    e.name[0] = DIR_FREE;
    int rc = write_at(v, v->cwd, slot, &e);
    if (rc != KFS_OK) return rc;
    return volume_flush(v) == DISK_OK ? KFS_OK : KFS_ERR;
}

static void path_strip_last(char *p) {        /* "\A\B" -> "\A", "\A" -> "" */
    char *bs = strrchr(p, '\\');
    if (bs) *bs = '\0'; else p[0] = '\0';
}

int dir_chdir(volume_t *v, const char *path) {
    while (*path == ' ' || *path == '\t') path++;

    if (path[0] == '\\' || path[0] == '/') {            /* absolute: reset to root */
        v->cwd.is_root = 1; v->cwd.cluster = 0; v->cwd_path[0] = '\0';
        path++;
        if (*path == '\0') return KFS_OK;
    }
    if (path[0] == '.' && path[1] == '.' && (path[2] == '\0' || path[2] == ' ')) {
        if (v->cwd.is_root) return KFS_OK;
        dir_entry_t dd;
        if (read_at(v, v->cwd, 1, &dd) != KFS_OK) return KFS_ERR;   /* the ".." entry */
        if (dd.first_cluster == 0) { v->cwd.is_root = 1; v->cwd.cluster = 0; v->cwd_path[0] = '\0'; }
        else { v->cwd.is_root = 0; v->cwd.cluster = dd.first_cluster; path_strip_last(v->cwd_path); }
        return KFS_OK;
    }
    if (path[0] == '.' && (path[1] == '\0' || path[1] == ' ')) return KFS_OK;  /* "." */
    if (*path == '\0') return KFS_OK;

    uint8_t n[11];
    if (dir_parse_name(path, n) != KFS_OK) return KFS_ARG;
    dir_entry_t e;
    if (find_in(v, v->cwd, n, NULL, &e) != KFS_OK) return KFS_NOTFOUND;
    if (!(e.attr & DIR_ATTR_DIR)) return KFS_ARG;

    v->cwd.is_root = 0; v->cwd.cluster = e.first_cluster;
    char comp[13]; dir_format_name(n, comp);
    size_t l = strlen(v->cwd_path);
    if (l + 1 + strlen(comp) < sizeof v->cwd_path) {
        v->cwd_path[l] = '\\';
        strcpy(v->cwd_path + l + 1, comp);
    }
    return KFS_OK;
}
