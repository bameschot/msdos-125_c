/* kfs.c - kernel status code strings. */
#include "kfs.h"

const char *kfs_strerror(int code) {
    switch (code) {
        case KFS_OK:       return "ok";
        case KFS_ERR:      return "I/O error";
        case KFS_NOTFOUND: return "not found";
        case KFS_EXISTS:   return "already exists";
        case KFS_FULL:     return "directory or volume full";
        case KFS_RANGE:    return "out of range";
        case KFS_ARG:      return "invalid argument";
        case KFS_EOF:      return "end of file";
        case KFS_NOTEMPTY: return "directory not empty";
        default:           return "unknown error";
    }
}
