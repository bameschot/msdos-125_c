/* command.c - see command.h. C port of COMMAND.ASM (transient interpreter). */
#include "command.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

#include "basic.h"
#include "dir.h"
#include "edit.h"
#include "fat.h"
#include "kfs.h"
#include "volume.h"

#define EDIT_BUF_MAX 8192u   /* editor capacity (< 64 KB so a save fits one record) */

#define VER_STRING "MS-DOS 1.25 (C port)"

/* ---- I/O helpers, all through INT 21H (dos_call) ---- */
static void put_ch(command_t *c, char ch) {
    dos_regs r; memset(&r, 0, sizeof(r));
    r.ah = DOS_CONOUT; r.dl = (uint8_t)ch;
    dos_call(c->dos, &r);
}
static void say(command_t *c, const char *s) { for (; *s; s++) put_ch(c, *s); }

/* Read a line from the console (function-0Ah-style: echo + backspace), but
 * returning -1 at end of input so the run loop terminates cleanly. */
static int read_line(command_t *c, char *buf, size_t cap) {
    console_t *con = c->dos->con;
    size_t n = 0;
    for (;;) {
        int k = con && con->getkey ? con->getkey(con->ctx) : -1;
        if (k < 0) return (n == 0) ? -1 : (int)n;          /* EOF */
        if (k == '\r' || k == '\n') { say(c, "\r\n"); break; }
        if (k == 0x08 || k == 0x7F) { if (n) { n--; say(c, "\b \b"); } continue; }
        if (k >= 0x20 && n + 1 < cap) { buf[n++] = (char)k; put_ch(c, (char)k); }
    }
    buf[n] = '\0';
    return (int)n;
}

/* Print a number as decimal (no printf in the kernel path). */
static void say_uint(command_t *c, uint32_t v) {
    char tmp[12]; int i = 0;
    if (v == 0) { put_ch(c, '0'); return; }
    while (v) { tmp[i++] = (char)('0' + v % 10); v /= 10; }
    while (i) put_ch(c, tmp[--i]);
}

/* ---- internal command handlers ---- */

/* DIR [pattern] : SEARCH FIRST/NEXT over the pattern (default *.*). */
static void cmd_dir(command_t *c, char *args) {
    uint8_t entry[32];
    dos_regs r; memset(&r, 0, sizeof(r));
    r.ah = DOS_SET_DTA; r.dx_ptr = entry; dos_call(c->dos, &r);

    dos_fcb_t pat; memset(&pat, 0, sizeof(pat));
    if (*args) {
        if (dir_parse_pattern(args, pat.name) != KFS_OK) { say(c, "Invalid filename\r\n"); return; }
    } else {
        memset(pat.name, '?', 11);                 /* *.* */
    }

    int fn = DOS_SEARCH_FIRST, count = 0;
    for (;;) {
        memset(&r, 0, sizeof(r)); r.ah = (uint8_t)fn; r.dx_ptr = &pat;
        dos_call(c->dos, &r);
        if (r.al != 0) break;
        fn = DOS_SEARCH_NEXT;
        char nm[13]; dir_format_name(entry, nm);
        say(c, nm);
        for (size_t i = strlen(nm); i < 14; i++) put_ch(c, ' ');
        if (entry[11] & DIR_ATTR_DIR) {            /* attribute byte at offset 11 */
            say(c, "<DIR>");
        } else {
            uint32_t size; memcpy(&size, entry + 28, 4);
            say_uint(c, size);
        }
        say(c, "\r\n");
        count++;
    }
    if (count == 0) say(c, "File not found\r\n");
    else { say(c, "    "); say_uint(c, (uint32_t)count); say(c, " file(s)\r\n"); }
}

/* TYPE <file> : OPEN then SEQ READ, echoing the file's bytes. */
static void cmd_type(command_t *c, char *args) {
    if (!*args) { say(c, "Required parameter missing\r\n"); return; }
    dos_fcb_t fcb;
    if (dos_fcb_init(&fcb, args) != KFS_OK) { say(c, "Invalid filename\r\n"); return; }

    uint8_t dta[128];
    dos_regs r; memset(&r, 0, sizeof(r)); r.ah = DOS_SET_DTA; r.dx_ptr = dta; dos_call(c->dos, &r);
    memset(&r, 0, sizeof(r)); r.ah = DOS_OPEN; r.dx_ptr = &fcb; dos_call(c->dos, &r);
    if (r.al != 0) { say(c, "File not found\r\n"); return; }

    uint32_t remaining = fcb.file_size;
    while (remaining) {
        memset(&r, 0, sizeof(r)); r.ah = DOS_SEQ_READ; r.dx_ptr = &fcb;
        dos_call(c->dos, &r);
        if (r.al == 1) break;
        uint32_t n = remaining < 128 ? remaining : 128;
        for (uint32_t i = 0; i < n; i++) put_ch(c, (char)dta[i]);
        remaining -= n;
    }
    say(c, "\r\n");
}

/* DEL/ERASE <file> */
static void cmd_del(command_t *c, char *args) {
    if (!*args) { say(c, "Required parameter missing\r\n"); return; }
    dos_fcb_t fcb;
    if (dos_fcb_init(&fcb, args) != KFS_OK) { say(c, "Invalid filename\r\n"); return; }
    dos_regs r; memset(&r, 0, sizeof(r)); r.ah = DOS_DELETE; r.dx_ptr = &fcb;
    dos_call(c->dos, &r);
    if (r.al != 0) say(c, "File not found\r\n");
}

/* MKDIR/MD <name> : function 39h */
static void cmd_mkdir(command_t *c, char *args) {
    char *n = strtok(args, " \t");
    if (!n) { say(c, "Required parameter missing\r\n"); return; }
    dos_regs r; memset(&r, 0, sizeof(r)); r.ah = DOS_MKDIR; r.dx_ptr = n;
    dos_call(c->dos, &r);
    if (r.al != 0) say(c, "Unable to create directory\r\n");
}
/* RMDIR/RD <name> : function 3Ah */
static void cmd_rmdir(command_t *c, char *args) {
    char *n = strtok(args, " \t");
    if (!n) { say(c, "Required parameter missing\r\n"); return; }
    dos_regs r; memset(&r, 0, sizeof(r)); r.ah = DOS_RMDIR; r.dx_ptr = n;
    dos_call(c->dos, &r);
    if (r.al != 0) say(c, "Unable to remove directory\r\n");
}
/* CD/CHDIR [path] : function 3Bh (no arg prints the current directory) */
static void cmd_cd(command_t *c, char *args) {
    char *p = strtok(args, " \t");
    if (!p) {                                  /* show current directory */
        put_ch(c, c->drive); put_ch(c, ':');
        const char *path = c->dos->vol ? c->dos->vol->cwd_path : "";
        say(c, *path ? path : "\\");
        say(c, "\r\n");
        return;
    }
    dos_regs r; memset(&r, 0, sizeof(r)); r.ah = DOS_CHDIR; r.dx_ptr = p;
    dos_call(c->dos, &r);
    if (r.al != 0) say(c, "Invalid directory\r\n");
}

/* REN/RENAME <old> <new> : function 17h */
static void cmd_ren(command_t *c, char *args) {
    char *old = strtok(args, " \t");
    char *neu = strtok(NULL, " \t");
    if (!old || !neu) { say(c, "Required parameter missing\r\n"); return; }
    dos_rename_t req; memset(&req, 0, sizeof(req));
    if (dir_parse_name(old, req.old) != KFS_OK || dir_parse_name(neu, req.newname) != KFS_OK) {
        say(c, "Invalid filename\r\n"); return;
    }
    dos_regs r; memset(&r, 0, sizeof(r)); r.ah = DOS_RENAME; r.dx_ptr = &req;
    dos_call(c->dos, &r);
    if (r.al != 0) say(c, "Rename failed\r\n");
}

/* COPY <src> <dst> : byte-accurate copy through SEQ READ/WRITE. */
static void cmd_copy(command_t *c, char *args) {
    char *src = strtok(args, " \t");
    char *dst = strtok(NULL, " \t");
    if (!src || !dst) { say(c, "Required parameter missing\r\n"); return; }

    dos_fcb_t in, out;
    if (dos_fcb_init(&in, src) != KFS_OK || dos_fcb_init(&out, dst) != KFS_OK) {
        say(c, "Invalid filename\r\n"); return;
    }
    uint8_t dta[128];
    dos_regs r; memset(&r, 0, sizeof(r)); r.ah = DOS_SET_DTA; r.dx_ptr = dta; dos_call(c->dos, &r);

    memset(&r, 0, sizeof(r)); r.ah = DOS_OPEN; r.dx_ptr = &in; dos_call(c->dos, &r);
    if (r.al != 0) { say(c, "File not found\r\n"); return; }
    memset(&r, 0, sizeof(r)); r.ah = DOS_CREATE; r.dx_ptr = &out; dos_call(c->dos, &r);
    if (r.al != 0) { say(c, "Cannot create destination\r\n"); return; }

    uint32_t remaining = in.file_size;
    while (remaining) {
        memset(&r, 0, sizeof(r)); r.ah = DOS_SEQ_READ; r.dx_ptr = &in; dos_call(c->dos, &r);
        if (r.al == 1) break;
        uint32_t n = remaining < 128 ? remaining : 128;
        out.rec_size = (uint16_t)n;
        memset(&r, 0, sizeof(r)); r.ah = DOS_SEQ_WRITE; r.dx_ptr = &out; dos_call(c->dos, &r);
        if (r.al != 0) { say(c, "Write error\r\n"); break; }
        remaining -= n;
    }
    memset(&r, 0, sizeof(r)); r.ah = DOS_CLOSE; r.dx_ptr = &out; dos_call(c->dos, &r);
    say(c, "    1 file(s) copied\r\n");
}

static void cmd_echo(command_t *c, char *args) { say(c, *args ? args : "ECHO is on"); say(c, "\r\n"); }
static void cmd_rem(command_t *c, char *args)  { (void)c; (void)args; }
static void cmd_cls(command_t *c, char *args)  { (void)args; say(c, "\x1b[2J\x1b[H"); }
static void cmd_ver(command_t *c, char *args)  { (void)args; say(c, VER_STRING "\r\n"); }
static void cmd_date(command_t *c, char *args) { (void)args; say(c, "Current date is Tue 1-01-1980 (no real-time clock)\r\n"); }
static void cmd_time(command_t *c, char *args) { (void)args; say(c, "Current time is 0:00:00.00 (no real-time clock)\r\n"); }
static void cmd_exit(command_t *c, char *args) { (void)args; c->running = 0; }

/* CHKDSK : report disk usage. File count/bytes come from a directory scan via
 * SEARCH FIRST/NEXT (INT 21H); capacity/free come from the mounted volume's
 * FAT, the way an external CHKDSK reads the allocation table. */
static void cmd_chkdsk(command_t *c, char *args) {
    (void)args;
    volume_t *v = c->dos->vol;
    if (!v) { say(c, "No disk mounted\r\n"); return; }

    uint8_t entry[32];
    dos_regs r; memset(&r, 0, sizeof(r));
    r.ah = DOS_SET_DTA; r.dx_ptr = entry; dos_call(c->dos, &r);

    dos_fcb_t pat; memset(&pat, 0, sizeof(pat));
    memset(pat.name, '?', 11);                 /* *.* */
    uint32_t files = 0, file_bytes = 0;
    int fn = DOS_SEARCH_FIRST;
    for (;;) {
        memset(&r, 0, sizeof(r)); r.ah = (uint8_t)fn; r.dx_ptr = &pat;
        dos_call(c->dos, &r);
        if (r.al != 0) break;
        fn = DOS_SEARCH_NEXT;
        uint32_t size; memcpy(&size, entry + 28, 4);
        files++; file_bytes += size;
    }

    uint32_t total = (uint32_t)v->cluster_count * v->bytes_per_cluster;
    uint32_t avail = (uint32_t)fat12_count_free(v->fat, v->max_cluster) * v->bytes_per_cluster;

    say_uint(c, total);      say(c, " bytes total disk space\r\n");
    say_uint(c, file_bytes); say(c, " bytes in "); say_uint(c, files); say(c, " user files\r\n");
    say_uint(c, avail);      say(c, " bytes available on disk\r\n");
}

/* EDIT save callback. Writes atomically: the buffer goes to a temp file first,
 * and only once that fully succeeds is the original replaced (delete + rename).
 * So a failure mid-write (e.g. disk full) leaves the original file intact. The
 * whole buffer is one record (rec_size = len) so the byte length is exact
 * (len < 64 KB by construction). */
#define EDIT_TMP_NAME "EDITTMP.$$$"
struct edit_ctx { command_t *c; const char *name; };

static int edit_save(void *vctx, const char *buf, size_t len) {
    struct edit_ctx *x = vctx;
    dos_t *dos = x->c->dos;
    dos_regs r;

    /* 1. write the buffer to a temp file */
    dos_fcb_t tmp;
    if (dos_fcb_init(&tmp, EDIT_TMP_NAME) != KFS_OK) return -1;
    memset(&r, 0, sizeof(r)); r.ah = DOS_SET_DTA; r.dx_ptr = (void *)buf; dos_call(dos, &r);
    memset(&r, 0, sizeof(r)); r.ah = DOS_CREATE; r.dx_ptr = &tmp; dos_call(dos, &r);
    if (r.al != 0) return -1;                       /* original untouched */
    if (len > 0) {
        tmp.rec_size = (uint16_t)len;
        memset(&r, 0, sizeof(r)); r.ah = DOS_SEQ_WRITE; r.dx_ptr = &tmp; dos_call(dos, &r);
        if (r.al != 0) {                            /* write failed: discard temp, keep original */
            memset(&r, 0, sizeof(r)); r.ah = DOS_CLOSE;  r.dx_ptr = &tmp; dos_call(dos, &r);
            dos_fcb_t df; dos_fcb_init(&df, EDIT_TMP_NAME);
            memset(&r, 0, sizeof(r)); r.ah = DOS_DELETE; r.dx_ptr = &df;  dos_call(dos, &r);
            return -1;
        }
    }
    memset(&r, 0, sizeof(r)); r.ah = DOS_CLOSE; r.dx_ptr = &tmp; dos_call(dos, &r);
    if (r.al != 0) return -1;

    /* 2. replace the target: delete it (ok if absent), then rename temp -> target */
    dos_fcb_t del; dos_fcb_init(&del, x->name);
    memset(&r, 0, sizeof(r)); r.ah = DOS_DELETE; r.dx_ptr = &del; dos_call(dos, &r);

    dos_rename_t rn; memset(&rn, 0, sizeof(rn));
    if (dir_parse_name(EDIT_TMP_NAME, rn.old) != KFS_OK ||
        dir_parse_name(x->name, rn.newname) != KFS_OK) return -1;
    memset(&r, 0, sizeof(r)); r.ah = DOS_RENAME; r.dx_ptr = &rn; dos_call(dos, &r);
    return r.al == 0 ? 0 : -1;
}

/* EDIT <file> : load the file (if any) into a buffer and run the editor. */
static char g_edit_buf[EDIT_BUF_MAX];
static void cmd_edit(command_t *c, char *args) {
    if (!*args) { say(c, "Required parameter missing\r\n"); return; }
    dos_fcb_t fcb;
    if (dos_fcb_init(&fcb, args) != KFS_OK) { say(c, "Invalid filename\r\n"); return; }

    /* Load existing contents (reading 128-byte records is position-correct). */
    size_t len = 0;
    uint8_t dta[128];
    dos_regs r; memset(&r, 0, sizeof(r)); r.ah = DOS_SET_DTA; r.dx_ptr = dta; dos_call(c->dos, &r);
    memset(&r, 0, sizeof(r)); r.ah = DOS_OPEN; r.dx_ptr = &fcb; dos_call(c->dos, &r);
    if (r.al == 0) {
        if (fcb.file_size > EDIT_BUF_MAX) {   /* refuse rather than load-truncate-on-save */
            say(c, "File too large to edit\r\n");
            return;
        }
        uint32_t remaining = fcb.file_size;
        while (remaining && len < EDIT_BUF_MAX) {
            memset(&r, 0, sizeof(r)); r.ah = DOS_SEQ_READ; r.dx_ptr = &fcb; dos_call(c->dos, &r);
            if (r.al == 1) break;
            uint32_t n = remaining < 128 ? remaining : 128;
            if (len + n > EDIT_BUF_MAX) n = (uint32_t)(EDIT_BUF_MAX - len);
            memcpy(g_edit_buf + len, dta, n);
            len += n; remaining -= n;
        }
    }

    struct edit_ctx ctx = { c, args };
    editor_run(c->dos, args, g_edit_buf, &len, EDIT_BUF_MAX, edit_save, &ctx);
}

/* BASIC <file> : load a (.BAS) program and run it through the interpreter. */
#define BASIC_BUF_MAX 16384u
static char g_basic_buf[BASIC_BUF_MAX + 1];
static void cmd_basic(command_t *c, char *args) {
    char *fname = strtok(args, " \t");
    if (!fname) { say(c, "Required parameter missing\r\n"); return; }
    char namebuf[20];
    if (!strchr(fname, '.')) {                  /* default extension .BAS */
        snprintf(namebuf, sizeof namebuf, "%s.BAS", fname);
        fname = namebuf;
    }
    dos_fcb_t fcb;
    if (dos_fcb_init(&fcb, fname) != KFS_OK) { say(c, "Invalid filename\r\n"); return; }

    uint8_t dta[128];
    dos_regs r; memset(&r, 0, sizeof(r)); r.ah = DOS_SET_DTA; r.dx_ptr = dta; dos_call(c->dos, &r);
    memset(&r, 0, sizeof(r)); r.ah = DOS_OPEN; r.dx_ptr = &fcb; dos_call(c->dos, &r);
    if (r.al != 0) { say(c, "File not found\r\n"); return; }
    if (fcb.file_size > BASIC_BUF_MAX) { say(c, "Program too large\r\n"); return; }

    size_t len = 0;
    uint32_t remaining = fcb.file_size;
    while (remaining) {
        memset(&r, 0, sizeof(r)); r.ah = DOS_SEQ_READ; r.dx_ptr = &fcb; dos_call(c->dos, &r);
        if (r.al == 1) break;
        uint32_t n = remaining < 128 ? remaining : 128;
        memcpy(g_basic_buf + len, dta, n);
        len += n; remaining -= n;
    }
    g_basic_buf[len] = '\0';
    basic_run(c->dos, g_basic_buf, len);
}

/* HELP : list the built-in commands. */
static void cmd_help(command_t *c, char *args) {
    (void)args;
    say(c,
        "Internal commands:\r\n"
        "  DIR [pat]     list files          TYPE <f>      show a file\r\n"
        "  COPY <s> <d>  copy a file         REN <o> <n>   rename a file\r\n"
        "  DEL <f>       delete a file       CHKDSK        check the disk\r\n"
        "  EDIT <f>      edit a text file    BASIC <f>     run a BASIC program\r\n"
        "  MKDIR <d>     make a directory    RMDIR <d>     remove a directory\r\n"
        "  CD [path]     change directory    ECHO <text>   echo text\r\n"
        "  CLS           clear the screen    VER           show version\r\n"
        "  DATE / TIME   show date / time    HELP          this list\r\n"
        "  EXIT          leave the shell\r\n");
}

/* The internal-command table (COMMAND.ASM keeps an equivalent name table). */
typedef void (*cmd_fn)(command_t *, char *);
static const struct { const char *name; cmd_fn fn; } COMMANDS[] = {
    { "DIR",    cmd_dir  }, { "TYPE",   cmd_type }, { "DEL",  cmd_del  },
    { "ERASE",  cmd_del  }, { "REN",    cmd_ren  }, { "RENAME", cmd_ren },
    { "COPY",   cmd_copy }, { "ECHO",   cmd_echo }, { "REM",  cmd_rem  },
    { "CLS",    cmd_cls  }, { "VER",    cmd_ver  }, { "DATE", cmd_date },
    { "TIME",   cmd_time }, { "CHKDSK", cmd_chkdsk }, { "HELP", cmd_help },
    { "EDIT",   cmd_edit }, { "BASIC",  cmd_basic },
    { "MKDIR",  cmd_mkdir }, { "MD", cmd_mkdir }, { "RMDIR", cmd_rmdir }, { "RD", cmd_rmdir },
    { "CD",     cmd_cd }, { "CHDIR", cmd_cd },
    { "EXIT",   cmd_exit }, { "QUIT",   cmd_exit },
};
#define NUM_COMMANDS (sizeof(COMMANDS) / sizeof(COMMANDS[0]))

void command_init(command_t *c, dos_t *dos) {
    c->dos = dos;
    c->running = 1;
    c->drive = 'A';
}

int command_exec(command_t *c, char *line) {
    char *p = line;
    while (*p == ' ' || *p == '\t') p++;
    if (!*p) return 0;                          /* blank line */

    /* extract and upper-case the command word */
    char cmd[16]; int i = 0;
    while (*p && *p != ' ' && *p != '\t' && i < (int)sizeof(cmd) - 1)
        cmd[i++] = (char)toupper((unsigned char)*p++);
    cmd[i] = '\0';
    while (*p == ' ' || *p == '\t') p++;        /* args = remainder */

    for (size_t k = 0; k < NUM_COMMANDS; k++)
        if (strcmp(cmd, COMMANDS[k].name) == 0) { COMMANDS[k].fn(c, p); return 0; }

    say(c, "Bad command or file name\r\n");      /* COMMAND.ASM fallthrough */
    return 0;
}

void command_run(command_t *c) {
    char line[130];
    while (c->running) {
        put_ch(c, c->drive);
        if (c->dos->vol) say(c, c->dos->vol->cwd_path);  /* "" at root, "\SUB" below */
        put_ch(c, '>');
        if (read_line(c, line, sizeof(line)) < 0) break;   /* end of input */
        command_exec(c, line);
    }
}
