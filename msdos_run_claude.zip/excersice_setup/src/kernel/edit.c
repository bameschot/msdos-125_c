/* edit.c - see edit.h. A compact full-screen text editor. */
#include "edit.h"

#include <string.h>

/* control-key codes (single bytes, delivered verbatim in raw mode) */
enum {
    K_SAVE = 0x17,  /* Ctrl-W */
    K_EXIT = 0x18,  /* Ctrl-X */
    K_LEFT = 0x02,  /* Ctrl-B */
    K_RIGHT= 0x06,  /* Ctrl-F */
    K_UP   = 0x10,  /* Ctrl-P */
    K_DOWN = 0x0E,  /* Ctrl-N */
    K_HOME = 0x01,  /* Ctrl-A */
    K_END  = 0x05,  /* Ctrl-E */
    K_DELR = 0x04,  /* Ctrl-D */
    K_BS1  = 0x08,
    K_BS2  = 0x7F,
    K_ESC  = 0x1B
};

#define HEADER_ROWS 2

/* ---- console helpers (direct, high-volume rendering) ---- */
static void oc(dos_t *d, char c) { if (d->con && d->con->putch) d->con->putch(d->con->ctx, c); }
static void os(dos_t *d, const char *s) { for (; *s; s++) oc(d, *s); }
static int  gk(dos_t *d) { return (d->con && d->con->getkey) ? d->con->getkey(d->con->ctx) : -1; }
static void onum(dos_t *d, unsigned v) {
    char t[10]; int i = 0;
    if (!v) { oc(d, '0'); return; }
    while (v) { t[i++] = (char)('0' + v % 10); v /= 10; }
    while (i) oc(d, t[--i]);
}
static void go_xy(dos_t *d, unsigned row, unsigned col) {
    os(d, "\x1b["); onum(d, row); oc(d, ';'); onum(d, col); oc(d, 'H');
}

/* ---- line geometry over the flat buffer ---- */
static size_t line_start(const char *b, size_t pos) {
    while (pos > 0 && b[pos - 1] != '\n') pos--;
    return pos;
}
static size_t line_end(const char *b, size_t len, size_t pos) {
    while (pos < len && b[pos] != '\n') pos++;
    return pos;
}

static void redraw(dos_t *d, const char *title, const char *buf, size_t len,
                   size_t cursor, const char *status) {
    os(d, "\x1b[2J\x1b[H");
    os(d, " EDIT  "); os(d, title); os(d, "\r\n");
    os(d, " ^W save  ^X exit  ^B ^F ^P ^N move  ^A ^E line  Bksp del   ");
    os(d, status); os(d, "\r\n");
    for (size_t i = 0; i < len; i++) {
        if (buf[i] == '\n') os(d, "\r\n");
        else oc(d, buf[i]);
    }
    /* place the cursor: row = newlines before it, col = offset in its line */
    unsigned row = 0;
    for (size_t i = 0; i < cursor; i++) if (buf[i] == '\n') row++;
    unsigned col = (unsigned)(cursor - line_start(buf, cursor));
    go_xy(d, HEADER_ROWS + row + 1, col + 1);
}

/* Decode an escape sequence already begun by ESC. Returns one of K_UP/DOWN/
 * LEFT/RIGHT for the arrow keys, -1 for any other (fully drained) sequence so
 * nothing leaks into the text, or -- if the byte after ESC was not actually a
 * sequence introducer -- that raw byte, to be handled as a normal keystroke. */
static int decode_escape(dos_t *d) {
    int b = gk(d);
    if (b == '[' || b == 'O') {           /* CSI or SS3 */
        int f = gk(d);
        while (f >= 0x30 && f <= 0x3F) f = gk(d);   /* skip parameter bytes (e.g. "3" in ESC[3~) */
        switch (f) {
            case 'A': return K_UP;
            case 'B': return K_DOWN;
            case 'C': return K_RIGHT;
            case 'D': return K_LEFT;
            default:  return -1;          /* Delete/PgUp/F-key/etc: ignore, do not insert */
        }
    }
    return b;                             /* lone ESC: process the following key normally */
}

int editor_run(dos_t *dos, const char *title, char *buf, size_t *len, size_t cap,
               int (*save)(void *ctx, const char *buf, size_t len), void *ctx) {
    size_t cursor = 0;
    const char *status = "";

    for (;;) {
        redraw(dos, title, buf, *len, cursor, status);
        int k = gk(dos);
        if (k < 0 || k == K_EXIT) break;

        if (k == K_SAVE) {
            int rc = save ? save(ctx, buf, *len) : -1;
            status = rc == 0 ? "[saved]" : "[save failed]";
            continue;
        }
        if (k == K_ESC) {
            k = decode_escape(dos);
            if (k < 0) continue;          /* unhandled sequence / EOF: ignore */
        }
        status = "";

        switch (k) {
            case K_LEFT:  if (cursor > 0) cursor--; break;
            case K_RIGHT: if (cursor < *len) cursor++; break;
            case K_HOME:  cursor = line_start(buf, cursor); break;
            case K_END:   cursor = line_end(buf, *len, cursor); break;
            case K_UP: {
                size_t ls = line_start(buf, cursor);
                if (ls == 0) { cursor = 0; break; }
                size_t col = cursor - ls;
                size_t ps = line_start(buf, ls - 1);   /* ls-1 is the '\n' */
                size_t pe = ls - 1;
                cursor = (ps + col < pe) ? ps + col : pe;
                break;
            }
            case K_DOWN: {
                size_t le = line_end(buf, *len, cursor);
                if (le == *len) { cursor = *len; break; }
                size_t col = cursor - line_start(buf, cursor);
                size_t ns = le + 1;
                size_t ne = line_end(buf, *len, ns);
                cursor = (ns + col < ne) ? ns + col : ne;
                break;
            }
            case K_BS1:
            case K_BS2:
                if (cursor > 0) {
                    memmove(buf + cursor - 1, buf + cursor, *len - cursor);
                    cursor--; (*len)--;
                }
                break;
            case K_DELR:
                if (cursor < *len) {
                    memmove(buf + cursor, buf + cursor + 1, *len - cursor - 1);
                    (*len)--;
                }
                break;
            case '\r':
            case '\n':
                if (*len + 1 <= cap) {
                    memmove(buf + cursor + 1, buf + cursor, *len - cursor);
                    buf[cursor++] = '\n'; (*len)++;
                }
                break;
            default:
                if (k >= 0x20 && k < 0x7F && *len + 1 <= cap) {
                    memmove(buf + cursor + 1, buf + cursor, *len - cursor);
                    buf[cursor++] = (char)k; (*len)++;
                }
                break;
        }
    }
    os(dos, "\x1b[2J\x1b[H");    /* leave a clean screen */
    return 0;
}
