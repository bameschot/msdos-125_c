/* dir.h - Layer 3: FAT12 root directory (MSDOS.ASM SRCHFRST/SRCHNXT, 32-byte
 * directory entries documented at MSDOS.ASM:99).
 *
 * MS-DOS 1.x has a single, fixed-size root directory (no subdirectories), so
 * these operate on the volume's root-directory region directly.
 */
#ifndef KERNEL_DIR_H
#define KERNEL_DIR_H

#include <stdbool.h>
#include <stdint.h>

#include "volume.h"

#define DIR_ENTRY_SIZE   32
#define DIR_NAME_LEN     11
#define DIR_FREE         0xE5u   /* deleted/free slot (first name byte)       */
#define DIR_END          0x00u   /* never-used slot; ends the search (1.25)   */
#define DIR_ATTR_DIR     0x10u   /* attribute bit: entry is a subdirectory    */

/* 32-byte on-disk directory entry. Packed: the byte layout is contractual. */
#pragma pack(push, 1)
typedef struct {
    uint8_t  name[11];       /* 8.3, space padded; [0]=0xE5 free, 0x00 end */
    uint8_t  attr;           /* bits 1..2 => hidden                        */
    uint8_t  reserved[10];
    uint16_t time;           /* bits0-4 sec/2, 5-10 min, 11-15 hour        */
    uint16_t date;           /* bits0-4 day, 5-8 month, 9-15 year-1980     */
    uint16_t first_cluster;
    uint32_t size;           /* bytes                                       */
} dir_entry_t;
#pragma pack(pop)

/* Name helpers. The 11-byte field is "NAME    EXT" (8 + 3, space padded). */
int  dir_parse_name(const char *s, uint8_t out[11]);     /* exact, no wildcards */
int  dir_parse_pattern(const char *s, uint8_t out[11]);  /* allows '?' and '*'  */
void dir_format_name(const uint8_t name[11], char out[13]);
bool dir_name_match(const uint8_t pattern[11], const uint8_t name[11]);

/* Raw slot access by directory index [0, root_entries). */
int dir_read_entry(volume_t *v, uint16_t index, dir_entry_t *e);
int dir_write_entry(volume_t *v, uint16_t index, const dir_entry_t *e);

/* Find an entry by exact name. On KFS_OK fills *index and *e. */
int dir_find(volume_t *v, const uint8_t name[11], uint16_t *index, dir_entry_t *e);

/* Find the first usable (deleted or never-used) slot. KFS_FULL if none. */
int dir_find_free(volume_t *v, uint16_t *index);

/* Wildcard search from *index: on KFS_OK returns the matching entry in *e and
 * sets *index to the slot AFTER it (so a repeat call continues). KFS_NOTFOUND
 * when the directory ends. Mirrors SEARCH FIRST / SEARCH NEXT. */
int dir_search(volume_t *v, const uint8_t pattern[11], uint16_t *index, dir_entry_t *e);

/* Subdirectories (DOS 2.0 layered onto the volume). All operate relative to
 * the volume's current directory. */
int dir_mkdir(volume_t *v, const char *name);   /* create a subdirectory      */
int dir_rmdir(volume_t *v, const char *name);   /* remove an empty subdir      */
int dir_chdir(volume_t *v, const char *path);   /* change dir: NAME, .., or \  */

#endif /* KERNEL_DIR_H */
