/* dos.h - Layer 5: the INT 21H system-call layer.
 *
 * Implements the MS-DOS dispatch model (MSDOS.ASM:277 ENTRY / :349 DISPATCH):
 * a saved-register block, a dispatch on the function number in AH, character
 * I/O through a pluggable console, and the FCB file calls bridged to Layer 4
 * (kfile). See ASM_TO_C_PORTING_REFERENCE.md sec. 3 (calling conventions).
 *
 * Host adaptation: where the real API passes a far pointer in DS:DX (a string,
 * FCB or buffer), we carry a C pointer in dos_regs.dx_ptr (porting guide 1.2).
 */
#ifndef KERNEL_DOS_H
#define KERNEL_DOS_H

#include <stdint.h>

#include "volume.h"

/* Pluggable console (the CONIN/CONOUT BIOS seam). The wrapper supplies a
 * terminal-backed implementation; tests supply a buffer-backed stub. */
typedef struct {
    int  (*getkey)(void *ctx);          /* blocking read; byte 0-255 or -1 EOF */
    void (*putch)(void *ctx, char c);   /* write one character                 */
    int  (*kbhit)(void *ctx);           /* 1 if a key is ready (may be NULL)    */
    void  *ctx;
} console_t;

/* Saved-register block (the PUSH frame at MSDOS.ASM SAVREGS). */
typedef struct {
    union { uint16_t ax; struct { uint8_t al, ah; }; };
    union { uint16_t bx; struct { uint8_t bl, bh; }; };
    union { uint16_t cx; struct { uint8_t cl, ch; }; };
    union { uint16_t dx; struct { uint8_t dl, dh; }; };
    uint16_t si, di, bp;
    void    *dx_ptr;                    /* stands in for DS:DX far pointer */
} dos_regs;

/* DOS machine state. vol may be NULL (no disk mounted). */
typedef struct {
    volume_t  *vol;
    console_t *con;
    void      *dta;          /* disk transfer area (function 1Ah)       */
    uint8_t    cur_drive;    /* 0 = A:                                  */
    int        terminated;   /* set by function 00h / INT 20h            */
    uint16_t   srch_index;   /* SEARCH FIRST/NEXT cursor                 */
    uint8_t    srch_pat[11];
} dos_t;

void dos_init(dos_t *s, volume_t *vol, console_t *con);

/* Dispatch one system call on AH (MSDOS.ASM ENTRY/DISPATCH). Returns 0 if the
 * function number is handled, -1 if unimplemented (carry/AL=0xFF set). */
int dos_call(dos_t *s, dos_regs *r);

/* ---- In-memory FCB (compact, scope-faithful). The DOS file calls operate on
 * one of these via dos_regs.dx_ptr. ---- */
typedef struct {
    uint8_t  drive;          /* 0 = default                              */
    uint8_t  name[11];       /* 8.3, space padded                        */
    uint16_t cur_block;      /* current extent (128 records each)        */
    uint16_t rec_size;       /* record size (default 128)                */
    uint32_t file_size;
    uint16_t date, time;
    uint16_t first_cluster;  /* internal                                 */
    uint16_t dir_index;      /* internal: backing directory slot         */
    uint8_t  cur_record;     /* NR within the current block              */
} dos_fcb_t;

/* Initialise an FCB from an 8.3 name string. Returns KFS_OK / KFS_ARG. */
int dos_fcb_init(dos_fcb_t *fcb, const char *name);

/* Argument block for RENAME (function 17h): old and new 8.3 names, mirroring
 * the real rename-FCB which packs both names in one block (dx_ptr target). */
typedef struct { uint8_t old[11]; uint8_t newname[11]; } dos_rename_t;

/* DOS function numbers used here (subset of the DISPATCH table). */
enum {
    DOS_TERMINATE      = 0x00,
    DOS_CONIN          = 0x01,
    DOS_CONOUT         = 0x02,
    DOS_RAWIO          = 0x06,
    DOS_PRINT_STRING   = 0x09,
    DOS_BUFFERED_INPUT = 0x0A,
    DOS_CONSTAT        = 0x0B,
    DOS_SELECT_DISK    = 0x0E,
    DOS_OPEN           = 0x0F,
    DOS_CLOSE          = 0x10,
    DOS_SEARCH_FIRST   = 0x11,
    DOS_SEARCH_NEXT    = 0x12,
    DOS_DELETE         = 0x13,
    DOS_SEQ_READ       = 0x14,
    DOS_SEQ_WRITE      = 0x15,
    DOS_CREATE         = 0x16,
    DOS_RENAME         = 0x17,
    DOS_SET_DTA        = 0x1A,
    DOS_MKDIR          = 0x39,
    DOS_RMDIR          = 0x3A,
    DOS_CHDIR          = 0x3B
};

#endif /* KERNEL_DOS_H */
