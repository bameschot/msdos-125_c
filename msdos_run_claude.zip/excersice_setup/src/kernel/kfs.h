/* kfs.h - shared kernel filesystem status codes. */
#ifndef KERNEL_KFS_H
#define KERNEL_KFS_H

enum {
    KFS_OK       =  0,
    KFS_ERR      = -1,   /* generic / underlying disk I/O error */
    KFS_NOTFOUND = -2,   /* name not present                    */
    KFS_EXISTS   = -3,   /* name already present                */
    KFS_FULL     = -4,   /* directory or volume full            */
    KFS_RANGE    = -5,   /* index / position out of range       */
    KFS_ARG      = -6,   /* bad argument                        */
    KFS_EOF      = -7,   /* end of file / no more entries        */
    KFS_NOTEMPTY = -8    /* directory not empty (RMDIR)          */
};

const char *kfs_strerror(int code);

#endif /* KERNEL_KFS_H */
