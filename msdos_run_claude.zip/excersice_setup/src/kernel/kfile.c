/* kfile.c - see kfile.h. Layer 4: file I/O over cluster chains. */
#include "kfile.h"

#include <string.h>

#include "dir.h"
#include "fat.h"
#include "kfs.h"

static uint32_t umin(uint32_t a, uint32_t b) { return a < b ? a : b; }

/* Resolve the cluster holding byte `pos`. If `allocate`, extend the chain as
 * needed (and start one if the file is empty). Mirrors FNDCLUS + ALLOCATE. */
static int cluster_for_pos(kfile_t *f, uint32_t pos, bool allocate, uint16_t *out) {
    volume_t *v = f->vol;
    uint32_t want = pos / v->bytes_per_cluster;   /* chain index of this byte */

    if (f->first_cluster == 0) {
        if (!allocate) return KFS_EOF;
        uint16_t c = fat12_alloc(v->fat, v->max_cluster);
        if (!c) return KFS_FULL;
        f->first_cluster = c;
    }

    uint16_t cl = f->first_cluster;
    for (uint32_t i = 0; i < want; i++) {
        uint16_t next = fat12_get(v->fat, cl);
        if (fat12_is_eof(next)) {
            if (!allocate) return KFS_EOF;
            uint16_t n = fat12_alloc(v->fat, v->max_cluster);
            if (!n) return KFS_FULL;
            fat12_set(v->fat, cl, n);   /* link previous -> new (new is EOF) */
            next = n;
        }
        cl = next;
    }
    *out = cl;
    return KFS_OK;
}

int kfile_create(volume_t *v, const char *name, kfile_t *f) {
    uint8_t n[11];
    if (!v || !f || dir_parse_name(name, n) != KFS_OK)
        return KFS_ARG;

    uint16_t idx;
    dir_entry_t e;
    if (dir_find(v, n, &idx, &e) == KFS_OK) {
        if (e.first_cluster)            /* truncate an existing file */
            fat12_free_chain(v->fat, e.first_cluster);
    } else {
        int rc = dir_find_free(v, &idx);
        if (rc != KFS_OK) return rc;    /* KFS_FULL */
    }

    memset(&e, 0, sizeof(e));
    memcpy(e.name, n, 11);
    e.date = DIR_DATE_1980;
    int rc = dir_write_entry(v, idx, &e);
    if (rc != KFS_OK) return rc;

    memset(f, 0, sizeof(*f));
    f->vol = v;
    memcpy(f->name, n, 11);
    f->dir_index = idx;
    return KFS_OK;
}

int kfile_open(volume_t *v, const char *name, kfile_t *f) {
    uint8_t n[11];
    if (!v || !f || dir_parse_name(name, n) != KFS_OK)
        return KFS_ARG;

    uint16_t idx;
    dir_entry_t e;
    int rc = dir_find(v, n, &idx, &e);
    if (rc != KFS_OK) return rc;

    memset(f, 0, sizeof(*f));
    f->vol = v;
    memcpy(f->name, n, 11);
    f->dir_index = idx;
    f->first_cluster = e.first_cluster;
    f->size = e.size;
    return KFS_OK;
}

int kfile_read(kfile_t *f, void *buf, uint32_t len, uint32_t *got) {
    if (!f || !f->vol) return KFS_ARG;
    volume_t *v = f->vol;
    uint8_t cbuf[KFILE_MAX_CLUSTER_BYTES];
    uint8_t *out = buf;
    uint32_t done = 0;

    while (done < len && f->pos < f->size) {
        uint16_t cl;
        int rc = cluster_for_pos(f, f->pos, false, &cl);
        if (rc == KFS_EOF) break;
        if (rc != KFS_OK) return rc;
        if (volume_read_cluster(v, cl, cbuf) != DISK_OK) return KFS_ERR;

        uint32_t coff  = f->pos % v->bytes_per_cluster;
        uint32_t chunk = umin(umin(v->bytes_per_cluster - coff, len - done),
                              f->size - f->pos);
        memcpy(out + done, cbuf + coff, chunk);
        done += chunk;
        f->pos += chunk;
    }
    if (got) *got = done;
    return KFS_OK;
}

int kfile_write(kfile_t *f, const void *buf, uint32_t len) {
    if (!f || !f->vol) return KFS_ARG;
    volume_t *v = f->vol;
    uint8_t cbuf[KFILE_MAX_CLUSTER_BYTES];
    const uint8_t *in = buf;
    uint32_t done = 0;

    while (done < len) {
        uint16_t cl;
        int rc = cluster_for_pos(f, f->pos, true, &cl);
        if (rc != KFS_OK) return rc;    /* KFS_FULL when volume exhausted */

        uint32_t coff  = f->pos % v->bytes_per_cluster;
        uint32_t chunk = umin(v->bytes_per_cluster - coff, len - done);

        /* read-modify-write so partial clusters keep their other bytes */
        if (volume_read_cluster(v, cl, cbuf) != DISK_OK) return KFS_ERR;
        memcpy(cbuf + coff, in + done, chunk);
        if (volume_write_cluster(v, cl, cbuf) != DISK_OK) return KFS_ERR;

        done += chunk;
        f->pos += chunk;
        if (f->pos > f->size)
            f->size = f->pos;
    }
    return KFS_OK;
}

int kfile_seek(kfile_t *f, uint32_t pos) {
    if (!f || !f->vol) return KFS_ARG;
    f->pos = pos;
    return KFS_OK;
}

int kfile_close(kfile_t *f) {
    if (!f || !f->vol) return KFS_ARG;
    dir_entry_t e;
    int rc = dir_read_entry(f->vol, f->dir_index, &e);
    if (rc != KFS_OK) return rc;
    e.first_cluster = f->first_cluster;
    e.size = f->size;
    rc = dir_write_entry(f->vol, f->dir_index, &e);
    if (rc != KFS_OK) return rc;
    rc = volume_flush(f->vol);
    f->vol = NULL;
    return rc;
}

int kfile_delete(volume_t *v, const char *name) {
    uint8_t n[11];
    if (!v || dir_parse_name(name, n) != KFS_OK)
        return KFS_ARG;

    uint16_t idx;
    dir_entry_t e;
    int rc = dir_find(v, n, &idx, &e);
    if (rc != KFS_OK) return rc;

    if (e.first_cluster)
        fat12_free_chain(v->fat, e.first_cluster);
    e.name[0] = DIR_FREE;
    rc = dir_write_entry(v, idx, &e);
    if (rc != KFS_OK) return rc;
    return volume_flush(v);
}

int kfile_rename(volume_t *v, const uint8_t old[11], const uint8_t newname[11]) {
    if (!v) return KFS_ARG;
    uint16_t idx; dir_entry_t e;
    if (dir_find(v, old, &idx, &e) != KFS_OK)
        return KFS_NOTFOUND;
    uint16_t j; dir_entry_t tmp;
    if (dir_find(v, newname, &j, &tmp) == KFS_OK)
        return KFS_EXISTS;                  /* target name already in use */
    memcpy(e.name, newname, 11);
    int rc = dir_write_entry(v, idx, &e);
    if (rc != KFS_OK) return rc;
    return volume_flush(v);
}
