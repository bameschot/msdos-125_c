/* basic.c - see basic.h. A rudimentary line-numbered BASIC interpreter. */
#include "basic.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINES 512
#define MAX_NUM   64
#define MAX_STR   32
#define MAX_LOOP  16
#define SLEN      255

typedef struct { int is_str; double num; char str[SLEN + 1]; } value_t;
typedef struct { int number; char *text; } bline_t;
typedef struct { char name[16]; double num; } numvar_t;
typedef struct { char name[16]; char val[SLEN + 1]; } strvar_t;
typedef struct { char var[16]; double limit, step; int body_pc; } loop_t;

typedef struct {
    dos_t   *dos;
    bline_t  lines[MAX_LINES]; int nlines;
    numvar_t nums[MAX_NUM];    int nnum;
    strvar_t strs[MAX_STR];    int nstr;
    loop_t   loops[MAX_LOOP];  int nloop;
    int      stopped;
    int      err; char errmsg[48]; int curline;
} interp;

/* ---- console ---- */
static void och(interp *I, char c) { if (I->dos->con && I->dos->con->putch) I->dos->con->putch(I->dos->con->ctx, c); }
static void os(interp *I, const char *s) { for (; *s; s++) och(I, *s); }
static void onl(interp *I) { os(I, "\r\n"); }
static int  gk(interp *I) { return (I->dos->con && I->dos->con->getkey) ? I->dos->con->getkey(I->dos->con->ctx) : -1; }
static void seterr(interp *I, const char *m) {
    if (!I->err) { I->err = 1; strncpy(I->errmsg, m, sizeof I->errmsg - 1); I->errmsg[sizeof I->errmsg - 1] = 0; }
}

/* ---- values ---- */
static value_t vnum(double n) { value_t v; v.is_str = 0; v.num = n; v.str[0] = 0; return v; }
static value_t vstr(const char *s) { value_t v; v.is_str = 1; v.num = 0; strncpy(v.str, s, SLEN); v.str[SLEN] = 0; return v; }
static double  asnum(interp *I, value_t v) { if (v.is_str) { seterr(I, "TYPE MISMATCH"); return 0; } return v.num; }

/* ---- variables ---- */
static double get_num(interp *I, const char *n) {
    for (int i = 0; i < I->nnum; i++) if (!strcmp(I->nums[i].name, n)) return I->nums[i].num;
    return 0;
}
static void set_num(interp *I, const char *n, double v) {
    for (int i = 0; i < I->nnum; i++) if (!strcmp(I->nums[i].name, n)) { I->nums[i].num = v; return; }
    if (I->nnum < MAX_NUM) { strncpy(I->nums[I->nnum].name, n, 15); I->nums[I->nnum].name[15] = 0; I->nums[I->nnum].num = v; I->nnum++; }
    else seterr(I, "TOO MANY VARIABLES");
}
static const char *get_str(interp *I, const char *n) {
    for (int i = 0; i < I->nstr; i++) if (!strcmp(I->strs[i].name, n)) return I->strs[i].val;
    return "";
}
static void set_str(interp *I, const char *n, const char *v) {
    for (int i = 0; i < I->nstr; i++) if (!strcmp(I->strs[i].name, n)) { strncpy(I->strs[i].val, v, SLEN); I->strs[i].val[SLEN] = 0; return; }
    if (I->nstr < MAX_STR) { strncpy(I->strs[I->nstr].name, n, 15); I->strs[I->nstr].name[15] = 0; strncpy(I->strs[I->nstr].val, v, SLEN); I->strs[I->nstr].val[SLEN] = 0; I->nstr++; }
    else seterr(I, "TOO MANY STRINGS");
}

/* ---- lexing ---- */
static void skipws(const char **p) { while (**p == ' ' || **p == '\t') (*p)++; }
static int read_word(const char **p, char *out, int cap) {   /* keyword: A-Z + A-Z0-9 */
    skipws(p); int n = 0;
    if (!isalpha((unsigned char)**p)) { out[0] = 0; return 0; }
    while (isalnum((unsigned char)**p) && n < cap - 1) { out[n++] = (char)toupper((unsigned char)**p); (*p)++; }
    out[n] = 0; return n;
}
static int read_var(const char **p, char *out, int cap) {    /* NAME or NAME$ */
    skipws(p); int n = 0;
    if (!isalpha((unsigned char)**p)) { out[0] = 0; return 0; }
    while (isalnum((unsigned char)**p) && n < cap - 2) { out[n++] = (char)toupper((unsigned char)**p); (*p)++; }
    if (**p == '$' && n < cap - 1) { out[n++] = '$'; (*p)++; }
    out[n] = 0; return n;
}
static int is_strname(const char *n) { size_t l = strlen(n); return l && n[l - 1] == '$'; }

/* ---- expression parser (recursive descent) ---- */
static value_t p_expr(interp *I, const char **p);

static value_t p_primary(interp *I, const char **p) {
    skipws(p);
    char c = **p;
    if (c == '(') { (*p)++; value_t v = p_expr(I, p); skipws(p); if (**p == ')') (*p)++; else seterr(I, "MISSING )"); return v; }
    if (c == '"') {
        (*p)++; char b[SLEN + 1]; int n = 0;
        while (**p && **p != '"') { if (n < SLEN) b[n++] = **p; (*p)++; }
        if (**p == '"') (*p)++; else seterr(I, "MISSING QUOTE");
        b[n] = 0; return vstr(b);
    }
    if (isdigit((unsigned char)c) || c == '.') { char *e; double d = strtod(*p, &e); *p = e; return vnum(d); }
    if (isalpha((unsigned char)c)) {
        char name[16]; read_var(p, name, sizeof name);
        return is_strname(name) ? vstr(get_str(I, name)) : vnum(get_num(I, name));
    }
    seterr(I, "SYNTAX ERROR"); return vnum(0);
}
static value_t p_unary(interp *I, const char **p) {
    skipws(p);
    if (**p == '-') { (*p)++; return vnum(-asnum(I, p_unary(I, p))); }
    if (**p == '+') { (*p)++; return p_unary(I, p); }
    return p_primary(I, p);
}
static value_t p_mul(interp *I, const char **p) {
    value_t v = p_unary(I, p);
    for (;;) {
        skipws(p); char c = **p;
        if (c == '*') { (*p)++; v = vnum(asnum(I, v) * asnum(I, p_unary(I, p))); }
        else if (c == '/') { (*p)++; double d = asnum(I, p_unary(I, p)); if (d == 0) { seterr(I, "DIVISION BY ZERO"); return vnum(0); } v = vnum(asnum(I, v) / d); }
        else break;
    }
    return v;
}
static value_t p_add(interp *I, const char **p) {
    value_t v = p_mul(I, p);
    for (;;) {
        skipws(p); char c = **p;
        if (c == '+') {
            (*p)++; value_t r = p_mul(I, p);
            if (v.is_str && r.is_str) { char b[SLEN + 1]; strncpy(b, v.str, SLEN); b[SLEN] = 0; strncat(b, r.str, SLEN - strlen(b)); v = vstr(b); }
            else if (!v.is_str && !r.is_str) v = vnum(v.num + r.num);
            else { seterr(I, "TYPE MISMATCH"); return vnum(0); }
        } else if (c == '-') { (*p)++; v = vnum(asnum(I, v) - asnum(I, p_mul(I, p))); }
        else break;
    }
    return v;
}
static value_t p_expr(interp *I, const char **p) {
    value_t v = p_add(I, p);
    skipws(p);
    const char *q = *p; int op = 0;
    if (q[0] == '<' && q[1] == '>') { op = 1; *p += 2; }
    else if (q[0] == '<' && q[1] == '=') { op = 4; *p += 2; }
    else if (q[0] == '>' && q[1] == '=') { op = 5; *p += 2; }
    else if (q[0] == '=') { op = 2; (*p)++; }
    else if (q[0] == '<') { op = 3; (*p)++; }
    else if (q[0] == '>') { op = 6; (*p)++; }
    if (!op) return v;
    value_t r = p_add(I, p);
    int res = 0;
    if (v.is_str && r.is_str) {
        int cmp = strcmp(v.str, r.str);
        switch (op) { case 1: res = cmp != 0; break; case 2: res = cmp == 0; break; case 3: res = cmp < 0; break;
                      case 4: res = cmp <= 0; break; case 5: res = cmp >= 0; break; case 6: res = cmp > 0; break; }
    } else {
        double a = asnum(I, v), b = asnum(I, r);
        switch (op) { case 1: res = a != b; break; case 2: res = a == b; break; case 3: res = a < b; break;
                      case 4: res = a <= b; break; case 5: res = a >= b; break; case 6: res = a > b; break; }
    }
    return vnum(res ? -1.0 : 0.0);
}

/* ---- output / lookup helpers ---- */
static void print_number(interp *I, double v) {
    char b[40];
    long long iv = (long long)v;
    if ((double)iv == v) snprintf(b, sizeof b, "%lld", iv);
    else snprintf(b, sizeof b, "%g", v);
    if (v >= 0) och(I, ' ');     /* BASIC leads non-negative numbers with a space */
    os(I, b);
}
static int find_line(interp *I, int number) {
    int lo = 0, hi = I->nlines - 1;
    while (lo <= hi) { int m = (lo + hi) / 2; if (I->lines[m].number == number) return m;
                       if (I->lines[m].number < number) lo = m + 1; else hi = m - 1; }
    return -1;
}
static int truthy(value_t v) { return v.is_str ? v.str[0] != 0 : v.num != 0; }

/* ---- statements ---- */
static void exec_stmt(interp *I, const char *s, int pc, int *next);

static void do_print(interp *I, const char **s) {
    skipws(s);
    if (**s == 0) { onl(I); return; }
    int trailing = 0;
    for (;;) {
        value_t v = p_expr(I, s); if (I->err) return;
        if (v.is_str) os(I, v.str); else print_number(I, v.num);
        skipws(s);
        if (**s == ';') { (*s)++; trailing = 1; skipws(s); if (**s == 0) break; trailing = 0; }
        else if (**s == ',') { (*s)++; och(I, '\t'); trailing = 1; skipws(s); if (**s == 0) break; trailing = 0; }
        else break;
    }
    if (!trailing) onl(I);
}
static void do_assign(interp *I, const char **s) {
    char name[16];
    if (!read_var(s, name, sizeof name)) { seterr(I, "SYNTAX ERROR"); return; }
    skipws(s); if (**s != '=') { seterr(I, "SYNTAX ERROR"); return; } (*s)++;
    value_t v = p_expr(I, s); if (I->err) return;
    if (is_strname(name)) { if (!v.is_str) { seterr(I, "TYPE MISMATCH"); return; } set_str(I, name, v.str); }
    else { if (v.is_str) { seterr(I, "TYPE MISMATCH"); return; } set_num(I, name, v.num); }
}
static void do_goto(interp *I, const char **s, int *next) {
    skipws(s); int n = (int)strtol(*s, NULL, 10);
    int idx = find_line(I, n); if (idx < 0) { seterr(I, "UNDEF'D LINE"); return; }
    *next = idx;
}
static void do_if(interp *I, const char **s, int pc, int *next) {
    value_t cond = p_expr(I, s); if (I->err) return;
    char w[8];
    if (!read_word(s, w, sizeof w) || strcmp(w, "THEN")) { seterr(I, "EXPECTED THEN"); return; }
    skipws(s);
    if (!truthy(cond)) { *next = pc + 1; return; }
    if (isdigit((unsigned char)**s)) { do_goto(I, s, next); }   /* THEN <line> */
    else exec_stmt(I, *s, pc, next);                            /* THEN <statement> */
}
static void do_for(interp *I, const char **s, int pc, int *next) {
    char var[16];
    if (!read_var(s, var, sizeof var) || is_strname(var)) { seterr(I, "SYNTAX ERROR"); return; }
    skipws(s); if (**s != '=') { seterr(I, "SYNTAX ERROR"); return; } (*s)++;
    double start = asnum(I, p_expr(I, s)); if (I->err) return;
    char w[8];
    if (!read_word(s, w, sizeof w) || strcmp(w, "TO")) { seterr(I, "EXPECTED TO"); return; }
    double limit = asnum(I, p_expr(I, s)); if (I->err) return;
    double step = 1; const char *save = *s;
    if (read_word(s, w, sizeof w) && !strcmp(w, "STEP")) { step = asnum(I, p_expr(I, s)); if (I->err) return; }
    else *s = save;
    set_num(I, var, start);
    if (I->nloop >= MAX_LOOP) { seterr(I, "TOO MANY FORS"); return; }
    loop_t *L = &I->loops[I->nloop++];
    strncpy(L->var, var, 15); L->var[15] = 0; L->limit = limit; L->step = step; L->body_pc = pc + 1;
    *next = pc + 1;
}
static void do_next(interp *I, const char **s, int pc, int *next) {
    char var[16]; read_var(s, var, sizeof var);     /* variable is optional */
    if (I->nloop <= 0) { seterr(I, "NEXT WITHOUT FOR"); return; }
    loop_t *L = &I->loops[I->nloop - 1];
    double v = get_num(I, L->var) + L->step;
    set_num(I, L->var, v);
    int cont = (L->step >= 0) ? (v <= L->limit) : (v >= L->limit);
    if (cont) *next = L->body_pc;
    else { I->nloop--; *next = pc + 1; }
}
static void read_console_line(interp *I, char *buf, int cap) {
    int n = 0;
    for (;;) {
        int k = gk(I);
        if (k < 0 || k == '\r' || k == '\n') { onl(I); break; }
        if (k == 0x08 || k == 0x7F) { if (n) { n--; os(I, "\b \b"); } continue; }
        if (k >= 0x20 && n < cap - 1) { buf[n++] = (char)k; och(I, (char)k); }
    }
    buf[n] = 0;
}
static void do_input(interp *I, const char **s) {
    skipws(s);
    if (**s == '"') { value_t pr = p_primary(I, s); if (I->err) return; os(I, pr.str);
                      skipws(s); if (**s == ';' || **s == ',') (*s)++; }
    os(I, "? ");
    char var[16]; if (!read_var(s, var, sizeof var)) { seterr(I, "SYNTAX ERROR"); return; }
    char in[SLEN + 1]; read_console_line(I, in, sizeof in);
    if (is_strname(var)) set_str(I, var, in);
    else set_num(I, var, strtod(in, NULL));
}

static void exec_stmt(interp *I, const char *s, int pc, int *next) {
    skipws(&s);
    if (*s == 0) return;
    if (*s == '?') { s++; do_print(I, &s); return; }    /* ? is shorthand for PRINT */
    const char *save = s;
    char kw[16];
    if (read_word(&s, kw, sizeof kw) == 0) { seterr(I, "SYNTAX ERROR"); return; }
    if (!strcmp(kw, "REM")) return;
    if (!strcmp(kw, "END") || !strcmp(kw, "STOP")) { I->stopped = 1; return; }
    if (!strcmp(kw, "PRINT")) { do_print(I, &s); return; }
    if (!strcmp(kw, "LET"))   { do_assign(I, &s); return; }
    if (!strcmp(kw, "GOTO"))  { do_goto(I, &s, next); return; }
    if (!strcmp(kw, "IF"))    { do_if(I, &s, pc, next); return; }
    if (!strcmp(kw, "FOR"))   { do_for(I, &s, pc, next); return; }
    if (!strcmp(kw, "NEXT"))  { do_next(I, &s, pc, next); return; }
    if (!strcmp(kw, "INPUT")) { do_input(I, &s); return; }
    s = save; do_assign(I, &s);                          /* otherwise: assignment */
}

int basic_run(dos_t *dos, char *program, size_t len) {
    static interp I;
    memset(&I, 0, sizeof I);
    I.dos = dos;

    /* tokenise into numbered lines */
    size_t i = 0;
    while (i < len && I.nlines < MAX_LINES) {
        while (i < len && (program[i] == '\r' || program[i] == '\n')) i++;
        if (i >= len) break;
        size_t st = i;
        while (i < len && program[i] != '\n') i++;
        size_t en = i;
        if (i < len) { program[i] = '\0'; i++; }
        char *line = &program[st];
        size_t l = en - st;
        while (l > 0 && (line[l - 1] == '\r' || line[l - 1] == ' ' || line[l - 1] == '\t')) line[--l] = '\0';
        char *p = line; while (*p == ' ' || *p == '\t') p++;
        if (*p == 0) continue;                       /* blank line */
        if (!isdigit((unsigned char)*p)) { seterr(&I, "MISSING LINE NUMBER"); break; }
        int num = (int)strtol(p, &p, 10);
        while (*p == ' ' || *p == '\t') p++;
        I.lines[I.nlines].number = num;
        I.lines[I.nlines].text = p;
        I.nlines++;
    }
    /* sort by line number (insertion sort; programs are small) */
    for (int a = 1; a < I.nlines; a++) {
        bline_t t = I.lines[a]; int b = a - 1;
        while (b >= 0 && I.lines[b].number > t.number) { I.lines[b + 1] = I.lines[b]; b--; }
        I.lines[b + 1] = t;
    }

    /* execute */
    int pc = 0;
    while (pc >= 0 && pc < I.nlines && !I.stopped && !I.err) {
        I.curline = I.lines[pc].number;
        int next = pc + 1;
        exec_stmt(&I, I.lines[pc].text, pc, &next);
        pc = next;
    }

    if (I.err) {
        char nb[16]; snprintf(nb, sizeof nb, "%d", I.curline);
        os(&I, "?"); os(&I, I.errmsg); os(&I, " IN "); os(&I, nb); onl(&I);
        return -1;
    }
    return 0;
}
