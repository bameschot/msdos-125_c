/* fat.h - Layer 1: FAT12 arithmetic (MSDOS.ASM UNPACK/PACK/ALLOCATE).
 *
 * Pure, dependency-free operations on a 12-bit File Allocation Table stored as
 * a flat byte buffer (two entries packed per three bytes). See
 * ASM_TO_C_PORTING_REFERENCE.md sec. 4.4 and MSDOS.ASM:99,448,484.
 */
#ifndef KERNEL_FAT_H
#define KERNEL_FAT_H

#include <stdbool.h>
#include <stdint.h>

/* 12-bit FAT entry values. MSDOS.ASM: entries > 0FF8H are end-of-file marks,
 * 0 is free; cluster 0/1 are reserved and data begins at cluster 2. */
#define FAT12_FREE        0x000u
#define FAT12_BAD         0xFF7u
#define FAT12_EOF         0xFFFu   /* canonical end-of-chain mark we write   */
#define FAT12_EOF_MIN     0xFF8u   /* any value >= this terminates a chain   */
#define FAT12_MIN_CLUSTER 2u       /* first allocatable data cluster         */

/* Read / write the 12-bit entry for `cluster` in the packed FAT buffer. */
uint16_t fat12_get(const uint8_t *fat, uint16_t cluster);
void     fat12_set(uint8_t *fat, uint16_t cluster, uint16_t value);

static inline bool fat12_is_eof(uint16_t v)  { return v >= FAT12_EOF_MIN; }
static inline bool fat12_is_free(uint16_t v) { return v == FAT12_FREE; }

/* Chain operations over an in-memory FAT. `max_cluster` is the highest valid
 * cluster number (cluster_count + 1). All pure-memory; no disk I/O. */
uint16_t fat12_next(const uint8_t *fat, uint16_t cluster);
uint16_t fat12_chain_length(const uint8_t *fat, uint16_t start);
uint16_t fat12_count_free(const uint8_t *fat, uint16_t max_cluster);

/* Allocate one free cluster, mark it end-of-chain, return its number (or 0 if
 * the volume is full). Mirrors MSDOS.ASM ALLOCATE. */
uint16_t fat12_alloc(uint8_t *fat, uint16_t max_cluster);

/* Free an entire cluster chain starting at `start`. Mirrors RELEASE. */
void     fat12_free_chain(uint8_t *fat, uint16_t start);

#endif /* KERNEL_FAT_H */
