/* kfile.h - Layer 4: file I/O over FAT12 cluster chains.
 *
 * A compact byte-stream file handle that implements the substance of the
 * MS-DOS FCB file calls (OPEN/CREATE/CLOSE/DELETE and sequential/positioned
 * read & write) by combining the directory (Layer 3), the in-memory FAT and
 * cluster I/O (Layer 2) and FAT arithmetic (Layer 1). The DOS dispatch layer
 * maps the record-oriented FCB system calls onto these.
 */
#ifndef KERNEL_KFILE_H
#define KERNEL_KFILE_H

#include <stdbool.h>
#include <stdint.h>

#include "volume.h"

#define KFILE_MAX_CLUSTER_BYTES 4096   /* >= any supported bytes_per_cluster */
#define DIR_DATE_1980  0x0021u         /* 1980-01-01 packed (year0,mon1,day1) */

typedef struct {
    volume_t *vol;
    uint16_t  dir_index;       /* directory slot backing this file */
    uint8_t   name[11];
    uint16_t  first_cluster;   /* 0 = empty file (no chain yet)    */
    uint32_t  size;            /* file size in bytes               */
    uint32_t  pos;             /* current byte position            */
} kfile_t;

/* Create a new file (or truncate an existing one) and leave it open at pos 0.
 * Claims a directory slot immediately. KFS_FULL if the directory is full. */
int kfile_create(volume_t *v, const char *name, kfile_t *f);

/* Open an existing file at pos 0. KFS_NOTFOUND if absent. */
int kfile_open(volume_t *v, const char *name, kfile_t *f);

/* Read up to len bytes at the current position; *got receives the count read
 * (short at end of file). Advances pos. */
int kfile_read(kfile_t *f, void *buf, uint32_t len, uint32_t *got);

/* Write len bytes at the current position, extending the file (and allocating
 * clusters) as needed. KFS_FULL if the volume runs out of clusters. */
int kfile_write(kfile_t *f, const void *buf, uint32_t len);

/* Set the current byte position (may exceed size; reads clamp to size). */
int kfile_seek(kfile_t *f, uint32_t pos);

/* Flush metadata (size, first cluster) to the directory entry and the FAT to
 * disk, then detach the handle. */
int kfile_close(kfile_t *f);

/* Delete a file: free its cluster chain and mark the directory slot deleted. */
int kfile_delete(volume_t *v, const char *name);

/* Rename a file in place. Names are 11-byte 8.3 directory fields. Returns
 * KFS_NOTFOUND if `old` is absent, KFS_EXISTS if `newname` already exists. */
int kfile_rename(volume_t *v, const uint8_t old[11], const uint8_t newname[11]);

#endif /* KERNEL_KFILE_H */
