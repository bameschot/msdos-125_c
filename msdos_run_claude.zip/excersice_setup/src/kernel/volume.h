/* volume.h - Layer 2: the mounted volume (MSDOS.ASM Drive Parameter Block).
 *
 * Binds a wrapper disk image (disk_t) to FAT12 geometry derived from the media
 * descriptor in FAT[0], loads the FAT into memory (as the kernel keeps a FAT
 * pointer per drive), and offers cluster / root-directory sector I/O. Mirrors
 * DPBLOCK (MSDOS.ASM:128) and FIGFAT/DSKREAD usage.
 */
#ifndef KERNEL_VOLUME_H
#define KERNEL_VOLUME_H

#include <stdbool.h>
#include <stdint.h>

#include "../disk.h"

/* A directory location: the fixed root region, or a subdirectory's cluster
 * chain (DOS 2.0-style subdirectories layered onto the 1.x volume). */
typedef struct { int is_root; uint16_t cluster; } dir_loc;

typedef struct {
    disk_t  *disk;
    uint8_t  media;                 /* descriptor from FAT[0]            */
    uint16_t bytes_per_sector;
    uint8_t  sectors_per_cluster;
    uint16_t reserved_sectors;      /* boot sector(s); 1                 */
    uint8_t  num_fats;              /* 2                                 */
    uint16_t sectors_per_fat;
    uint16_t root_entries;
    uint16_t root_dir_sectors;      /* derived                           */
    uint16_t first_root_sector;     /* reserved + num_fats*spf           */
    uint16_t first_data_sector;     /* first_root_sector + root_dir_secs */
    uint16_t total_sectors;
    uint16_t cluster_count;         /* number of data clusters           */
    uint16_t max_cluster;           /* highest valid cluster (count + 1) */
    uint32_t bytes_per_cluster;     /* spc * bps                         */
    uint8_t *fat;                   /* in-memory FAT (sectors_per_fat*bps) */
    dir_loc  cwd;                   /* current directory (default: root)  */
    char     cwd_path[64];          /* display path, "" at root           */
} volume_t;

/* Mount: read the media byte from FAT[0], derive layout, load the FAT into
 * memory. Returns DISK_OK or a DISK_ERR_* code (DISK_ERR_ARG if unformatted /
 * unknown media or geometry mismatch). */
int volume_mount(volume_t *v, disk_t *disk);

/* Write the in-memory FAT back to every FAT copy and flush the disk image. */
int volume_flush(volume_t *v);

/* Free the in-memory FAT. Does not flush. */
void volume_unmount(volume_t *v);

/* Sector address of a data cluster (cluster >= 2). */
uint32_t volume_cluster_sector(const volume_t *v, uint16_t cluster);

/* Cluster data I/O (buf must hold bytes_per_cluster). */
int volume_read_cluster(volume_t *v, uint16_t cluster, void *buf);
int volume_write_cluster(volume_t *v, uint16_t cluster, const void *buf);

/* Root-directory sector I/O, idx in [0, root_dir_sectors). */
int volume_read_root_sector(volume_t *v, uint16_t idx, void *buf);
int volume_write_root_sector(volume_t *v, uint16_t idx, const void *buf);

#endif /* KERNEL_VOLUME_H */
