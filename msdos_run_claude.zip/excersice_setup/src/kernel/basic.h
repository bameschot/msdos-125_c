/* basic.h - a rudimentary BASIC interpreter (the BASIC command).
 *
 * Runs a line-numbered, ASCII BASIC program through the kernel console. A
 * deliberately small subset in the spirit of the BASIC.COM that shipped with
 * MS-DOS 1.25:
 *   PRINT  LET/assignment  IF..THEN  GOTO  FOR..TO..STEP/NEXT  INPUT  REM
 *   END/STOP, numeric and string (NAME$) variables, and expressions with
 *   + - * / parentheses, comparisons (= <> < <= > >=) and string concatenation.
 */
#ifndef KERNEL_BASIC_H
#define KERNEL_BASIC_H

#include <stddef.h>

#include "dos.h"

/* Run the program in `program` (len bytes; the buffer is tokenised in place,
 * so it must be writable and NUL-terminated at program[len]). Console I/O goes
 * through `dos`. Returns 0, or -1 if a parse/runtime error was reported. */
int basic_run(dos_t *dos, char *program, size_t len);

#endif /* KERNEL_BASIC_H */
