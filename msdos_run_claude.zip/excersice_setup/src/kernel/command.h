/* command.h - C port of the MS-DOS command processor (COMMAND.ASM).
 *
 * The transient command interpreter: show a prompt, read a command line, parse
 * the command word, and dispatch to the matching internal-command handler.
 * Unknown commands fall through to "Bad command or file name" (COMMAND.ASM has
 * no external-program loader in this port — MS-DOS 1.x program loading is not
 * part of the kernel scope). All I/O and file work is done through dos_call()
 * (INT 21H) into the ported kernel, so this sits on top of Layer 5.
 *
 * Internal commands: DIR TYPE DEL/ERASE REN/RENAME COPY ECHO REM CLS VER
 * DATE TIME EXIT.
 */
#ifndef KERNEL_COMMAND_H
#define KERNEL_COMMAND_H

#include "dos.h"

typedef struct {
    dos_t *dos;
    int    running;       /* cleared by EXIT or end-of-input */
    char   drive;         /* prompt drive letter, e.g. 'A'   */
} command_t;

/* Bind the processor to a DOS machine (with a mounted volume + console). */
void command_init(command_t *c, dos_t *dos);

/* Prompt / read-line / dispatch loop. Returns when EXIT is run or input ends. */
void command_run(command_t *c);

/* Execute a single command line (mutates the buffer while tokenising).
 * Exposed for testing. Returns 0. */
int command_exec(command_t *c, char *line);

#endif /* KERNEL_COMMAND_H */
