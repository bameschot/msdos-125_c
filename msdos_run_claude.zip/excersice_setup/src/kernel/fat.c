/* fat.c - see fat.h. Layer 1: FAT12 arithmetic. */
#include "fat.h"

/* UNPACK (MSDOS.ASM:448): addr = FAT + cluster*1.5; fetch word; if cluster odd
 * shift right 4; mask to 12 bits. */
uint16_t fat12_get(const uint8_t *fat, uint16_t cluster) {
    uint32_t i = (uint32_t)cluster + (cluster >> 1);     /* cluster * 1.5 */
    uint16_t w = (uint16_t)(fat[i] | (fat[i + 1] << 8));
    return (cluster & 1u) ? (uint16_t)(w >> 4) : (uint16_t)(w & 0x0FFFu);
}

/* PACK (MSDOS.ASM:484): merge a 12-bit value into the right nibble lane. */
void fat12_set(uint8_t *fat, uint16_t cluster, uint16_t value) {
    uint32_t i = (uint32_t)cluster + (cluster >> 1);
    uint16_t w = (uint16_t)(fat[i] | (fat[i + 1] << 8));
    value &= 0x0FFFu;
    if (cluster & 1u)
        w = (uint16_t)((w & 0x000Fu) | (value << 4));    /* odd: high 12 bits */
    else
        w = (uint16_t)((w & 0xF000u) | value);           /* even: low 12 bits */
    fat[i]     = (uint8_t)w;
    fat[i + 1] = (uint8_t)(w >> 8);
}

uint16_t fat12_next(const uint8_t *fat, uint16_t cluster) {
    return fat12_get(fat, cluster);
}

uint16_t fat12_chain_length(const uint8_t *fat, uint16_t start) {
    uint16_t n = 0, c = start;
    while (c >= FAT12_MIN_CLUSTER && !fat12_is_eof(c)) {
        n++;
        c = fat12_get(fat, c);
    }
    return n;
}

uint16_t fat12_count_free(const uint8_t *fat, uint16_t max_cluster) {
    uint16_t n = 0;
    for (uint16_t c = FAT12_MIN_CLUSTER; c <= max_cluster; c++)
        if (fat12_is_free(fat12_get(fat, c)))
            n++;
    return n;
}

uint16_t fat12_alloc(uint8_t *fat, uint16_t max_cluster) {
    for (uint16_t c = FAT12_MIN_CLUSTER; c <= max_cluster; c++) {
        if (fat12_is_free(fat12_get(fat, c))) {
            fat12_set(fat, c, FAT12_EOF);
            return c;
        }
    }
    return 0;   /* volume full */
}

void fat12_free_chain(uint8_t *fat, uint16_t start) {
    uint16_t c = start;
    while (c >= FAT12_MIN_CLUSTER && !fat12_is_eof(c)) {
        uint16_t next = fat12_get(fat, c);
        fat12_set(fat, c, FAT12_FREE);
        c = next;
    }
}
