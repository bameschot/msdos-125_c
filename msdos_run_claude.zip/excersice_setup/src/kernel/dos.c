/* dos.c - see dos.h. Layer 5: INT 21H dispatch + char I/O + FCB file calls. */
#include "dos.h"

#include <string.h>

#include "dir.h"
#include "kfile.h"
#include "kfs.h"

void dos_init(dos_t *s, volume_t *vol, console_t *con) {
    memset(s, 0, sizeof(*s));
    s->vol = vol;
    s->con = con;
}

int dos_fcb_init(dos_fcb_t *fcb, const char *name) {
    memset(fcb, 0, sizeof(*fcb));
    if (dir_parse_name(name, fcb->name) != KFS_OK)
        return KFS_ARG;
    fcb->rec_size = 128;
    return KFS_OK;
}

/* ---- console helpers ---- */
static void con_putc(dos_t *s, char c) { if (s->con && s->con->putch) s->con->putch(s->con->ctx, c); }
static void con_puts(dos_t *s, const char *str) { for (; *str; str++) con_putc(s, *str); }
static int  con_getc(dos_t *s) { return (s->con && s->con->getkey) ? s->con->getkey(s->con->ctx) : -1; }

/* ---- FCB <-> kfile bridge ---- */
static uint32_t fcb_pos(const dos_fcb_t *fcb) {
    return ((uint32_t)fcb->cur_block * 128u + fcb->cur_record) * fcb->rec_size;
}
static void fcb_advance(dos_fcb_t *fcb) {
    if (++fcb->cur_record == 128) { fcb->cur_record = 0; fcb->cur_block++; }
}
static void fcb_to_kfile(dos_t *s, const dos_fcb_t *fcb, kfile_t *f) {
    memset(f, 0, sizeof(*f));
    f->vol = s->vol;
    f->dir_index = fcb->dir_index;
    memcpy(f->name, fcb->name, 11);
    f->first_cluster = fcb->first_cluster;
    f->size = fcb->file_size;
}

/* ---- character I/O (01,02,06,09,0A,0B) ---- */
static void fn_conin(dos_t *s, dos_regs *r) {
    int c = con_getc(s);
    if (c < 0) c = 0;
    con_putc(s, (char)c);          /* CONIN echoes */
    r->al = (uint8_t)c;
}
static void fn_conout(dos_t *s, dos_regs *r) { con_putc(s, (char)r->dl); }
static void fn_rawio(dos_t *s, dos_regs *r) {
    if (r->dl == 0xFF) {           /* input */
        int c = con_getc(s);
        r->al = (c < 0) ? 0 : (uint8_t)c;
    } else {
        con_putc(s, (char)r->dl);
    }
}
static void fn_print_string(dos_t *s, dos_regs *r) {
    const char *p = r->dx_ptr;     /* '$'-terminated (MSDOS.ASM PRTBUF) */
    if (!p) return;
    for (; *p && *p != '$'; p++) con_putc(s, *p);
}
static void fn_buffered_input(dos_t *s, dos_regs *r) {
    uint8_t *buf = r->dx_ptr;       /* [0]=max, [1]=len, [2..]=chars */
    if (!buf) return;
    uint8_t max = buf[0], n = 0;
    for (;;) {
        int c = con_getc(s);
        if (c < 0 || c == '\r' || c == '\n') { con_puts(s, "\r\n"); break; }
        if (c == 0x08 || c == 0x7F) { if (n) { n--; con_puts(s, "\b \b"); } continue; }
        if (n + 1u < max) { buf[2 + n++] = (uint8_t)c; con_putc(s, (char)c); }
    }
    buf[1] = n;
}
static void fn_constat(dos_t *s, dos_regs *r) {
    r->al = (s->con && s->con->kbhit && s->con->kbhit(s->con->ctx)) ? 0xFF : 0x00;
}

/* ---- program / drive control (00,0E) ---- */
static void fn_terminate(dos_t *s, dos_regs *r) { (void)r; s->terminated = 1; }
static void fn_select_disk(dos_t *s, dos_regs *r) {
    s->cur_drive = r->dl;          /* single volume; just record it */
    r->al = 1;                     /* one drive available           */
}

/* ---- FCB file calls (0F,10,11,12,13,14,15,16,1A) ---- */
static void fn_open(dos_t *s, dos_regs *r) {
    dos_fcb_t *fcb = r->dx_ptr;
    uint16_t idx; dir_entry_t e;
    if (!s->vol || dir_find(s->vol, fcb->name, &idx, &e) != KFS_OK) { r->al = 0xFF; return; }
    fcb->first_cluster = e.first_cluster;
    fcb->file_size = e.size;
    fcb->rec_size = 128;
    fcb->cur_block = 0;
    fcb->cur_record = 0;
    fcb->dir_index = idx;
    r->al = 0;
}
static void fn_close(dos_t *s, dos_regs *r) {
    dos_fcb_t *fcb = r->dx_ptr;
    dir_entry_t e;
    if (!s->vol || dir_read_entry(s->vol, fcb->dir_index, &e) != KFS_OK) { r->al = 0xFF; return; }
    e.first_cluster = fcb->first_cluster;
    e.size = fcb->file_size;
    if (dir_write_entry(s->vol, fcb->dir_index, &e) != KFS_OK) { r->al = 0xFF; return; }
    r->al = (volume_flush(s->vol) == DISK_OK) ? 0 : 0xFF;
}
static void fn_create(dos_t *s, dos_regs *r) {
    dos_fcb_t *fcb = r->dx_ptr;
    char nm[13];
    dir_format_name(fcb->name, nm);
    kfile_t f;
    if (!s->vol || kfile_create(s->vol, nm, &f) != KFS_OK) { r->al = 0xFF; return; }
    fcb->first_cluster = 0;
    fcb->file_size = 0;
    fcb->rec_size = 128;
    fcb->cur_block = 0;
    fcb->cur_record = 0;
    fcb->dir_index = f.dir_index;
    r->al = 0;
}
static void fn_delete(dos_t *s, dos_regs *r) {
    dos_fcb_t *fcb = r->dx_ptr;
    char nm[13];
    dir_format_name(fcb->name, nm);
    r->al = (s->vol && kfile_delete(s->vol, nm) == KFS_OK) ? 0 : 0xFF;
}
static void fn_seq_read(dos_t *s, dos_regs *r) {
    dos_fcb_t *fcb = r->dx_ptr;
    if (!s->vol || !s->dta) { r->al = 0xFF; return; }
    kfile_t f; fcb_to_kfile(s, fcb, &f);
    kfile_seek(&f, fcb_pos(fcb));
    uint32_t got = 0;
    if (kfile_read(&f, s->dta, fcb->rec_size, &got) != KFS_OK) { r->al = 0xFF; return; }
    if (got == 0) { r->al = 1; return; }                 /* EOF, no data */
    if (got < fcb->rec_size) {
        memset((uint8_t *)s->dta + got, 0, fcb->rec_size - got);
        fcb_advance(fcb);
        r->al = 3;                                        /* partial record */
        return;
    }
    fcb_advance(fcb);
    r->al = 0;
}
static void fn_seq_write(dos_t *s, dos_regs *r) {
    dos_fcb_t *fcb = r->dx_ptr;
    if (!s->vol || !s->dta) { r->al = 0xFF; return; }
    kfile_t f; fcb_to_kfile(s, fcb, &f);
    kfile_seek(&f, fcb_pos(fcb));
    int rc = kfile_write(&f, s->dta, fcb->rec_size);
    /* Record the (possibly partial) chain even on failure so CLOSE/DELETE can
     * reach and free it -- otherwise a failed write leaks the clusters it grew. */
    fcb->first_cluster = f.first_cluster;
    fcb->file_size = f.size;
    if (rc == KFS_FULL) { r->al = 1; return; }            /* disk full */
    if (rc != KFS_OK)   { r->al = 0xFF; return; }
    fcb_advance(fcb);
    r->al = 0;
}
static void fn_rename(dos_t *s, dos_regs *r) {
    dos_rename_t *q = r->dx_ptr;
    if (!s->vol || !q) { r->al = 0xFF; return; }
    r->al = (kfile_rename(s->vol, q->old, q->newname) == KFS_OK) ? 0 : 0xFF;
}
static void fn_set_dta(dos_t *s, dos_regs *r) { s->dta = r->dx_ptr; }

/* Directory calls (39h/3Ah/3Bh): DS:DX -> ASCIIZ path (our dx_ptr). */
static void fn_mkdir(dos_t *s, dos_regs *r) {
    const char *p = r->dx_ptr;
    r->al = (s->vol && p && dir_mkdir(s->vol, p) == KFS_OK) ? 0 : 0xFF;
}
static void fn_rmdir(dos_t *s, dos_regs *r) {
    const char *p = r->dx_ptr;
    r->al = (s->vol && p && dir_rmdir(s->vol, p) == KFS_OK) ? 0 : 0xFF;
}
static void fn_chdir(dos_t *s, dos_regs *r) {
    const char *p = r->dx_ptr;
    r->al = (s->vol && p && dir_chdir(s->vol, p) == KFS_OK) ? 0 : 0xFF;
}

/* Fill the DTA with a 32-byte directory entry for a search hit. */
static void search_emit(dos_t *s, const dir_entry_t *e) {
    if (s->dta) memcpy(s->dta, e, sizeof(*e));
}
static void fn_search_first(dos_t *s, dos_regs *r) {
    dos_fcb_t *fcb = r->dx_ptr;
    if (!s->vol) { r->al = 0xFF; return; }
    memcpy(s->srch_pat, fcb->name, 11);
    s->srch_index = 0;
    dir_entry_t e;
    if (dir_search(s->vol, s->srch_pat, &s->srch_index, &e) != KFS_OK) { r->al = 0xFF; return; }
    search_emit(s, &e);
    r->al = 0;
}
static void fn_search_next(dos_t *s, dos_regs *r) {
    if (!s->vol) { r->al = 0xFF; return; }
    dir_entry_t e;
    if (dir_search(s->vol, s->srch_pat, &s->srch_index, &e) != KFS_OK) { r->al = 0xFF; return; }
    search_emit(s, &e);
    r->al = 0;
}

int dos_call(dos_t *s, dos_regs *r) {
    switch (r->ah) {
        case DOS_TERMINATE:      fn_terminate(s, r);      return 0;
        case DOS_CONIN:          fn_conin(s, r);          return 0;
        case DOS_CONOUT:         fn_conout(s, r);         return 0;
        case DOS_RAWIO:          fn_rawio(s, r);          return 0;
        case DOS_PRINT_STRING:   fn_print_string(s, r);   return 0;
        case DOS_BUFFERED_INPUT: fn_buffered_input(s, r); return 0;
        case DOS_CONSTAT:        fn_constat(s, r);        return 0;
        case DOS_SELECT_DISK:    fn_select_disk(s, r);    return 0;
        case DOS_OPEN:           fn_open(s, r);           return 0;
        case DOS_CLOSE:          fn_close(s, r);          return 0;
        case DOS_SEARCH_FIRST:   fn_search_first(s, r);   return 0;
        case DOS_SEARCH_NEXT:    fn_search_next(s, r);    return 0;
        case DOS_DELETE:         fn_delete(s, r);         return 0;
        case DOS_SEQ_READ:       fn_seq_read(s, r);       return 0;
        case DOS_SEQ_WRITE:      fn_seq_write(s, r);      return 0;
        case DOS_CREATE:         fn_create(s, r);         return 0;
        case DOS_RENAME:         fn_rename(s, r);         return 0;
        case DOS_SET_DTA:        fn_set_dta(s, r);        return 0;
        case DOS_MKDIR:          fn_mkdir(s, r);          return 0;
        case DOS_RMDIR:          fn_rmdir(s, r);          return 0;
        case DOS_CHDIR:          fn_chdir(s, r);          return 0;
        default:                 r->al = 0xFF;            return -1;  /* unimplemented */
    }
}
