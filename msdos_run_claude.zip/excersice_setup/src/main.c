/* main.c - interactive wrapper CLI.
 *
 * A small disk monitor that demonstrates the host wrapper layer: raw-mode
 * keyboard input, screen output, and sector reads/writes against a disk
 * image that is loaded on start and saved on exit.
 *
 * Usage:
 *   wrapper <image> [sector_count] [sector_size]
 *
 * If <image> exists it is loaded. Otherwise a new zero-filled image of
 * sector_count sectors (default 256) is created and written on exit.
 *
 * Commands (typed at the prompt, Enter to submit):
 *   h                 show help
 *   i                 image info
 *   r <lba>           read and hex-dump a sector
 *   w <lba> <text>    write text into a sector (sector cleared first)
 *   f                 flush image to disk now
 *   c                 clear the screen
 *   q                 quit (saves the image)
 * Control keys: Ctrl-C / Ctrl-Q quit; Ctrl-D on an empty line quits;
 * Ctrl-L clears the screen.
 */
#include "disk.h"
#include "fat12.h"
#include "terminal.h"
#include "kernel/command.h"
#include "kernel/dos.h"
#include "kernel/volume.h"

#include <ctype.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static disk_t g_disk;            /* global so signal/atexit can save it */

static void cleanup(void) {
    disk_close(&g_disk);         /* flushes if dirty; safe if zeroed */
    term_restore();
}

static void on_signal(int sig) {
    (void)sig;
    cleanup();
    _exit(1);
}

static void print_help(void) {
    term_printf(
        "Commands:\r\n"
        "  h               this help\r\n"
        "  i               image info\r\n"
        "  r <lba>         read + hex-dump a sector\r\n"
        "  w <lba> <text>  write text into a sector\r\n"
        "  format          format image as DOS 1.x FAT12 (by geometry)\r\n"
        "  f               flush image to disk now\r\n"
        "  c               clear screen\r\n"
        "  q               quit (saves image)\r\n"
        "Keys: Ctrl-C/Ctrl-Q quit, Ctrl-D quits on empty line, Ctrl-L clears.\r\n");
}

static void print_info(void) {
    term_printf("image : %s\r\n", g_disk.path);
    term_printf("size  : %zu bytes\r\n", g_disk.size);
    term_printf("sector: %u bytes\r\n", g_disk.sector_size);
    term_printf("count : %u sectors\r\n", g_disk.sector_count);
    term_printf("dirty : %s\r\n", g_disk.dirty ? "yes" : "no");
}

/* Hex + ASCII dump of one sector. */
static void cmd_read(uint32_t lba) {
    uint8_t *buf = malloc(g_disk.sector_size);
    if (!buf) { term_printf("out of memory\r\n"); return; }

    int rc = disk_read_sector(&g_disk, lba, buf);
    if (rc != DISK_OK) {
        term_printf("read sector %u: %s\r\n", lba, disk_strerror(rc));
        free(buf);
        return;
    }

    term_printf("sector %u:\r\n", lba);
    for (uint32_t off = 0; off < g_disk.sector_size; off += 16) {
        char line[80];
        int p = snprintf(line, sizeof(line), "%04x  ", off);
        for (uint32_t i = 0; i < 16; i++) {
            if (off + i < g_disk.sector_size)
                p += snprintf(line + p, sizeof(line) - p, "%02x ", buf[off + i]);
            else
                p += snprintf(line + p, sizeof(line) - p, "   ");
        }
        p += snprintf(line + p, sizeof(line) - p, " |");
        for (uint32_t i = 0; i < 16 && off + i < g_disk.sector_size; i++) {
            unsigned char c = buf[off + i];
            line[p++] = isprint(c) ? (char)c : '.';
        }
        line[p++] = '|';
        line[p] = '\0';
        term_printf("%s\r\n", line);
    }
    free(buf);
}

static void cmd_write(uint32_t lba, const char *text) {
    uint8_t *buf = calloc(1, g_disk.sector_size);
    if (!buf) { term_printf("out of memory\r\n"); return; }

    size_t n = strlen(text);
    if (n > g_disk.sector_size) n = g_disk.sector_size;
    memcpy(buf, text, n);

    int rc = disk_write_sector(&g_disk, lba, buf);
    if (rc != DISK_OK)
        term_printf("write sector %u: %s\r\n", lba, disk_strerror(rc));
    else
        term_printf("wrote %zu byte(s) to sector %u\r\n", n, lba);
    free(buf);
}

/* Read one line of input in raw mode, doing our own echo and editing.
 * Returns the line length, or -1 if the user asked to quit. */
static int read_line(char *buf, size_t cap) {
    size_t len = 0;
    for (;;) {
        int k = term_read_key();
        if (k == TERM_EOF || k == KEY_CTRL_C || k == KEY_CTRL_Q) {
            if (k == TERM_EOF && len > 0) { /* flush pending line on EOF */ }
            else return -1;
        }
        if (k == KEY_CTRL_D) {
            if (len == 0) return -1;        /* EOF on empty line */
            continue;
        }
        if (k == KEY_CTRL_L) {
            term_clear();
            term_write("> ");
            (void)!fwrite(buf, 1, len, stdout);
            continue;
        }
        if (k == KEY_ENTER || k == KEY_LF) {
            term_write("\r\n");
            buf[len] = '\0';
            return (int)len;
        }
        if (k == KEY_BACKSPACE || k == KEY_BS) {
            if (len > 0) { len--; term_write("\b \b"); }
            continue;
        }
        if (k >= 0x20 && k < 0x7F && len + 1 < cap) {
            buf[len++] = (char)k;
            char ch = (char)k;
            (void)!write(STDOUT_FILENO, &ch, 1);
        }
    }
}

static void dispatch(char *line) {
    /* tokenize: command, optional lba, optional rest-of-line text */
    char *cmd = strtok(line, " \t");
    if (!cmd) return;

    if (strcmp(cmd, "format") == 0) {
        uint8_t media = fat12_media_for_geometry(g_disk.sector_size,
                                                 g_disk.sector_count);
        if (media == 0) {
            term_printf("format: not a standard DOS 1.x geometry "
                        "(use 512x320 for 160K or 512x640 for 320K)\r\n");
            return;
        }
        int rc = fat12_format(&g_disk, media);
        term_printf("format: %s (media 0x%02X)\r\n", disk_strerror(rc), media);
        return;
    }

    switch (cmd[0]) {
        case 'h': print_help(); break;
        case 'i': print_info(); break;
        case 'c': term_clear();  break;
        case 'f': {
            int rc = disk_flush(&g_disk);
            term_printf("flush: %s\r\n", disk_strerror(rc));
            break;
        }
        case 'r': {
            char *a = strtok(NULL, " \t");
            if (!a) { term_printf("usage: r <lba>\r\n"); break; }
            cmd_read((uint32_t)strtoul(a, NULL, 0));
            break;
        }
        case 'w': {
            char *a = strtok(NULL, " \t");
            char *text = strtok(NULL, "");      /* remainder of the line */
            if (!a || !text) { term_printf("usage: w <lba> <text>\r\n"); break; }
            while (*text == ' ' || *text == '\t') text++;
            cmd_write((uint32_t)strtoul(a, NULL, 0), text);
            break;
        }
        default:
            term_printf("unknown command '%s' (try 'h')\r\n", cmd);
    }
}

/* ===================================================================== *
 *  Boot the ported kernel: mount the disk, wire the terminal as the
 *  console, and run the ported command processor (COMMAND.ASM port).
 * ===================================================================== */

/* Terminal-backed console for the kernel (the CONIN/CONOUT seam). */
static int  tcon_getkey(void *ctx) { (void)ctx; int k = term_read_key(); return k < 0 ? -1 : k; }
static void tcon_putch(void *ctx, char c) { (void)ctx; char b = c; (void)!write(STDOUT_FILENO, &b, 1); }

static int run_shell(const char *path) {
    disk_t d;
    if (disk_open(&d, path, 512) != DISK_OK) {
        /* No disk yet: format a fresh 320 KB MS-DOS 1.25 floppy and boot it. */
        if (fat12_create_image(path, "320") != DISK_OK ||
            disk_open(&d, path, 512) != DISK_OK) {
            fprintf(stderr, "cannot create disk image '%s'\n", path);
            return 1;
        }
        fprintf(stderr, "formatted new 320 KB disk '%s'\n", path);
    }
    volume_t v;
    if (volume_mount(&v, &d) != DISK_OK) {
        fprintf(stderr, "'%s' is not a FAT12 volume (use --format, or --monitor for raw access)\n", path);
        disk_close(&d);
        return 1;
    }
    console_t con = { tcon_getkey, tcon_putch, NULL, NULL };
    dos_t s; dos_init(&s, &v, &con);

    if (term_raw_enable() != 0)
        fprintf(stderr, "warning: could not enable raw mode\n");

    /* Banner, then hand control to the command processor. */
    static const char *banner = "MS-DOS 1.25 (C port)\r\n"
        "Type HELP for commands.\r\n";
    for (const char *p = banner; *p; p++) tcon_putch(NULL, *p);

    command_t cmd;
    command_init(&cmd, &s);
    command_run(&cmd);

    volume_flush(&v);
    volume_unmount(&v);
    term_restore();
    disk_close(&d);
    return 0;
}

static const struct { const char *flag, *name; } SIZE_FLAGS[] = {
    { "--160", "160" }, { "--180", "180" }, { "--320", "320" },
    { "--360", "360" }, { "--720", "720" },
};
#define SIZE_FLAGS_COUNT (sizeof(SIZE_FLAGS) / sizeof(SIZE_FLAGS[0]))

static void usage(const char *prog) {
    fprintf(stderr,
        "usage:\n"
        "  %s <image>                                boot the ported DOS kernel on <image>\n"
        "                                            (formats a fresh 320K disk if absent)\n"
        "  %s --format <path> --SIZE                 create a blank FAT12 image\n"
        "  %s --monitor <image> [count] [size]       low-level sector/hex disk monitor\n"
        "\n"
        "  SIZE is one of: --160 --180 --320 --360 --720 (kilobytes)\n",
        prog, prog, prog);
}

int main(int argc, char **argv) {
    const char *format_path = NULL;   /* set by --format <path>            */
    const char *shell_path  = NULL;   /* set by --shell <path> (explicit)  */
    const char *size_name   = NULL;   /* set by a --SIZE flag              */
    const char *image_path  = NULL;   /* first positional arg              */
    int monitor_mode = 0;             /* set by --monitor                  */
    uint32_t pos[2] = {0, 0};         /* optional sector_count, sector_size */
    int npos = 0;

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (strcmp(a, "--help") == 0 || strcmp(a, "-h") == 0) {
            usage(argv[0]);
            return 0;
        } else if (strcmp(a, "--monitor") == 0) {
            monitor_mode = 1;
        } else if (strcmp(a, "--shell") == 0) {
            if (i + 1 >= argc) { fprintf(stderr, "--shell requires a path\n"); return 2; }
            shell_path = argv[++i];
        } else if (strcmp(a, "--format") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "--format requires a path\n");
                return 2;
            }
            format_path = argv[++i];
        } else if (strncmp(a, "--", 2) == 0) {
            const char *m = NULL;
            for (size_t k = 0; k < SIZE_FLAGS_COUNT; k++)
                if (strcmp(a, SIZE_FLAGS[k].flag) == 0) { m = SIZE_FLAGS[k].name; break; }
            if (!m) {
                fprintf(stderr, "unknown flag '%s'\n", a);
                usage(argv[0]);
                return 2;
            }
            size_name = m;
        } else if (image_path == NULL) {
            image_path = a;                 /* first positional: image path */
        } else if (npos < 2) {
            pos[npos++] = (uint32_t)strtoul(a, NULL, 0);  /* count, then size */
        }
    }

    /* --- DOS shell mode: mount the volume and run the ported kernel --- */
    if (shell_path)
        return run_shell(shell_path);

    /* --- one-shot format mode: create a blank image and exit --- */
    if (format_path) {
        if (!size_name) {
            fprintf(stderr, "--format requires a size flag (e.g. --720)\n");
            usage(argv[0]);
            return 2;
        }
        int rc = fat12_create_image(format_path, size_name);
        if (rc != DISK_OK) {
            fprintf(stderr, "cannot create '%s': %s\n", format_path, disk_strerror(rc));
            return 1;
        }
        uint8_t media; uint32_t ss, sc;
        fat12_geometry_by_name(size_name, &media, &ss, &sc);
        printf("created '%s': %u KB, %u sectors x %u bytes, media 0x%02X\n",
               format_path, (sc * ss) / 1024u, sc, ss, media);
        return 0;
    }

    if (!image_path) {
        usage(argv[0]);
        return 2;
    }

    /* --- default: boot the ported DOS kernel on the image --- */
    if (!monitor_mode)
        return run_shell(image_path);

    /* --- explicit --monitor: low-level sector/hex disk monitor --- */
    const char *path = image_path;
    uint32_t sector_size  = pos[1] ? pos[1] : DISK_DEFAULT_SECTOR_SIZE;
    uint32_t sector_count = pos[0] ? pos[0] : 256;

    int rc = disk_open(&g_disk, path, sector_size);
    if (rc == DISK_ERR_IO) {
        /* No such file: create a fresh image. */
        rc = disk_create(&g_disk, path, sector_size, sector_count);
        if (rc != DISK_OK) {
            fprintf(stderr, "cannot create '%s': %s\n", path, disk_strerror(rc));
            return 1;
        }
        fprintf(stderr, "created new image '%s' (%u x %u bytes)\n",
                path, sector_count, sector_size);
    } else if (rc != DISK_OK) {
        fprintf(stderr, "cannot open '%s': %s\n", path, disk_strerror(rc));
        return 1;
    } else {
        fprintf(stderr, "loaded image '%s' (%u sectors x %u bytes)\n",
                path, g_disk.sector_count, g_disk.sector_size);
    }

    atexit(cleanup);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGHUP, on_signal);

    if (term_raw_enable() != 0)
        fprintf(stderr, "warning: could not enable raw mode\n");

    term_printf("disk monitor - type 'h' for help, 'q' to quit\r\n");

    char line[1024];
    for (;;) {
        term_write("> ");
        int n = read_line(line, sizeof(line));
        if (n < 0)
            break;                  /* quit requested */
        if (n == 0)
            continue;
        if (line[0] == 'q')
            break;
        dispatch(line);
    }

    term_printf("saving image...\r\n");
    /* cleanup() runs via atexit: flushes the disk and restores the terminal. */
    return 0;
}
