MS-DOS 1.25 (C PORT) - DEMO DISK
================================

BASIC PROGRAMS ON THIS DISK:
  HELLO.BAS  - a hello-world loop
  MATH.BAS   - prints a multiplication table
  CALC.BAS   - a simple four-function calculator
  GUESS.BAS  - a two-player number guessing game

TO RUN A PROGRAM FROM THE A> PROMPT:
  BASIC HELLO
  BASIC CALC
  BASIC GUESS

LEARN THE BASIC LANGUAGE:
  TYPE BASIC.TXT   the BASIC dialect manual

OTHER USEFUL COMMANDS:
  DIR              list the files on this disk
  TYPE README.TXT  show this file
  CHKDSK           report disk usage
  EDIT HELLO.BAS   edit a program

HAVE FUN.
