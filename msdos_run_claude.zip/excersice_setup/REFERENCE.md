# Technical Reference

This document is the technical reference for the workspace. It has three parts:

- **Part 1 — MS-DOS 1.25 source** (`v1.25/source/`): the original 8086 assembly.
- **Part 2 — the C host wrapper** (`src/`, `tests/`): the console + disk-image layer a C port
  of the kernel runs on, with module APIs and the FAT12 on-disk format.
- **Part 3 — the ported kernel** (`src/kernel/`): the C port of the `MSDOS.ASM` filesystem and
  `INT 21H` system-call core, layer by layer, and how the wrapper boots it by default.

---

# Part 1 — MS-DOS 1.25 source (`v1.25/source/`)

This folder holds the complete **8086 assembly source** for **MS-DOS version 1.25**,
dated **March 3, 1982**, written by **Tim Paterson** at Seattle Computer Products (SCP).
It is the first general OEM release of MS-DOS and corresponds to **IBM PC DOS 1.1**
(PC DOS 1.1 was MS-DOS 1.24 plus one change — a `00` end-of-directory marker added in 1.25
to speed up directory searches).

All facts below were read directly from the source files in `v1.25/source/`.

---

## File inventory

| File | Lines | Size | Role |
|------|------:|-----:|------|
| `STDDOS.ASM`  |    22 |  627 B | Build entry point — sets switches, `INCLUDE`s the kernel |
| `MSDOS.ASM`   | 4,030 | 110 KB | The DOS kernel (system calls, FAT filesystem, FCB I/O) |
| `COMMAND.ASM` | 2,165 |  65 KB | Command processor (`COMMAND.COM`) |
| `IO.ASM`      | 1,933 |  35 KB | SCP-specific hardware BIOS / I/O layer |
| `ASM.ASM`     | 4,005 |  60 KB | SCP 8086 Assembler v2.44 (the build tool) |
| `TRANS.ASM`   | 1,212 |  15 KB | Z80→8086 source translator v2.21 |
| `HEX2BIN.ASM` |   213 |   3 KB | Intel-HEX-to-binary converter v1.02 |

The first four files (`STDDOS`, `MSDOS`, `COMMAND`, `IO`) **are** the operating system.
The last three (`ASM`, `TRANS`, `HEX2BIN`) are the **toolchain** used to build and port it.

---

## The operating system

### `STDDOS.ASM` — build entry point
A 22-line wrapper. It defines `TRUE`/`FALSE` and four assembly-time switches, then
`INCLUDE MSDOS.ASM`. As shipped:

- `MSVER = TRUE`, `IBM = FALSE` — build the standard MS-DOS variant (not IBM PC DOS)
- `HIGHMEM = FALSE` — load DOS in low memory
- `DSKTEST = FALSE` — separate disk/character stacks for DEBUG re-entrancy testing, off

`STDDOS.ASM` is what you assemble; everything else in the kernel is pulled in from `MSDOS.ASM`.

### `MSDOS.ASM` — the kernel
The heart of the OS. Its header carries a full revision history from **0.34 (12/29/80)** to
**1.25 (03/03/82)**.

**Entry points**
- `QUIT` — `INT 20H`, program terminate
- `COMMAND` — `INT 21H`, the main system-call interrupt; dispatches on the function number in `AH`
- `ENTRY` — the CP/M-compatible `CALL 5` path; remaps `CL`→`AH` and merges with the INT 21H dispatcher
- `FATAL` / `HARDERR` — `INT 24H` fatal-error handling

**System-call dispatch table** (`DISPATCH` at line 349) — 47 functions (0–46):

| # | Routine | # | Routine | # | Routine |
|--:|---------|--:|---------|--:|---------|
| 0 | ABORT | 16 | CLOSE | 32 | GETDSKPT |
| 1 | CONIN | 17 | SRCHFRST | 33 | USERCODE |
| 2 | CONOUT | 18 | SRCHNXT | 34 | RNDRD |
| 3 | READER | 19 | DELETE | 35 | RNDWRT |
| 4 | PUNCH | 20 | SEQRD | 36 | FILESIZE |
| 5 | LIST | 21 | SEQWRT | 37 | SETRNDREC |
| 6 | RAWIO | 22 | CREATE | 38 | SETVECT (extended) |
| 7 | RAWINP | 23 | RENAME | 39 | NEWBASE |
| 8 | IN | 24 | INUSE | … | (block R/W, FCB parse, |
| 9 | PRTBUF | 25 | GETDRV | | date/time, VERIFY) |
| 10 | BUFIN | 26 | SETDMA | | |
| 11 | CONSTAT | 27 | GETFATPT | | |
| 12 | FLUSHKB | 28 | GETFATPTDL | | |
| 13 | DSKRESET | 29 | GETRDONLY | | |
| 14 | SELDSK | 30 | SETATTRIB | | |
| 15 | OPEN | 31 | GETDSKPT… | | |

Functions 0–35 mirror **CP/M 2.2** semantics (FCB-based, `CALL 5`) for easy software porting;
36–46 are the MS-DOS "extended functions."

**FCB structure** (`FCBLOCK`, line 78) — the in-memory file control block:
drive+name (12 bytes), `EXTENT`, `RECSIZ` (record size), `FILSIZ` (file size),
`DRVBP`, `FDATE`/`FTIME` (last-write date/time), `DEVID` (bit 7 flags file vs. device),
`FIRCLUS`/`LSTCLUS`/`CLUSPOS` (first/last/position cluster cache to avoid re-walking chains),
`NR` (next record), `RR` (3-byte random record).

**32-byte directory entry** (documented at line 99):
name+ext (0–10), attributes (11; bits 1–2 = hidden), reserved (12–21),
packed time (22–23), packed date (24–25), first cluster (26–27), file size (28–31, 30-bit max).

**12-bit FAT** (documented at line 112): entries packed two per three bytes —
entry `N` is read by `addr = FAT + N*1.5`, fetch the word, shift right 4 if `N` is odd, mask `0FFFH`.
Cluster 0 = end-of-file trap, cluster 1 reserved, data starts at cluster 2;
entries `> 0FF8H` are EOF, `0` is free. Core routines: `UNPACK`/`PACK` (the odd/even arithmetic),
`FATREAD`/`FATWRT`, `FNDCLUS` (chain walk using the cached cluster fields), `ALLOCATE`/`RELEASE`.

**Drive Parameter Block** (`DPBLOCK`, line 128): per-drive geometry — driver/unit number,
sector size, sectors-per-cluster mask & log2 shift, FAT start sector & count, directory entry count,
first data sector, max cluster, FAT size in sectors, directory start, and FAT pointer.

**BIOS interface**: the kernel calls into a separate `SEGBIOS` segment (at `40H` for SCP,
`60H` for IBM) via far-call stubs for console/printer/aux I/O, disk read/write, disk-change
detection, date/time, console flush, and drive mapping. Named devices `CON`/`AUX`/`PRN`/`NUL`
(plus `COM1` on IBM) are recognized and routed to character I/O instead of the disk.

### `COMMAND.ASM` — command processor (v1.17)
Builds `COMMAND.COM`. Per its header, it is split into three parts:
1. **Resident** — handlers for `INT 22H` (terminate), `INT 23H` (Ctrl-C), `INT 24H` (fatal error),
   `INT 27H` (stay-resident); plus the **checksum** that detects whether the transient was
   overwritten by a user program and reloads it from disk only when needed.
2. **Init** — runs once at startup, then is overwritten.
3. **Transient** — loaded at the top of physical memory (overlayable by big programs); contains
   all internal-command parsing and external-program loading.

Build switches: `MSVER`/`IBMVER` select prompt char (`:` vs `>`) and default COMMAND drive;
`HIGHMEM = TRUE` runs the resident part above the transient.

### `IO.ASM` — SCP hardware BIOS (for "86-DOS 1.20 and later", revised 8-02-82)
The hardware-specific I/O layer **for Seattle Computer Products hardware** — OEMs replaced this
with their own. Everything is selected with assembly-time equates:
- CPU Support card at I/O base `F0H`, console interrupt-driven or polled (`INTINP`)
- Multiport Serial card at `10H` vs. parallel port for AUX and printer, with baud-rate equates
- Disk controllers: SCP / Tarbell SD / Tarbell DD / Cromemco 4FDC / Cromemco 16FDC
- 8-inch and 5.25-inch drive geometries; PerSci fast-seek option
- `CONVERT` mode: drives A/B in new Microsoft FAT format, C/D in old SCP format on the same physical drives

---

## The build toolchain

### `ASM.ASM` — SCP 8086 Assembler v2.44
Tim Paterson's own two-pass 8086 assembler — the tool that assembled DOS before MASM existed.
Revision history runs **2.01 (12/29/80)** → **2.44 (05/09/83)**. Produces Intel HEX and/or binary
plus `.PRN` listings; supports nested `IF`/`ENDIF`, `EQU`/`ORG`/`PUT`, `DB`/`DW`, all 8086 mnemonics,
and 8087 FPU mnemonics (added in 2.40, with Intel "reverse-bit" bug fix in 2.41). 1 KB source buffer.

### `TRANS.ASM` — Z80→8086 Translator v2.21
A source-level translator from Z80 assembly to 8086 assembly, run under 86-DOS. This is the tool
SCP used to port the original Z80 codebase (QDOS/86-DOS lineage) to the 8086.

### `HEX2BIN.ASM` — Intel HEX → binary converter v1.02
Small utility that converts Intel-HEX-format output (e.g. from `ASM.ASM`) into raw binary, with an
optional load-offset argument (default `-100H`). The last link in the build pipeline.

---

## How it fits together

```
              build tools                          operating system
        ┌─────────────────────┐            ┌──────────────────────────────┐
TRANS ──▶ (Z80 → 8086 port)    │   assemble │  STDDOS.ASM ──INCLUDE──▶ MSDOS.ASM (kernel)
ASM   ──▶ (.ASM → .HEX/.bin) ──┼───────────▶│  COMMAND.ASM (shell)
HEX2BIN ▶ (.HEX → binary)      │            │  IO.ASM (SCP BIOS, OEM-replaceable)
        └─────────────────────┘            └──────────────────────────────┘
```

### Notable design points
- **One source, two products**: toggling `IBM`/`MSVER` in `STDDOS.ASM` produces either MS-DOS or
  IBM PC DOS — affecting keyboard handling, prompt char, FCB extent zeroing, named-device set, and
  BIOS segment.
- **CP/M compatibility by design**: the `CALL 5` entry and FCB API ease porting CP/M 2.2 software.
- **Single-tasking, single group**: the kernel runs with `DS=CS=ES=SS` in one `DOSGROUP`; the user
  stack is saved/restored across every system call.
- **No memory management or `EXEC`**: functions 48H/49H/4BH and subdirectories arrived only in DOS 2.0.
- **The 1.25 change**: writing a `00` byte at the end of the directory so searches can stop early.

---

# Part 2 — The C host wrapper (`src/`, `tests/`)

A small C11 application providing the **console and disk-image services** a C port of the DOS
kernel would sit on: raw-mode keyboard input, screen output, and a sector-addressed disk image
loaded on start and saved on exit. It is the host side of the seam the original kernel reaches
through `INT 21H` character I/O (`CONIN`/`CONOUT`) and its BIOS disk calls.

## Module map

| File | Lines | Responsibility |
|------|------:|----------------|
| `src/disk.{h,c}`     | 58 / 131 | Disk image: load file → memory, sector read/write, flush/save |
| `src/terminal.{h,c}` | 53 / 76  | Raw-mode keyboard input, screen output |
| `src/fat12.{h,c}`    | 59 / 145 | FAT12 floppy formatting and identification |
| `src/main.c`         | ~430     | CLI: default kernel boot + `--format` + `--monitor` |
| `tests/test_disk.c`  | 139      | Disk module unit tests (25 checks) |
| `tests/test_format.c`| 196      | FAT12 format / geometry / `--format` tests (51 checks) |

Dependency direction: `main` → {`disk`, `terminal`, `fat12`}; `fat12` → `disk`; `terminal` and
`disk` are independent and have no cross-dependency. The test binaries link only the modules they
exercise (`test_disk` ← `disk`; `test_format` ← `disk` + `fat12`), so neither needs a TTY.

## Disk image module (`disk.h`)

The image is **read fully into memory on open** and **written back on close** (or `disk_flush`).
Access is sector-granular, matching the kernel's DPB/sector model (Part 1, `DPBLOCK`).

```c
typedef struct {
    char    *path;          /* backing file path (owned)      */
    uint8_t *data;          /* in-memory image (owned)        */
    size_t   size;          /* total bytes                    */
    uint32_t sector_size;   /* bytes per sector               */
    uint32_t sector_count;  /* size / sector_size             */
    int      dirty;         /* 1 if modified since last flush */
} disk_t;

int  disk_open (disk_t*, const char *path, uint32_t sector_size); /* load existing image */
int  disk_create(disk_t*, const char *path, uint32_t sector_size, uint32_t sector_count);
int  disk_read_sector (disk_t*, uint32_t lba, void *buf);         /* buf >= sector_size  */
int  disk_write_sector(disk_t*, uint32_t lba, const void *buf);   /* sets dirty          */
int  disk_flush(disk_t*);                                         /* write file if dirty */
int  disk_close(disk_t*);                                         /* flush + free        */
const char *disk_strerror(int code);
```

Semantics:
- `disk_open` requires the file length to be a non-zero multiple of `sector_size`, else `DISK_ERR_ARG`.
- A missing file yields `DISK_ERR_IO` (this is how `main` detects "create instead of open").
- `disk_create` allocates a zero-filled image and marks it `dirty` (nothing on disk yet).
- Read/write bounds-check `lba < sector_count` → `DISK_ERR_RANGE`; `NULL` args → `DISK_ERR_ARG`.
- `disk_close` is safe on a zeroed `disk_t` and returns the flush status.

Status codes (`enum`): `DISK_OK (0)`, `DISK_ERR_IO (-1)`, `DISK_ERR_RANGE (-2)`,
`DISK_ERR_ARG (-3)`, `DISK_ERR_NOMEM (-4)`.

## Terminal module (`terminal.h`)

Puts the controlling terminal into **raw mode** via `termios` so every keypress is delivered
immediately and unmodified — including control keys.

```c
int  term_raw_enable(void);   /* save current attrs, switch to raw; no-op if stdin not a TTY */
void term_restore(void);      /* restore saved attrs; idempotent, signal/atexit-safe         */
int  term_read_key(void);     /* one byte (0-255), or TERM_EOF (-1) / TERM_INTR (-2)          */
void term_write(const char*); /* raw string to screen                                        */
void term_printf(const char *fmt, ...);
void term_clear(void);        /* ANSI clear + home                                           */
```

Raw mode is established by clearing, on a copy of the saved `termios`:
- `c_iflag`: `IXON ICRNL BRKINT INPCK ISTRIP` — no flow-control, no CR→NL, no break/parity handling
- `c_oflag`: `OPOST` — no output post-processing (caller emits explicit `\r\n`)
- `c_lflag`: `ECHO ICANON ISIG IEXTEN` — no echo, no line buffering, **no signal generation**
  (so Ctrl-C arrives as byte `0x03` rather than raising `SIGINT`)
- `c_cflag`: set `CS8`; `VMIN=1, VTIME=0` (block until one byte)

The original `termios` is captured in a static and restored on exit. If `stdin` is **not** a TTY
(e.g. piped input under the test harness), `term_raw_enable` is a no-op and returns 0, so the
program still works with redirected input. Control-key constants (`KEY_CTRL_C`, `KEY_CTRL_D`,
`KEY_CTRL_L`, `KEY_CTRL_Q`, `KEY_ENTER`, `KEY_BACKSPACE`, …) are defined in the header.

## FAT12 module (`fat12.h`) — on-disk format

Formats and identifies FAT12 floppies the **authentic MS-DOS 1.x way**: a volume is recognised
by the **media descriptor byte in the first byte of the FAT**, exactly as the kernel does
(`MSDOS.ASM:980` — `MOV AH,[SI]` / `OR AH,0F8H`). These images carry **no BPB**, **no "FAT12"
type string** (DOS 4.0), and **no volume label** (DOS 2.0).

```c
int     fat12_format(disk_t*, uint8_t media);          /* format to a media's standard layout */
uint8_t fat12_media_for_geometry(uint32_t sector_size, uint32_t sector_count);
uint8_t fat12_media_descriptor(disk_t*);               /* read media byte from FAT[0], or 0   */
int     fat12_geometry_by_name(const char *name, uint8_t *media,
                               uint32_t *sector_size, uint32_t *sector_count);
int     fat12_create_image(const char *path, const char *name); /* create + format + save     */
```

### Supported geometries

All use 512-byte sectors, 1 reserved (boot) sector, and 2 FATs. The table is the single source of
truth (`GEOMETRY[]` in `fat12.c`); `fat12_format` validates the requested disk against it.

| name | media | sectors | bytes | sec/clus | root ent | sec/FAT | data sector |
|------|-------|---------|-------|---------:|---------:|--------:|------------:|
| 160 | `0xFE` | 320  | 163840 | 1 | 64  | 1 | 7 |
| 180 | `0xFC` | 360  | 184320 | 1 | 64  | 2 | 9 |
| 320 | `0xFF` | 640  | 327680 | 2 | 112 | 1 | 10 |
| 360 | `0xFD` | 720  | 368640 | 2 | 112 | 2 | 12 |
| 720 | `0xF9` | 1440 | 737280 | 2 | 112 | 3 | 14 |

`sectors-per-FAT` is sized so the FAT holds every cluster's 12-bit entry; `fat12_format` recomputes
`(clusters + 2) * 3 / 2 + 1` bytes and rejects a geometry whose FAT or system area would not fit
(a self-check on the curated table).

### On-disk layout produced

```
sector 0            boot sector:  EB FE (JMP $ stub) … 00 …  55 AA   (no BPB / no "FAT12")
sector 1            FAT #1:       <media> FF FF 00 00 …               (FAT[0]=0xF??, FAT[1]=0xFFF)
sector 1+spf        FAT #2:       copy of FAT #1
…                   root dir:     all 00  (00 = end-of-directory marker, the 1.25 optimisation)
…                   data area
```

The trailing `55 AA` is the BIOS load signature `FORMAT` wrote; it is **not** a filesystem marker.
`fat12_media_descriptor` validates an image by checking `FAT[0] >= 0xF8` and `FAT[1]==FAT[2]==0xFF`.

## CLI (`main.c`)

Three modes, selected by argument parsing:

**Boot the kernel (default)** — `wrapper <image>`: mounts the image and runs the ported DOS kernel
(see Part 3, `run_shell`). If the image is absent it is formatted as a fresh 320 KB FAT12 disk
first, so the command always boots into a usable shell. This is what runs when no mode flag is
given.

**One-shot format** — create a blank image and exit:
```
wrapper --format <path> --SIZE        SIZE ∈ {--160,--180,--320,--360,--720}
```
Missing path → exit 2; missing/unknown size flag → usage + exit 2; `fat12_create_image` failure →
exit 1. On success prints `created '<path>': <KB> KB, <sectors> sectors x <bps> bytes, media 0xNN`.

**Low-level monitor** — `wrapper --monitor <image> [sector_count] [sector_size]` (defaults 256 ×
512): opens the image, or creates a zero-filled one if absent, then runs a raw sector/hex command
loop reading raw keys (own echo, backspace, Ctrl-L redraw). Commands: `h i r w format f c q` (see
README). On exit, `cleanup()` (registered via `atexit` and `SIGINT/SIGTERM/SIGHUP` handlers)
flushes the disk and restores the terminal — so the image is saved even on signal.

## Build and test

`make build` compiles `wrapper` from the `src/*.c` plus `src/kernel/*.c`. `make test` builds and
runs all seven suites — the five kernel layers (Part 3) followed by `test_disk` (25 checks) and
`test_format` (51 checks). These are plain assert-style harnesses that print PASS/FAIL and exit
non-zero on any failure. The format tests confirm: correct image sizes per `--SIZE`, the authentic
media-descriptor identity (and the *absence* of a BPB/"FAT12" string), geometry lookup, and
graceful errors on missing files, NULL inputs, unknown media, and media/geometry mismatches.

---

# Part 3 — The ported kernel (`src/kernel/`)

A compact C port of the `MSDOS.ASM` filesystem and system-call core (Part 1), built on the wrapper
(Part 2). It was written **bottom-up**: each layer has no dependency on layers above it and ships
with a unit-test suite that passes before the next layer is started. Scope matches MS-DOS 1.x — the
FCB file API and a single fixed root directory; no subdirectories, no `EXEC`/program loader, no
`COMMAND.COM` (those are separate files or DOS 2.0+). Kernel calls return `KFS_*` status codes
(`kfs.h`): `KFS_OK`, `KFS_ERR`, `KFS_NOTFOUND`, `KFS_EXISTS`, `KFS_FULL`, `KFS_RANGE`, `KFS_ARG`,
`KFS_EOF`.

## Layer map

| Layer | Module | Ports (MSDOS.ASM) | Depends on | Tests |
|-------|--------|-------------------|-----------|------:|
| 1 — FAT12 arithmetic | `fat.{h,c}`    | `UNPACK`:448 / `PACK`:484 / `ALLOCATE`:2362 / `FNDCLUS`:1621 | (none) | `test_fat` (24) |
| 2 — Volume / DPB     | `volume.{h,c}` | `DPBLOCK`:128, `FIGFAT`, FAT load/flush | L1, wrapper disk/fat12 | `test_volume` (25) |
| 3 — Directory        | `dir.{h,c}`    | `SRCHFRST`:366 / `SRCHNXT`:367, dir entry:99, subdirs | L2 | `test_dir` (49) |
| 4 — Files            | `kfile.{h,c}`  | OPEN/CLOSE/CREATE/DELETE/SEQRD/SEQWRT | L1-3 | `test_kfile` (24) |
| 5 — DOS dispatch     | `dos.{h,c}`    | `ENTRY`:277 / `DISPATCH`:349, char I/O, FCB, dir calls | L1-4 | `test_dos` (29) |
| command processor    | `command.{h,c}`, `edit.{h,c}`, `basic.{h,c}` | `COMMAND.ASM`, EDIT, `BASIC.COM` | L5 | `test_command` (52), `test_basic` (20) |

## Layer 1 — FAT12 arithmetic (`fat.h`)

Pure, dependency-free operations on a packed 12-bit FAT (two entries per three bytes). The literal
`UNPACK`/`PACK` arithmetic from the porting guide sec. 4.4.

```c
uint16_t fat12_get(const uint8_t *fat, uint16_t cluster);   /* UNPACK */
void     fat12_set(uint8_t *fat, uint16_t cluster, uint16_t value);  /* PACK */
bool     fat12_is_eof(uint16_t v);   /* v >= 0xFF8 */
bool     fat12_is_free(uint16_t v);  /* v == 0     */
uint16_t fat12_next(const uint8_t *fat, uint16_t cluster);
uint16_t fat12_chain_length(const uint8_t *fat, uint16_t start);
uint16_t fat12_count_free(const uint8_t *fat, uint16_t max_cluster);
uint16_t fat12_alloc(uint8_t *fat, uint16_t max_cluster);   /* ALLOCATE; 0 if full */
void     fat12_free_chain(uint8_t *fat, uint16_t start);    /* RELEASE  */
```

`fat12_get`: `i = cluster + cluster/2`; fetch the 16-bit word at `fat[i]`; if the cluster is odd
shift right 4, else mask `0x0FFF`. `fat12_set` merges the value into the correct nibble lane.
Sentinels: `0` free, `>= 0xFF8` end-of-chain, `0xFF7` bad; data clusters start at 2.

## Layer 2 — Volume / DPB (`volume.h`)

Binds a wrapper `disk_t` to FAT12 geometry derived from the media byte in `FAT[0]`
(`MSDOS.ASM:980`), loads the FAT into memory, and offers cluster / root-sector I/O. The `volume_t`
struct mirrors `DPBLOCK`: media, bytes/sector, sectors/cluster, reserved sectors, FAT count & size,
root entries, derived `first_root_sector`/`first_data_sector`, `cluster_count`, `max_cluster`, and
the in-memory `fat` pointer.

```c
int volume_mount(volume_t *v, disk_t *disk);   /* read media, derive layout, load FAT */
int volume_flush(volume_t *v);                 /* write FAT to all copies + flush disk */
void volume_unmount(volume_t *v);
uint32_t volume_cluster_sector(const volume_t *v, uint16_t cluster);
int volume_read_cluster (volume_t *v, uint16_t cluster, void *buf);
int volume_write_cluster(volume_t *v, uint16_t cluster, const void *buf);
int volume_read_root_sector (volume_t *v, uint16_t idx, void *buf);
int volume_write_root_sector(volume_t *v, uint16_t idx, const void *buf);
```

Geometry is obtained from the wrapper's `fat12_layout()` (single source of truth), so the kernel and
the formatter never disagree. Mounting an unformatted/unknown image returns `DISK_ERR_ARG`. The FAT
lives in memory while mounted (as the kernel keeps a FAT pointer per drive) and is written back to
**both** FAT copies by `volume_flush`.

## Layer 3 — Directory (`dir.h`)

The single fixed-size root directory: 8.3 name handling and slot search/create over the root region.

```c
int  dir_parse_name(const char *s, uint8_t out[11]);     /* "a.txt" -> "A       TXT" */
int  dir_parse_pattern(const char *s, uint8_t out[11]);  /* allows '?' and '*'        */
void dir_format_name(const uint8_t name[11], char out[13]);
bool dir_name_match(const uint8_t pattern[11], const uint8_t name[11]);
int  dir_read_entry (volume_t*, uint16_t index, dir_entry_t*);
int  dir_write_entry(volume_t*, uint16_t index, const dir_entry_t*);
int  dir_find(volume_t*, const uint8_t name[11], uint16_t *index, dir_entry_t*);  /* exact */
int  dir_find_free(volume_t*, uint16_t *index);
int  dir_search(volume_t*, const uint8_t pat[11], uint16_t *index, dir_entry_t*); /* SRCHFRST/NEXT */
```

`dir_entry_t` is the packed 32-byte on-disk entry (name[11], attr, reserved[10], time, date,
first_cluster, size); a `_Static_assert` pins `sizeof == 32`. Scans stop at a `0x00` first byte
(the end-of-directory marker MS-DOS 1.25 introduced) and skip `0xE5` (deleted). `dir_search`
returns one match and advances `*index`, so repeated calls implement SEARCH NEXT.

**Subdirectories.** DOS 2.0-style subdirectories are layered onto the volume: a subdir is a one-
cluster file of 32-byte entries whose directory entry carries the `DIR_ATTR_DIR` (0x10) attribute,
with `.` and `..` as its first two entries (`..`'s first cluster is the parent, or 0 for the root).
A `dir_loc` (`{is_root, cluster}`) names a directory, and an internal `slot_locate` maps a slot
index to a disk sector for either the root region or a chain. The volume tracks a **current
directory** (`volume_t.cwd` + `cwd_path`); the public `dir_*` and all file operations are
cwd-relative, so nothing above this layer changed. `dir_mkdir`/`dir_rmdir` (empty-only) and
`dir_chdir` (a single name, `..` via the stored `..` entry, or `\` to the root) implement the
commands; the root stays the default, so 1.x-style single-directory use is unaffected. Scope is
deliberately small: single-component paths, one cluster per directory (no growth).

## Layer 4 — Files (`kfile.h`)

Byte-stream file I/O over cluster chains — the substance of the FCB file calls.

```c
int kfile_create(volume_t*, const char *name, kfile_t*);  /* create or truncate, open at 0 */
int kfile_open  (volume_t*, const char *name, kfile_t*);
int kfile_read  (kfile_t*, void *buf, uint32_t len, uint32_t *got);
int kfile_write (kfile_t*, const void *buf, uint32_t len);  /* extends chain; KFS_FULL if no space */
int kfile_seek  (kfile_t*, uint32_t pos);
int kfile_close (kfile_t*);                                 /* update dir entry + flush FAT */
int kfile_delete(volume_t*, const char *name);              /* free chain + mark slot deleted */
```

The internal `cluster_for_pos()` walks the chain to the cluster holding byte `pos`, extending it
via `fat12_alloc` when writing (mirrors `FNDCLUS` + `ALLOCATE`). Writes are read-modify-write at
cluster granularity so partial clusters keep their other bytes; `size` grows as the position passes
the old end. `kfile_close` writes `first_cluster`/`size` back to the directory entry and flushes.

## Layer 5 — DOS dispatch (`dos.h`)

The `INT 21H` system-call layer: a register block, a dispatch on `AH`, character I/O through a
pluggable console, and the FCB file calls bridged to Layer 4.

```c
typedef struct { /* saved-register block; AH/AL etc. as byte unions */
    union { uint16_t ax; struct { uint8_t al, ah; }; };  /* + bx,cx,dx, si,di,bp */
    void *dx_ptr;        /* stands in for the DS:DX far pointer (porting guide 1.2) */
} dos_regs;

typedef struct { int (*getkey)(void*); void (*putch)(void*, char); int (*kbhit)(void*); void *ctx; } console_t;

void dos_init(dos_t *s, volume_t *vol, console_t *con);
int  dos_call(dos_t *s, dos_regs *r);     /* dispatch on r->ah; -1 if unimplemented */
int  dos_fcb_init(dos_fcb_t *fcb, const char *name);
```

`dos_call` switches on `r->ah` exactly as `DISPATCH` indexes on the function number. Implemented
functions (a representative subset of the table):

| AH | Name | Backed by |
|----|------|-----------|
| 00h | terminate | sets `dos_t.terminated` |
| 01h/02h/06h | CONIN / CONOUT / direct I/O | `console_t` |
| 09h | print `$`-string | `console_t` |
| 0Ah/0Bh | buffered input / console status | `console_t` |
| 0Eh | select disk | records current drive |
| 0Fh/10h/16h/13h | OPEN / CLOSE / CREATE / DELETE | dir + kfile |
| 11h/12h | SEARCH FIRST / NEXT | `dir_search`, result to DTA |
| 14h/15h | SEQ READ / WRITE | kfile via the FCB record cursor |
| 1Ah | set DTA | stores transfer-area pointer |

The console is the `CONIN`/`CONOUT` BIOS seam: the wrapper supplies a terminal-backed
implementation, tests supply a buffer-backed stub. `DS:DX` far pointers (string, FCB, buffer)
arrive as `dx_ptr`. The in-memory `dos_fcb_t` is compact but scope-faithful (drive, 8.3 name,
current block/record, record size, file size, internal first-cluster and directory index); the
sequential calls compute the byte position as `(cur_block*128 + cur_record) * rec_size` and advance
the record cursor, mapping the CP/M extent/record model onto `kfile` seeks. Function 17h RENAME
takes a `dos_rename_t` (old + new 8.3 names in one block, mirroring the real rename-FCB) and calls
`kfile_rename`.

## Command processor (`command.h` — the COMMAND.ASM port)

The transient command interpreter, sitting on top of Layer 5 (it makes only `dos_call()` requests,
never touching the disk directly — exactly as `COMMAND.COM` makes only `INT 21H` calls).

```c
typedef struct { dos_t *dos; int running; char drive; } command_t;
void command_init(command_t *c, dos_t *dos);
void command_run (command_t *c);                 /* prompt -> read line -> dispatch loop */
int  command_exec(command_t *c, char *line);     /* run one line (exposed for tests)     */
```

`command_run` prints the `A>` prompt, reads a line from the console (echo + backspace, terminating
on end-of-input), and calls `command_exec`. `command_exec` skips leading blanks, upper-cases the
command word, and looks it up in an internal-command table (the analogue of COMMAND.ASM's command
name table); a miss prints `Bad command or file name` — the same fallthrough the original uses
before attempting to load an external program (program loading is out of scope for this port).

| Command | Issues (INT 21H) |
|---------|------------------|
| `DIR [pattern]` | 1Ah set DTA, 11h/12h SEARCH FIRST/NEXT, 02h print |
| `TYPE <f>` | 0Fh OPEN, 14h SEQ READ loop |
| `COPY <src> <dst>` | 0Fh OPEN, 16h CREATE, 14h/15h READ/WRITE, 10h CLOSE |
| `REN <old> <new>` | 17h RENAME |
| `DEL`/`ERASE <f>` | 13h DELETE |
| `MKDIR`/`MD`, `RMDIR`/`RD`, `CD`/`CHDIR` | 39h MKDIR, 3Ah RMDIR, 3Bh CHDIR |
| `EDIT <f>` | 0Fh/14h load, then a full-screen editor; 16h/15h/10h on save |
| `BASIC <f>` | 0Fh/14h load the program, then run the interpreter |
| `CHKDSK` | 1Ah/11h/12h dir scan for file count/bytes + FAT free count for capacity |
| `ECHO REM CLS VER DATE TIME HELP` | 02h CONOUT (console built-ins) |
| `EXIT`/`QUIT` | clears `running` |

`EDIT` (`edit.h`) is a compact full-screen editor over a flat in-memory buffer (8 KB cap). It reads
keys and renders through the same `console_t`, so it works on the raw-mode terminal and on a test
stub alike. Its key bindings are single control bytes a raw-mode terminal never intercepts —
**Ctrl-W** save, **Ctrl-X** exit, **Ctrl-B/F/P/N** move, **Ctrl-A/E** line start/end, Backspace /
**Ctrl-D** delete — deliberately avoiding the flow-control keys Ctrl-S/Ctrl-Q and the signal keys
Ctrl-C/Ctrl-Z. Unrecognised escape sequences (Delete, PgUp/Dn, function keys) are fully drained so
they never leak stray characters into the text; recognised arrow sequences map to the same movement.

Save is **atomic**: the buffer is written to a temp file (`EDITTMP.$$$`) as one record
(`rec_size = length`, exact since the buffer is < 64 KB), and only once that fully succeeds is the
target replaced (DELETE + RENAME). A failure mid-write — e.g. a full disk — therefore leaves the
original file intact. Files larger than the 8 KB buffer are refused on open rather than loaded and
silently truncated on save.

`BASIC` (`basic.h`) is a rudimentary line-numbered interpreter (`BASIC.COM` analogue). `cmd_basic`
loads the `.BAS` file via `INT 21H` (defaulting the extension) into a 16 KB buffer and calls
`basic_run`, which tokenises the program in place into numbered lines, sorts them, and executes with
a recursive-descent expression evaluator. Subset: `PRINT` / `LET` / bare assignment / `IF..THEN` /
`GOTO` / `FOR..TO..STEP`/`NEXT` / `INPUT` / `REM` / `END`/`STOP`; numeric and string (`A$`)
variables; `+ - * /`, parentheses, comparisons and `+` string concatenation. I/O is the same
`console_t`, so the interpreter is driven by a stub console in tests.

The `SELFTEST.BAS` program in `README.md` exercises the whole dialect in one run (author with
`EDIT SELFTEST.BAS`, run with `BASIC SELFTEST`); each output line maps to a feature, and
`test_basic` asserts the same results:

| Output line | Feature |
|-------------|---------|
| `A*B = 42` | bare assignment, `*`, mixed string/number `PRINT` with `;` |
| `MATH: 14 20` | operator precedence (`2+3*4`) and parentheses (`(2+3)*4`) |
| `SUM 1..10 = 55` | `FOR/NEXT` ascending with accumulation |
| `COUNTDOWN: 5 3 1` | `FOR/NEXT` with negative `STEP`; trailing `;` then bare `PRINT` |
| `HELLO WORLD` | string variables and `+` concatenation |
| `SUM OK` / `DIFFERENT` | `IF…THEN` with `=` and `<>` |
| `GOTO: 1 2 3` | `GOTO` loop with `IF N<3 THEN GOTO` |
| `DONE` | `END` terminates |

All output (including the prompt and file bytes from `TYPE`) goes through function 02h CONOUT, so a
swap of the `console_t` redirects the whole shell. `command_exec` is buffer-driven and independent
of any terminal, so the suite drives it with a stub console.

## Integration with the wrapper (default boot)

`./wrapper <image>` is the wrapper's default action: `run_shell` (in `main.c`) formats the image if
absent, mounts it with `volume_mount`, wires a terminal-backed `console_t` (`term_read_key` /
`write` — the CONIN/CONOUT seam), and runs the command processor (`command_run`). Thus the kernel
and its command interpreter boot on the wrapper's keyboard input, screen output and disk with no
extra flags. File changes flush to the disk image on close, so files persist across sessions.
`make run` boots the kernel on `disk.img`; `make monitor` opens the same image in the low-level
sector monitor.

## Build and test (kernel)

`make test` runs the kernel suites bottom-up before the wrapper suites: `test_fat` (24),
`test_volume` (25), `test_dir` (49), `test_kfile` (24), `test_dos` (29), `test_command` (52),
`test_basic` (20) — 223 kernel checks, 299
total. Lower-layer suites link only the modules they exercise (e.g. `test_fat` is just `fat.c`), so
each layer is genuinely verified in isolation, in keeping with the bottom-up construction.
